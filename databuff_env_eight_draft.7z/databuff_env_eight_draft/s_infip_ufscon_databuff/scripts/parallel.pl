use strict;
use warnings;
use File::Path qw(make_path remove_tree);
use Cwd;

	my $a 		= cwd();
	my @array 	= split('/',$a);
	my $str 	= join ('/',($array[0],$array[1],$array[2]));
	chdir($str);
#make_path("NEW_CREATED\n");
	system('source ~/.cshrc');
#	print " Value of cwd is $a\n Value of split array is @array \n Value of required home dir is $str \n Value of source is $b \n";
#	

