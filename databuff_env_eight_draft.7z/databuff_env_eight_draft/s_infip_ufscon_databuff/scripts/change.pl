use strict;
use warnings;
use Cwd;


my $a = cwd();
print " Currently in $a\n";
my $b =  $ENV{"HOME"};
#chdir $b;
$a=cwd();
print " Now in  in $a\n";
print "\n".$ENV{"USER"}."\n";
my $user = $ENV{"USER"};
my $num_jobs = `qstat | grep "$user" | wc -l `;
print "$num_jobs\n";

my @arr=`ls | grep ".txt"`;
print " Length of array is ".scalar @arr."\n";


