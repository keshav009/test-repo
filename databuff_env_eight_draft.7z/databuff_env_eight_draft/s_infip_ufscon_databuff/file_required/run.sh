#!/bin/sh
#IUS_HOME=/usr/share/Tools/IES1302018_23092014
#IUS_HOME=`ncroot` 
#-parseinfo include \

irun  -mess -sv -define DENALI_SV_NC \
	-top specman -top specman_wave \
	-define DENALI_UVM -uvm \
        -input wave_dump.tcl \
        -input noassert.tcl \
	-access +rw \
        -gui \
	-vtimescale 1ns/100ps \
	-uvm -sem2009 +access+rwc -V93 \
	-loadvpi ${DENALI}/verilog/libcdnsv.so:cdnsvVIP:export \
	-ncsimargs "-loadrun ${CDN_VIP_LIB_PATH}/libcdnvipcuvm.so" \
	-incdir ${DENALI}/ddvapi/sv \
	-SVSEED random +define+SHP_ENHS +define+PA_MAX_DATA_LANES1 +define+RX_SYB_DWIDTH16 +define+TX_SYB_DWIDTH16 \
	+define+PSEUDO_SIDEBAND_SIGNAL_ENABLE +define+DMAWIDTH64 +define+DATA_DEBUG +define+SHP_CLOCK_250 +define+UTP_SHP +define+DYN_PKT_SIZE \
	${DENALI}/ddvapi/sv/denaliMem.sv \
	${DENALI}/ddvapi/sv/denaliCdn_axi.sv \
	-incdir ${DENALI}/ddvapi/sv/uvm/cdn_axi \
	${DENALI}/ddvapi/sv/uvm/cdn_axi/cdnAxiUvmTop.sv \
	-top s_infip_ufscon_v1_top_tb \
	+define+CDN_AUTO_TEST \
	-incdir /nas_storage/non_svn/div2/UFSCON_PH2_PUB/senthil/verification/testbench/top/vip_models/axi \
	/nas_storage/swtools_div2/VIPCAT113_33_11_06_2015/tools.lnx86/denali/ddvapi/sv/hdl_interfaces/cdn_axi/cdnAxi3Interface.sv \
	+incdir+../testbench/top/vip_models/ral \
	+incdir+../testbench/top/common/sv \
	+incdir+../testbench/top/vip_models/ubus/tb/include \
	+incdir+../testbench/top/vip_models/ubus/tb/isdc_sdcon_ubus_ip/sv \
        +incdir+../testbench/top/vip_models/shp/MASTER/s_infip_shp_v1/tb/s_infip_shp_v1_master_top_common/sv \
	+incdir+../testbench/top/vip_models/shp/MASTER/s_infip_shp_v1/tb/s_infip_shp_v1_master/sv \
        +incdir+../testbench/top/vip_models/shp/SLAVE/s_infip_shp_v1/tb/s_infip_shp_v1_slave_top_common/sv \
	+incdir+../testbench/top/vip_models/shp/SLAVE/s_infip_shp_v1/tb/s_infip_shp_v1_slave/sv \
	+incdir+../testbench/top/vip_models/unipro/s_infip_ufscon_v1/tb/s_infip_ufscon_v1_unipro_device/sv \
	+incdir+../testbench/top/vip_models/unipro/s_infip_ufscon_v1/tb/s_infip_ufscon_v1_unipro_top_common/sv \
	+incdir+../testbench/top/environment/sv \
	+incdir+../testcases/selftest1 \
	+incdir+../testbench/top/vip_models/shp/MASTER/s_infip_shp_v1/assertion \
	+incdir+../testbench/top/vip_models/shp/SLAVE/s_infip_shp_v1/assertion \
	+incdir+../testbench/top/tb \
	+incdir+../testbench/top/vip_models/m_phy/s_infip_ufscon_v1/tb/include \
	+incdir+../testbench/top/vip_models/m_phy/s_infip_ufscon_v1/tb/s_infip_ufscon_v1_m_phy_pseudo_agent/sv \
	+incdir+../testbench/sequences/ubus \
	+incdir+../testbench/sequences/ufscon \
	+incdir+../testbench/sequences/shp \
	+incdir+../testbench/sequences/axi \
	+incdir+/nas_storage/swtools_div2/IES_14_2_024/latest/tools.lnx86/methodology/UVM/CDNS-1.1d/additions/sv/reg/ \
	-F dut.f \
	../testbench/top/common/sv/s_infip_ufscon_v1_common_pkg.sv \
	../testbench/top/vip_models/axi/axi3UvmUserTop.sv \
	../testbench/top/vip_models/unipro/s_infip_ufscon_v1/tb/s_infip_ufscon_v1_unipro_top_common/sv/s_infip_ufscon_v1_unipro_top_common_pkg.sv \
	../testbench/top/vip_models/unipro/s_infip_ufscon_v1/tb/s_infip_ufscon_v1_unipro_device/sv/s_infip_ufscon_v1_unipro_device_pkg.sv \
	../testbench/top/vip_models/ral/infra_ip_ufscon_v2_rdb.sv \
	../testbench/top/vip_models/ubus/tb/isdc_sdcon_ubus_ip/sv/isdc_sdcon_ubus_ip_pkg.sv \
	../testbench/top/vip_models/ral/ubus_reg_adaptor.sv \
        ../testbench/top/vip_models/shp/SLAVE/s_infip_shp_v1/tb/s_infip_shp_v1_slave_top_common/sv/s_infip_shp_v1_slave_top_common_pkg.sv \
	../testbench/top/vip_models/shp/SLAVE/s_infip_shp_v1/tb/s_infip_shp_v1_slave/sv/s_infip_shp_v1_slave_pkg.sv \
        ../testbench/top/vip_models/shp/MASTER/s_infip_shp_v1/tb/s_infip_shp_v1_master_top_common/sv/s_infip_shp_v1_master_top_common_pkg.sv \
	../testbench/top/vip_models/shp/MASTER/s_infip_shp_v1/tb/s_infip_shp_v1_master/sv/s_infip_shp_v1_master_pkg.sv \
	../testbench/top/vip_models/m_phy/s_infip_ufscon_v1/tb/s_infip_ufscon_v1_m_phy_pseudo_agent/sv/s_infip_ufscon_v1_m_phy_pseudo_agent_pkg.sv \
	../testbench/sequences/ubus/s_infip_ufscon_v1_ubus_top_seq_pkg.sv \
	../testbench/top/environment/sv/s_infip_ufscon_v1_top_pkg.sv \
	../testcases/selftest1/s_infip_ufscon_v1_top_test_pkg.sv \
	../testbench/top/tb/s_infip_ufscon_v1_resetnclockgen.sv \
	../testbench/top/tb/s_infip_ufscon_v1_top_th.sv \
	../testbench/top/tb/s_infip_ufscon_v1_top_tb.sv \
	-snprerun notest -snnoauto \
        +UVM_VERBOSITY=UVM_MEDIUM $* \
	${CDN_VIP_LIB_PATH}/ncsim_psui.sv

#	+UVM_TESTNAME=s_infip_ufscon_v1_reg_def_val_test \

#	+define+PSEUDO_SIDEBAND_SIGNAL_ENABLE +define+DMAWIDTH32 +define+DATA_DEBUG +define+SHP_CLOCK_250 +define+TDMAC_DEBUG \

#s_infip_ufscon_v1_utp_backdoor_axi_slave_write

#irun -SVSEED 1 +define+SHP_ENHS +define+PA_MAX_DATA_LANES1 +define+RX_SYB_DWIDTH16 +define+TX_SYB_DWIDTH16 \
#+define+PSEUDO_SIDEBAND_SIGNAL_ENABLE +define+DMAWIDTH32 +define+DATA_DEBUG +define+SHP_CLOCK_250 -vtimescale 1ns/10ps -uvm -64 -sem2009 +access+rwc -V93  \
#+incdir+../testbench/top/vip_models/ral \
#+incdir+../testbench/top/common/sv \
#+incdir+../testbench/top/vip_models/axi \
#+incdir+../testbench/top/vip_models/ubus/tb/include \
#+incdir+../testbench/top/vip_models/ubus/tb/isdc_sdcon_ubus_ip/sv \
#+incdir+../testbench/top/vip_models/shp/MASTER/s_infip_shp_v1/tb/s_infip_shp_v1_master/sv \
#+incdir+../testbench/top/vip_models/shp/SLAVE/s_infip_shp_v1/tb/s_infip_shp_v1_slave/sv \
#+incdir+../testbench/top/vip_models/unipro/s_infip_ufscon_v1/tb/s_infip_ufscon_v1_unipro_device/sv \
#+incdir+../testbench/top/vip_models/unipro/s_infip_ufscon_v1/tb/s_infip_ufscon_v1_unipro_top_common/sv \
#+incdir+../testbench/top/environment/sv \
#+incdir+../testcases/selftest1 \
#+incdir+../testbench/top/vip_models/shp/SLAVE/s_infip_shp_v1/assertion \
#+incdir+../testbench/top/vip_models/shp/MASTER/s_infip_shp_v1/assertion \
#+incdir+../testbench/top/tb \
#+incdir+../testbench/top/vip_models/m_phy/s_infip_ufscon_v1/tb/include \
#+incdir+../testbench/top/vip_models/m_phy/s_infip_ufscon_v1/tb/s_infip_ufscon_v1_m_phy_pseudo_common/sv \
#+incdir+../testbench/top/vip_models/m_phy/s_infip_ufscon_v1/tb/s_infip_ufscon_v1_m_phy_pseudo_agent/sv \
#+incdir+../testbench/top/vip_models/m_phy/s_infip_ufscon_v1/tb/s_infip_ufscon_v1_m_phy_pseudo/sv \
#+incdir+../testbench/top/vip_models/m_phy/s_infip_ufscon_v1/tb/s_infip_ufscon_v1_m_phy_pseudo_test/sv \
#+incdir+../testbench/sequences/ubus \
#+incdir+../testbench/sequences/ufscon \
#+incdir+../testbench/sequences/shp \
#+incdir+../testbench/sequences/m_phy \
#+incdir+../testbench/sequences/unipro \
#+incdir+/nas_storage/swtools_div2/IES_14_2_25022015/latest/tools.lnx86/methodology/UVM/CDNS-1.1d/additions/sv/reg/ \
#-F dut.f \
#../testbench/top/common/sv/s_infip_ufscon_v1_common_pkg.sv \
#../testbench/top/vip_models/axi/axi3UvmUserTop.sv \
#../testbench/top/vip_models/unipro/s_infip_ufscon_v1/tb/s_infip_ufscon_v1_unipro_top_common/sv/s_infip_ufscon_v1_unipro_top_common_pkg.sv \
#../testbench/top/vip_models/unipro/s_infip_ufscon_v1/tb/s_infip_ufscon_v1_unipro_device/sv/s_infip_ufscon_v1_unipro_device_pkg.sv \
#../testbench/top/vip_models/ral/infra_ip_ufscon_v2_rdb.sv \
#../testbench/top/vip_models/ubus/tb/isdc_sdcon_ubus_ip/sv/isdc_sdcon_ubus_ip_pkg.sv \
#../testbench/top/vip_models/ral/ubus_reg_adaptor.sv \
#../testbench/top/vip_models/shp/SLAVE/s_infip_shp_v1/tb/s_infip_shp_v1_slave/sv/s_infip_shp_v1_slave_pkg.sv \
#../testbench/top/vip_models/shp/MASTER/s_infip_shp_v1/tb/s_infip_shp_v1_master/sv/s_infip_shp_v1_master_pkg.sv \
#../testbench/top/vip_models/m_phy/s_infip_ufscon_v1/tb/s_infip_ufscon_v1_m_phy_pseudo_agent/sv/s_infip_ufscon_v1_m_phy_pseudo_agent_pkg.sv \
#../testbench/sequences/ubus/s_infip_ufscon_v1_ubus_top_seq_pkg.sv \
#../testbench/top/environment/sv/s_infip_ufscon_v1_top_pkg.sv \
#../testcases/selftest1/s_infip_ufscon_v1_top_test_pkg.sv \
#../testbench/top/tb/s_infip_ufscon_v1_resetnclockgen.sv \
#../testbench/top/tb/s_infip_ufscon_v1_top_th.sv \
#../testbench/top/tb/s_infip_ufscon_v1_top_tb.sv \
#+UVM_TESTNAME=s_infip_ufscon_v1_utp_backdoor_axi_slave_write \ 
#${CDN_VIP_LIB_PATH}/ncsim_psui.sv
#+UVM_TESTNAME=s_infip_ufscon_v1_reg_rd_wr_test +UVM_VERBOSITY=UVM_FULL $*
#+UVM_VERBOSITY=UVM_FULL $*
#+UVM_TESTNAME=s_infip_ufscon_v1_shp_write_test +UVM_VERBOSITY=UVM_FULL $*
#Note: To run single testcase use the following command"
#./compile_ius_t.sh +UVM_TESTNAME=s_infip_ufscon_v1_attr_reg_def_val_test -clean -gui       
