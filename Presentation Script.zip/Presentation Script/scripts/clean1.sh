rm -rf ../regression ../sim/rtl_sim ../sim/vip_lib/ ../sim/irun.key
