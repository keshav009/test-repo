#!/usr/bin/perl -w
#==========================================================================================================================================================================
#  Task 	: Perl Script 
#  Filename 	: test.pl
#==========================================================================================================================================================================
#  Description	: Perl script to assist user in running single test cases or regression lists using cadence sim tool.
#==========================================================================================================================================================================
#
#==========================================================================================================================================================================
#  Libraries Used.
#==========================================================================================================================================================================
use strict;						# Used for unsafe constructs
use warnings;						# Used for controlling optional warnings
use Getopt::Long;					# Getopt::Long is used for command line arguments while executing the perl script.
use File::Glob;						# Used for the function Glob, which is used for finding files in a directory   
use Switch;						# Switch is equivalent to case statements.
use POSIX qw(strftime);					# strftime is used to get the current time in any desired format.
use Cwd;						# cwd() returns the current working directory in which the perl script is executing.
use File::Copy;						# Provides 2 basic functions, copy and move, which are useful for getting content from one place to another 
use File::Path;						# Used for creating and removing directory trees
use Switch;						# Switch is equivalent to case statements.
use Data::Dumper;					# Used to print hashes
use Time::Local;					# Used for manipulation in time variables
#==========================================================================================================================================================================
# Validity Variables Used for test and regression.
#==========================================================================================================================================================================
my $valid_test 	= 'nil';				# Flag to keep track if the single test case option is selected by the user
my $valid_reg  	= 'nil';				# Flag to keep track if the regression option is selected by the user.
my $retest 	= 0;					# $retest keeps track of the number of times each test_case is to be run.
my $select 	= 'none';				# $select is used to switch betweem compile, test or regression mode.
my $state	= 1;					# To operate as static variable while creating the excel sheet.
#==========================================================================================================================================================================
# Variables to store the IRUN commands for test and regression.
#==========================================================================================================================================================================
my $cmd_reg='';						# Regression list command
my $cmd_test='';					# Single test command
#========================================================================================================================================================
# OPTIONS- These variables are used to store all the required options for test and regression.
#========================================================================================================================================================
my $reg_file;						# $reg_file is used to store the regression file list.
my $verbosity = 'nil';					# Storing the user input verbosity if provided
my $seed = 'nil';					# Storing the user input seed if provided
my $stop_time ='nil';					# Storing the user input timeout if provided
my $test_name_single;					# $test_name_single is used to store a single test case name.
my $frtl;						# $frtl is use to store the rtl file list. 
my $ftb;						# ftb is used to store the testbench filelist.
my $tool;						# Holds the tool name - ncsim, vcs, modelsim.
my $inclist;						# Stores the file name for inclist	 
my $vtimescale;						# Stores the time scale for running the tests 
my $deflist = 'nil';					# Stores the file name for define list
my $sim_mode;						# Stores the mode : rtl_sim, cov_sim   
my $gui ='nil';						# Checks for GUI mode
my $pbs ='nil';						# Checks for PBS enabling
my $dump = 'nil';					# Storing the dump file
my $log = 'nil';					# Storing the log file name
my $log_status = 'passed';				# It holds the status of the test as either passed or failed.
my $vip_library ='nil';					# It stores the file name containing the vip_lib content 
my $no_of_licenses= 2;					# Default taken as 2 and it can be changed by the user.
my $excel='nil';					# Checks for excel 
my $options='nil';					# Extra options to be added.
my $opt_error='nil';					# Extra optional errors can be inspected
my $opt_error_exclude='nil';				# Optional errors to be excluded can be inspected
my $coverage = 'nil';					# Stores the coverage options file
my $queue = 'default';					# Stores the type of queue if given by user
my $user_input_licenses = 0;				# Stores the number of licenses from the user if given
my $vip_change_dir = 'nil';				# Stores the directory where the vip_lib content to be stored and executed
my $lib_link = 'nil';
my $lib_link_file = 'nil';
my $language= 'nil';
#=======================================================================================================================================================
# Additional Variables used for adding information into the log and error files 
#========================================================================================================================================================
my @error_count;				 	# Stores the count of the words that have to checked in the log file for error
my @error_exclude_count;				# Stores the count of the words which are errors but have to be excluded
my @error_word;						# Store the words that have to be checked in the log file for error
my @error_exclude_word;					# Store the words that have to be excluded from the error
my @er_op_fh;
my @keyss;
my @assertion_error;
my $fatal=0;						# Counting and storing the number of fatal errors(UVM_FATAL/OVM_FATAL) in this variable
my $warning=0;						# Counting and storing the number of warnings(UVM_WARNINGS/OVM_WARNINGS) in this variable
my $error=0; 						# Counting and storing the number of errors(UVM_ERROR/OVM_ERROR) in this variable
my $optional_error=0;					# Counting and storing the number of optional_errors in this variable if provided bý user
my %hash_error;
my @define_list;					# Stores the define words if given through the regression list					
my @vip_fh;						# Stores the content of the vip_lib content file
my $error_count_file = 'error_count.fl';		# The file to store the no of errors in the log file 
my $error_exclude_count_file = 'error_exclude_count.fl';# The file to stores the no of errors to be excluded from the log file 
my %hash_list;						# Storing the optional error words(with special characters) with it's count in the hash 
my %hash_exclude_list;					# Storing the optional error exclude word(with special characters) with it's count in the hash
my %hash_list_sp;					# Storing the optional error words with it's count in the hash 
my %hash_exclude_list_sp;				# Storing the optional error exclude word with it's count in the hash
#==========================================================================================================================================================
# Additional Variables used for adding information into the excel file
#==========================================================================================================================================================
my $total_passed = 0;					# Storing the number of passed tests
my $total_failed = 0;					# Storing the number of failed tests
my $total_passed_and_failed = 0;			# Storing the total number of tests
my $test_name_1;					
my @test_name_bunch;
my $count_reg = 0;					# Counting the number of tests in the file
my $count_grep = 0;					# Counting the number of log files that have been processed for information collection
my $count_diff = 0;					# Counting the difference of above two variables
my @all_sim_time;
#========================================================================================================================================================
# To read from a recevied file the mandatory and optional options for test and regression and store them in an array @option_array
#========================================================================================================================================================
sub retrieve						
{
	my @option_array,my $rcv_fh,my $row,my $rcv_file=$_[0]; 	
	open($rcv_fh,'<',$rcv_file) or 
	die " The file $rcv_file does not exist. Copy it from the orginal script folder\n";
	while( $row =<$rcv_fh>)				# Reading it line by line
	{	
		chomp($row);				# Removing the newline character for making lines into words
		push(@option_array,$row);		# Storing them in an array
	}
	return @option_array;				# Returning the new array to the variable 
}
#========================================================================================================================================================
#Pass the text files which hold the Mandatory and optional options and store them in their respective arrays
#========================================================================================================================================================
my @mandatory_single=retrieve('mandatory_single.txt');			# Storing the mandatory single options that are given in the file
my @mandatory_regression= retrieve('mandatory_regression.txt');		# Storing the mandatory regression options that are given in the file
my @mandatory_compile= retrieve('mandatory_compile.txt');		# Storing the mandatory compile options that are given in the file
my @optional_single=retrieve('optional_single.txt');			# Storing the optional single options that are given in the file
my @optional_regression=retrieve('optional_regression.txt');		# Storing the optional regression options that are given in the file
my @single_options=(@mandatory_single,@optional_single);		# Storing both mandatory and optional options for single test in one array
my @regression_options=(@mandatory_regression,@optional_regression);	# Storing both mandatory and optional options for regression test list in one array
my @received_options;							# This array holds all the options entered by the user.
my $boolean='compile';							# Stat executes the statement only once and $boolean is 'compile'.
#========================================================================================================================================================
#Directories.
#========================================================================================================================================================
my $top_dir;						# Stores the path of the ../verification directory of the root projet structure.
my $current_dir;					# Stores the path of the ../scripts directory .
my $log_dir;						# Stores the path of the ../regression directory .
my $sim_dir;						# Stores the path of the ../sims directory .
my $vip_lib_dir;
my $workbook;						# Stores the excel workbook name which holds the final excel report
my $worksheet1;							
my $rw = 2;						# To keep track of the $row_count while entering data into the excel worksheet
my $report_file;					# To store the excel report.
my $vip_library_dir = 'vip_lib';			# The vip_lib directory path is stored
#========================================================================================================================================================
#Initialising the paths to the different directory variables accordingly
#========================================================================================================================================================
# Paths are stored------------------------------------------------------------------------------------------------------------------------------------------------
$current_dir = cwd();					# Current Working Directory path is stored
my @temp=split('/',$current_dir); 			# Split the entire path and stores in array
pop(@temp);						# Deletes the last element of the array
$top_dir=join('/',@temp);				# Join them again and without the last element, i.e., the directory above the current directory 
$sim_dir=$top_dir."/sim";				# Simulation directory path is stored
$vip_lib_dir = $sim_dir;				# vip_lib directory path is stored
$log_dir=$top_dir."/regression";			# Log file directory path is stored
# Directories are created-----------------------------------------------------------------------------------------------------------------------------------------
create_dir($sim_dir);					
create_dir($log_dir);
create_dir($sim_dir.'/rtl_sim');
create_dir($sim_dir.'/cov_sim');
create_dir($log_dir.'/rtl_sim');
create_dir($log_dir.'/cov_sim');
# Subroutine used for creating directories-------------------------------------------------------------------------------------------------------------------------
sub create_dir
{
	my $temp_dir = $_[0];							# Stores the name of the directory to be created
	if (-d $temp_dir)							# checks whether the directory to be created exists
	{
		 print "Directory $temp_dir exists, not creating it. \n";	# Displays an appropiate message
	}
	else	
	{
		mkpath  "$temp_dir";						# Makes the required directory if it doesn't exist
		print "Directory $temp_dir does not exist, creating it. \n";
	}
}
# To find out the user of the project------------------------------------------------------------------------------------------------------------------------------
my $user = $ENV{"USER"};					# Returns the current users name.
my @user =split('',$user);					# Splits the name into letters
if( scalar @user > 16 )						# Checks whether the name has more then 16 characters
{
	$user = '';
	my $char_count ;
	for ( $char_count = 0 ; $char_count < 16; $char_count ++)
	{
		$user=$user.$user[$char_count];
	}
}								# If user has more than 16 characters then only first 16 characters are taken
print " User is $user \n";
#========================================================================================================================================================
#This method receives the different options specified below, from the command line when the script is executed.
#As and when the user enters a particular option, the script jumps to the corresponding subroutine and executes the task in it.
#========================================================================================================================================================
GetOptions( 	
	"regression=s"		=>\&regression,
	"test=s"		=>\&test,
	"verbosity=s"		=>\&verbosity,
	"seed=s"		=>\&seed,
	"stop_time=s"		=>\&stop_time,
	"frtl=s"		=>\&frtl,
	"ftb=s"			=>\&ftb,
	"tool=s"		=>\&tool,
	"inclist=s"		=>\&inclist,
	"dump=s"		=>\&dump,
	"vtimescale=s"		=>\&vtimescale,
	"log=s"			=>\&log,
	"opt_error=s"		=>\&opt_error,
	"opt_error_exclude=s"	=>\&opt_error_exclude,
	"vip_library=s"		=>\$vip_library,
	"gui"			=>\&gui,
	"pbs"			=>\&pbs,
	"excel"			=>\$excel,
	"deflist=s"		=>\&deflist,
	"sim_mode=s"		=>\&sim_mode,	
	"licenses=i"		=>\$user_input_licenses,
	"queue=s"		=>\$queue,
	"options=s"		=>\&options,
	"coverage=s"		=>\&coverage,
	"vip_change_dir"	=>\$vip_change_dir,
	"lib_link"		=>\$lib_link,
	"lib_link_file=s"	=>\&lib_link_file,
	"language=s"		=>\&language,
	"help=s"		=>\&help, ) or help();		# If any user options are not in the list or if there are no options specified for an option.
								# An error is thrown accordingly and The help file is called and the program dies.
#========================================================================================================================================================
#This subroutine validates if the received  file or directory  argument exists
#========================================================================================================================================================
sub file_exist
{
	if (-e $_[0])							# Checks if the file exists.
	{  
		if(-R $_[0]){}						# Checks if the file is readable.
		else
		{
			die "\n\nError:File $_[0] is not readable.\n";	# Prints an error message if the file is not readable
		}
	}				
	else	
	{
		die "\n\nError:File :$_[0] does not exist.\n";          # Error thrown if file does not exist.
	}	
}
#========================================================================================================================================================
# Depending on the received options or options entered by the user, these subroutines are called.
#========================================================================================================================================================
sub regression
{	
	$valid_reg = 'true';			# This flag is used as an indication that the user entered regression.
	$select = 'reg';			# The mode of operation is selected as regression.
	$reg_file=$current_dir.'/'.$_[1];	# Appending the full path to the regression file.
	file_exist($reg_file);			# Checking if the regression filelist file exists and if it is readable
	$reg_file=$_[1];			# Storing the regress filelist name without the whole path , to create the sim_dir later.
	push(@received_options,$_[0]);		# Storing the received option regression in an array.
	
}
#------------------------------------------------------------------------------------------------------------------------------------
sub test
{
	
	$valid_test='true';			# This flag is used as an indication that the user entered regression.
	$select='test';				# The mode of operation is selected as regression.
	$test_name_single=$_[1];		# The single test case name is stored in this variable.
	push(@received_options,$_[0]);		# Storing the received option test in an array.
}
#------------------------------------------------------------------------------------------------------------------------------------
sub verbosity
{
	$verbosity= $_[1];			# The verbosity value is stored in this array.
	push(@received_options,$_[0]);		# Storing the received option uvm_verbostiy in an array.
}
#------------------------------------------------------------------------------------------------------------------------------------
sub gui
{
	$gui = $_[1];				# The gui is set in this variable.
	push(@received_options,$_[0]);		# Storing the received option gui in an array.
	
}
#------------------------------------------------------------------------------------------------------------------------------------
sub pbs
{
	$pbs = $_[1];				# The pbs is set in this variable.
	push(@received_options,$_[0]);		# Storing the received option pbs in an array.
	
}
#------------------------------------------------------------------------------------------------------------------------------------
sub seed
{
	$seed = $_[1];				# The seed value is stored in this variable.
	push(@received_options,$_[0]);		# Storing the received option seed in an array.
}
#------------------------------------------------------------------------------------------------------------------------------------
sub options
{
	$options = $_[1];			# The options file is saved in this variable.
	$options=$current_dir.'/'.$options;	# The full path is prepended to the inclist file name.
	file_exist($options);			# Checking if the options filelist file exists and if it is readable.
	push(@received_options,$_[0]);		# Storing the received option options in an array.
}
#------------------------------------------------------------------------------------------------------------------------------------
sub stop_time
{
	$stop_time = $_[1];			# The simulation stop time is stored in this variable.
	push(@received_options,$_[0]);		# Storing the received option stop_time in an array.
}
#------------------------------------------------------------------------------------------------------------------------------------
sub dump
{
	$dump=$current_dir.'/'.$_[1];		# Appending the full path to the .tcl file
	push(@received_options,$_[0]);		# Storing the received option dump in an array
	my $dump_fh;				# Printing exit as the last line in the tcl file.
	open($dump_fh,'>>',$_[0]);		# Opening the dump file in append mode 
	print $dump_fh "\nexit";		# Adding the word 'exit' at last
	close $dump_fh;				# Closing the dump file
}
#------------------------------------------------------------------------------------------------------------------------------------
sub log
{
	$log = $_[1];				# The log file name is stored in this variable
	push(@received_options, $_[0]);		# Storing the received option log in an array
}
#------------------------------------------------------------------------------------------------------------------------------------
sub vtimescale
{	
	$vtimescale = $_[1];			# The vtimescale is stored in this variable.
	push(@received_options,$_[0]);		# Storing the received option vtimescale in an array
}
#------------------------------------------------------------------------------------------------------------------------------------
sub inclist
{
	$inclist = $_[1];				# The inclist file is saved in this variable.
	$inclist=$current_dir.'/'.$inclist;		# The full path is prepended to the inclist file name.
	file_exist($inclist);				# Checking if the inclist filelist file exists and if it is readable.
	push(@received_options,$_[0]);			# Storing the received option inclist inclist in an array.
}
#-----------------------------------------------------------------------------------------------------------------------------------
sub deflist 
{
	$deflist = $_[1];				# The deflist file is saved in this variable.
	$deflist=$current_dir.'/'.$deflist;		# The full path is prepended to the deflist file namne.
	file_exist($deflist);				# Checking if the define filelist file exists and if it is readable
	push(@received_options,$_[0]);			# Storing the received option deflist in an array.
}
#------------------------------------------------------------------------------------------------------------------------------------
sub ftb
{
	$ftb = $_[1];					# The TB filelist is saved in this variable
	$ftb =$current_dir.'/'.$ftb;			# The full path is prependede to this TB filelist
	file_exist($ftb);				# Checking if the TB filelist file exists and if it is readable.
	push(@received_options,$_[0]);			# Storing the received option ftb  in an array
}
#------------------------------------------------------------------------------------------------------------------------------------
sub frtl
{
	$frtl = $_[1];					# The RTL filelist file is saved in this variable.
	$frtl=$current_dir.'/'.$frtl;			# The full path is prepended to the RTl filelist file.
	file_exist($frtl);				# Checking if the RTL filelist file exists and if it is readable.
	push(@received_options,$_[0]);			# Storing the received option in an array.
}
#------------------------------------------------------------------------------------------------------------------------------------
sub opt_error
{
	$opt_error = $_[1];				# The optional error file is saved in this variable.
	$opt_error = $current_dir.'/'.$opt_error;	# The full path is prepended to the optional error file namne.
	file_exist($opt_error);				# Checking if the optional error file exists and if it is readable
	push(@received_options,$_[0]);			# Storing the received option optional error in an array.
}
#------------------------------------------------------------------------------------------------------------------------------------
sub opt_error_exclude
{
	$opt_error_exclude = $_[1];					# The optional error exclude file is saved in this variable.
	$opt_error_exclude = $current_dir.'/'.$opt_error_exclude;	# The full path is prepended to the optional error exclude file namne.
	file_exist($opt_error_exclude);					# Checking if the optional error exclude file exists and if it is readable
	push(@received_options,$_[0]);					# Storing the received option optional error exclude in an array.
}
#------------------------------------------------------------------------------------------------------------------------------------
sub coverage
{
	$coverage = $_[1];
	$coverage = $current_dir.'/'.$coverage;
	file_exist($coverage);
	push(@received_options,$_[0]);
}
#------------------------------------------------------------------------------------------------------------------------------------
sub queue
{
	$queue = $_[1];
	push(@received_options,$_[0]);
}
#------------------------------------------------------------------------------------------------------------------------------------
sub lib_link_file
{
	$lib_link_file = $_[1];
	$lib_link_file = $current_dir.'/'.$lib_link_file;
	file_exist($lib_link_file);
	push(@received_options,$_[0]);
}
#------------------------------------------------------------------------------------------------------------------------------------
sub language
{
	$language = $_[1];
	push(@received_options,$_[0]);
}
#------------------------------------------------------------------------------------------------------------------------------------
sub sim_mode
{	
	my @legal_sim_mode = qw(rtl_sim compile cov_sim);	# This array contains the values which are allowed as arguements for the sim_mode option.
	$sim_mode=$_[1];					# The sim_mode is saved in this variable.
	if (grep { $_ eq $sim_mode } @legal_sim_mode)		# This checks if the received option is valid and allowed option or not
	{							# Currently only rtl_sim and compile are funcitonal, and accordingly
								# log and sim dirs are appended, the gate and cov simulations can be added.
		switch($sim_mode)						
		{
			case 'compile' 
			{						
				$select='compile';		
				$sim_dir=$sim_dir.'/rtl_sim'; 	
				$log_dir=$log_dir.'/rtl_sim';	
			}
			case 'rtl_sim'  
			{	
				$sim_dir=$sim_dir.'/rtl_sim';	
				$log_dir=$log_dir.'/rtl_sim';
			}
			case 'cov_sim'  
			{	
				$sim_dir=$sim_dir.'/cov_sim';	
				$log_dir=$log_dir.'/cov_sim';
			}
		}
		push(@received_options,$_[0]);			# The recevied option sim_mdoe is stored in the array.
	}
	else
	{
		print "\n Error: Wrong option for sim_mode.\n Specify one of the following @legal_sim_mode\n";	# Error message is printed if the received option argument is not valid and the program dies.
		die("\n");
	}
}
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
sub tool
{
	my @legal_tool = qw(modelsim ncsim vcs);		# These are the allowed options for tool.
	if ( grep { $_ eq $_[1] } @legal_tool)			# The user entered value is compared with the legal/allowed values.
	{
		$tool=$_[1];					# The tool value is stored in this variable.
		push (@received_options,$_[0]);		     	# Storing the received option tool in an array
	}
	else
	{
		print "\nerror: must specify one of the following arguments for \"-tool \" \n@legal_tool\n"; 	#Error message is printed if the user enters an invlaid value allowed for tool.
		die "\n";
	}
}
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
sub help
{
	my $help_text=$current_dir.'/help.txt';			# Prepends the full path to the help,txt file.
	file_exist($help_text);					# Checls if the help file exists.
	system("cat $help_text");				# Displays the help fiule on the console file.
	die("\n");						# Kills the program.
}
#========================================================================================================================================================================
# DATE AND TIME
#This subroutine is used to return date and time in the @return array.
#It is currently not used and can be used if needed, as the sim date and time 
#is grepped from the irun.log file itself.
#========================================================================================================================================================================
sub get_date_time	
{
	my $date=strftime "%d-%m-%Y",localtime;		# Command to retrieve  date in dd/mm/yyy format.
	my $time=strftime "%T",localtime;		# Command to retrive time.
	my @time=split(' ',$time);			
	my @return;
	push(@return,$date);
	push(@return,$time[0]);
	return @return;					# Returns the date and time found.
}
#===========================================================================================================================================================================
# MISSING_SINGLE_TEST
# This is to check if any mandatory options for single test are not specified 
#===========================================================================================================================================================================
sub missing_test
{
	my @missing;						# Array to store the missing mandatory options 
	foreach my $variable(@mandatory_single)			
	{				
		push (@missing,$variable) unless grep { $_ eq $variable } @received_options;	# If any of the mandatory options are not in the received list of options, they are pushed to @missing.
	}		
	if(scalar @missing != 0)				# If there are missing options, print Error message.
	{
		print "\nError:Mandatory Options to run a single test is not specified.\nThe missing options is/are @missing.\n"; 
		help();
	}		
	foreach my $variable (@received_options)		# If any variable in the revceived option list is not optional for single test, an error is thrown.
	{
		print "\nError:The option specified $variable is not a valid optional variable for single.\n" and help()  unless grep { $_ eq $variable } @single_options;
	}
}
#===========================================================================================================================================================================
# MISSING_REGRESSION_TEST
# This is to check if any mandatory options for regression test are not specified
#===========================================================================================================================================================================
sub missing_reg
{
	my @missing;											# Array to store the missing mandatory options
	foreach my $variable(@mandatory_regression)
	{
		push(@missing,$variable) unless grep { $_ eq $variable } @received_options;		# If any of the mandatory options are not in the received list of options, they are pushed to @missing.
	}
	if(scalar @missing != 0)							# If there are missing options, print Error message.				
	{	
		print "\nError:Mandatory Options to run a regression test is not specified.\nThe missing option is/are @missing.\n";
		help();
	}
	foreach my $variable (@received_options)			# If any variable in the revceived option list is not optional for single test, an error is thrown.
	{
		print "\nError:The option specified $variable is not a valid optional variable for regression test.\n" and help() unless grep { $_ eq $variable } @regression_options;
	}
}
#======================================================================================================================================================================================
# MISSING_COMPILE_TEST
# This is to check if all mandatory options for compile mode are specified or not
#======================================================================================================================================================================================
sub missing_compile
{
	my @missing;							# Array to store the missing mandatory options
	foreach my $variable(@mandatory_compile)
	{
		push (@missing,$variable) unless grep {$_ eq $variable } @received_options;	# If any of the mandatory optins are not in the received list of options, they are pushed to @missing

	}
	if(scalar @missing != 0)					# If there are missing options print the Error Measage
	{
		print "\n Error : Mandatory options to compile the test are not specified\n. The missing options is/are @missing \n";
		help();
	}
}
#======================================================================================================================================================================================
# INITIALIZE THE DIRECTORY
# This initializes the sim_directory and the regression directory
#======================================================================================================================================================================================
sub init_dir
{	
	my $sub_dir_name = $_[0];							# Receive the sub_directory name . Eg : reglist_8.fl, reglist_16.fl, single_test.
	my $remove;
	if (($select eq 'compile' and $valid_reg eq 'true') or ($select eq 'reg'))	# If not compile and not single test, in other words if only regression: then chop ".fl" extention.
	{
		chop ($sub_dir_name);
		chop ($sub_dir_name);
		chop ($sub_dir_name);
	}
	$sim_dir=$sim_dir.'/'.$sub_dir_name;						# Prepend the entire path to the received sub_directory_name.
	if (-e $sim_dir)								# Check if the sub_directory exists.
	{	
		chdir $sim_dir;								# Change directory to the sub_dir.
		opendir (my $dh, $sim_dir) or die "failed \n";				# Open a Directory file handle.

		my @dirs = grep { -d "$sim_dir/$_" && ! /^\.{1,2}$/ } readdir ($dh);	# Read all the directries in it into @dirs array.

			foreach my $dir_name ( @dirs)		
			{	
				if ( ($dir_name ne 'common_libs')  and ($sub_dir_name ne 'single_test' ))	# Remove all directories except the common_libs.
				{
					$remove = $sim_dir.'/'.$dir_name ;
					rmtree( $remove ) or die "could not remove \n";
				}
				if ( ($dir_name eq 'common_libs') )			# Remove all directories except the common_libs.
                                {
					$remove = $sim_dir.'/'.'common_libs'.'/'.'INCA_libs' if($tool eq 'ncsim');
					$remove = $sim_dir.'/'.'common_libs'.'/'.'work' if($tool eq 'modelsim');
					if (-e $remove) 
					{
					  rmtree( $remove ) or die "could not remove  $remove\n";
                                        }
                                } 
			}
		close $dh;
	}
	else										
	{	
		mkpath "$sim_dir" or die "Could not create $sim_dir\n";			# If sub_directory does not exist, create it.
	}
	$log_dir=$log_dir.'/'.$sub_dir_name;						# Prepend the entire path to the log_sub_directory.
	if (-e $log_dir)								# Check if it exists
	{
		rmtree $log_dir or die "Could not remove $log_dir\n";			# If it does , clear all data in it by deleting it.
	} 
	mkpath "$log_dir" ; 								# Re-create it . create failed, passed and report directories inside of it.
	my $failed = $log_dir.'/failed';						# Failed Directory path
	my $passed = $log_dir.'/passed';						# Passed Directory path
	my $report = $log_dir.'/report';						# Report Directory path
	mkpath("$failed");								# Creating Failed Directory 
	mkpath("$passed");								# Creating Passed Directory 				
	mkpath("$report");								# Creating Report Directory 
	chdir $current_dir;								# Change back to current direcotry.
}
#======================================================================================================================================================================================
# VIP_LIB CREATION
#=========================================================================================================================================================================
sub vip_library
{
	my $vip_dir = $_[0];								# Path for vip_lib is stored
	print " The directory is $vip_dir \n\n";
	chdir $vip_dir;									# Directory changed to the vip_lib 
	my $exe = 'create_vip.sh';							# A new file is made
	
	# If vip_lib directory exist, it just uses it
	if (-d "$vip_library_dir")
	{
		print "vip_lib Exists. Not creating again \n";
	}
=pod	
	else
	{
		print "vip_lib does not exist, Creating it again \n"; 
		open(my $fh,'>',$exe);
		print $fh "cd $vip_dir\n";
		print $fh '${CDN_VIP_ROOT}/bin/cdn_vip_setup_env -cdnautotest -s ncsim_irun -cdn_vip_root ${CDN_VIP_ROOT} -m sv_uvm -csh -cdn_vip_lib '.$vip_library.' -i axi';
		close $fh;
		my $mode = 0777;				# Make the file executable
		chmod $mode, "$exe";			
		print " The file name is $exe \n";
		system ("./$exe");
	}
=cut
	# Else a new directory is created
	else
	{
		print "vip_lib does not exist, Creating it again \n"; 
		chdir $current_dir;							# Changes to the current directory
		my $vip_fh;								# File handle for vip_lib file
		open ($vip_fh,'<',$vip_library);					# Opening the vip_lib file present in the CWD in read mode
		@vip_fh = <$vip_fh>;							# All content is stored in an array 
		close $vip_fh;								# Closing the file
		chdir $vip_dir;								# Changes to the vip_lib directory
		open($vip_fh,'>',$exe);							# Opening the vip_lib file in write mode in vip_llib directory
		# Content is written inside this file
		print $vip_fh "cd $vip_dir\n";						
		foreach my $elements (@vip_fh)
		{
			print $vip_fh "$elements";
		}
		close $vip_fh;								# Closing the file	
		my $mode = 0777;							# The mode in which we want to change
		chmod $mode, "$exe";							# Changing the file into executable mode for user, owner and group
		print " The file name is $exe \n";					 
		system ("./$exe");							# Executing the file
	}	
}
#==========================================================================================================================================================================
# Create a directory for the corresponding test_name
#==========================================================================================================================================================================
sub create_dir_test_name
{
	my $test_name = $_[0];
	my $new_dir   = $sim_dir.'/'.$test_name;
	if (-e $new_dir)
	{
	}
	else
	{
		#print "Directory $new_dir does not exist , so creating it \n";			
		mkpath ("$new_dir") or die "Could not create directory $new_dir \n";
	}
}
#==========================================================================================================================================================================
# CREATE_LOG
# To copy the log file generated to the log file folder and grep the required info and save it in report.xls
#==========================================================================================================================================================================
sub create_log		
{
	my $test_name_single=$_[0];						# Store the test case name in this variable.
	my $test_dir_name=$_[1];						# Store the sub_simulation_directory name in this varaible.
	my $log_irun_dir=$sim_dir.'/'.$test_dir_name;		
	chdir $log_irun_dir or die "Failed to change to $log_irun_dir\n";	# Navigate to the directory where the simulation is taking place.	
	if ( $log ne 'nil')							# If User has specified log name through options change the log file name.
	{
		$test_name_single = $log;
	}
# Opening and reading the log file-----------------------------------------------------------------------------------------------------------------------------------------
	my @log_list;								# To store all the lines in the generated test_name.log file into the @log_list array
	my $log_fh_1;								# File_handle to open the test_name.log file.
	my $irun_log_file = $log_irun_dir.'/'.$test_name_single;		# Prepend the test case name with the directroy whrere the log file will be placed.
	file_exist("$irun_log_file");						# Check if the log file exists
	open($log_fh_1,"$irun_log_file");						
	@log_list=<$log_fh_1>;							# Read all the lines in the log file into the @log__list array.
# CPU Usage----------------------------------------------------------------------------------------------------------------------------------------------------------------
	my $cpu_use=retrieve_log_info(@log_list,"ncsim: CPU Usage","Usage",2,'end');	# CPU Usage is grepped from the log file and the sub routine retirve_log_info , returns the values.
	if ($cpu_use eq '')
	{	
		goto NEXT;
	}
#Start Time and Date--------------------------------------------------------------------------------------------------------------------------------------------------------
	NEXT:
	my $start_time=retrieve_log_info(@log_list,"Started on","at",1,2); 	# start time is grepped from the log file and the sub routine retirve_log_info , returns the values.
	my $start_date=retrieve_log_info(@log_list,"Started on","at",-3,0);	# start date is grepped from the log file and the sub routine retirve_log_info , returns the values.
#Stop Time and Date---------------------------------------------------------------------------------------------------------------------------------------------------------
	my $end_time=retrieve_log_info(@log_list,"Exiting on","at",1,2);	# end time is grepped from the log file and the sub routine retirve_log_info , returns the values.
	my $stop_date=retrieve_log_info(@log_list,"Exiting on","at",-3,0);	# end date is grepped from the log file and the sub routine retirve_log_info , returns the values.
	my $tot_sim=retrieve_log_info(@log_list,"Exiting on","at",4,5);		# total sim time is grepped from the log file and the sub routine retirve_log_info , returns the values
	chop $tot_sim;								# Chop to remove any trailing character
#Modifications in the simulation time--------------------------------------------------------------------------------------------------------------------------------------
	#my $tot_sim_1="1:00:00".$tot_sim;
	#my ($day,$month,$year,$hour,$min,$sec)=split(/:/, $tot_sim_1);
	#$tot_sim_1= timelocal ($sec,$min,$hour,$day,$month,$year);
	#$tot_sim_1= strftime "%T", localtime $tot_sim_1;
	#$tot_sim = $tot_sim_1;	
	#substr ($tot_sim,0,2) = "";
# Calculating total simulation time-----------------------------------------------------------------------------------------------------------------------------------------
	substr ($tot_sim,0,1) = "";
	my @tot_sim = split //,$tot_sim;
	if ($tot_sim[0] == 0)
	{
		$tot_sim[0] = '';
	}
	$tot_sim = join ('',@tot_sim);
	push (@all_sim_time, $tot_sim);
	#@tot_sim = split ("", $tot_sim);
# Passed or Failed, LOG_STATUS----------------------------------------------------------------------------------------------------------------------------------------------
	my $assertion_error_match =  '\*E';
	@assertion_error = grep / $assertion_error_match/,@log_list;
	$error=retrieve_log_info(@log_list,"UVM_ERROR :",":",1,2) if ($language eq 'UVM');
	$fatal=retrieve_log_info(@log_list,"UVM_FATAL :",":",1,2) if ($language eq 'UVM');
	$warning=retrieve_log_info(@log_list,"UVM_WARNING :",":",1,2) if ($language eq 'UVM');
	$error=retrieve_log_info(@log_list,"OVM_ERROR :",":",1,2) if ($language eq 'OVM');
	$fatal=retrieve_log_info(@log_list,"OVM_FATAL :",":",1,2) if ($language eq 'OVM');
	$warning=retrieve_log_info(@log_list,"OVM_WARNING :",":",1,2) if ($language eq 'OVM');
	substr ($warning,0,1) = ""; 
	my $copy=retrieve_log_info(@log_list,"Copyright ","Copyright",1,2);
	$optional_error = opt_error_info($log_irun_dir, $irun_log_file)	if ($opt_error ne 'nil');
	if (($error + $fatal + scalar @assertion_error + $optional_error) > 0)
	{
		$log_status = 'failed';
		print "$test_dir_name is FAILED status 1 working\n";
		$total_failed = $total_failed + 1;
		$total_passed_and_failed = $total_passed_and_failed + 1;
	}
	elsif (($error + $fatal + scalar @assertion_error) > 0 )	# If any fatal/errors are there in the log file; store the log file in failed folder and update status as failed
	{
		$log_status = 'failed';
		print "$test_dir_name is FAILED status 2 working\n";
		$total_failed = $total_failed + 1;
		$total_passed_and_failed = $total_passed_and_failed + 1;
	}
	elsif (($stop_date eq ''))
	{
		$log_status = 'failed';
		print "$test_dir_name is FAILED status 3 working\n";
		$total_failed = $total_failed + 1;
		$total_passed_and_failed = $total_passed_and_failed + 1;
	}
	#elsif ($copy eq " 1995-2014")
	#{
	#	$log_status = 'passed';
	#	print "Passed status working\n";
	#	$total_passed = $total_passed + 1;
	#	$total_passed_and_failed = $total_passed_and_failed + 1;
	#}
	#elsif ($denali_error_difference > 0)
	#{
	#	$log_status = 'failed';
	#	print "$test_dir_name is FAILED status 4 working\n";
	#	$total_failed = $total_failed + 1;
	#	$total_passed_and_failed = $total_passed_and_failed + 1;
	#}
	else
	{
		print "$test_dir_name is PASSED\n";
		$log_status = 'passed';
                system "rm -rf $log_irun_dir/*.vcd $log_irun_dir/*.shm";
		$total_passed = $total_passed + 1;
		$total_passed_and_failed = $total_passed_and_failed + 1;
	}
#Get SVSEED VALUE-------------------------------------------------------------------------------------------------------------------------------------------------------
	my $match="SVSEED";							# Match saves the word which is to be looked up in the log file
	my $seed = '';								
	my @match = grep /$match/,@log_list;					# All the lines which has the term SVSEED is stored in @match
	@match=split('',$match[0]);						# The first such line is split up
	my $count,my $stall;							
	foreach my $b(@match)							# Itereate over each element in the line
	{	
		if ($b eq ':')							# as soon as " : " is found, store the index in stall
		{
			$stall=$count;						
		}
		$count ++;							# Increment Count to keep track of index of each element in the array.
	}
	for ($count = ($stall+2); $count < scalar @match; $count ++)		# Print the seed value by using the 'stall' value saved from the previous iteration
	{	
		$seed=$seed.$match[$count];					# Check out a sample log file for more information.
	}	
	$seed =~ s/|s+$//;							# Remove any white spaces to the right
	chomp $seed;								# Remove trailing new line characters

# Retriving the test name by chopping off the extra 4 characters used while creating the file plreq.log------------------------ ----------------------------------------
	#my $repeat = 4;
	#while ( $repeat > 0 )
	#{
	#	chop $test_name_single;
	#	$repeat --;
	#}
	if ($log eq 'nil')
	{
		@test_name_bunch = split ('_',$test_name_single);
		pop(@test_name_bunch);
		$test_name_1 = join('_',@test_name_bunch);
	}
	else
	{
		my $repeat = 4;
		while ( $repeat > 0 )
		{
			chop $test_name_single;
			$repeat --;
		}
		$test_name_1 = $test_name_single;
	}
# To shift the name of the test case in case the user gives single test option
	if ($select eq 'test')
	{
		$test_name_1 = $test_name_single;
	}
# Update the excel file-------------------------------------------------------------------------------------------------------------------------------------------------
	if ($excel ne 'nil')
	{ 
		eval "use Spreadsheet::ParseExcel;"; 				#ParseExcel is used to read data from rows and columns from excel worksheets.
		eval "use Spreadsheet::ParseExcel::SaveParser;";		#SaveParser is used to dynamically update the excel when the script is running
		my $parser = Spreadsheet::ParseExcel::SaveParser->new();		# Create a new SaveParser and save it in $parser.
		my $wb = $parser->Parse("$report_file");				# Use $parser to open the initially created excel file $report_file.
		my $wk = $wb->worksheet(0);						# navigate to the first worksheet in the excel file.
		#my $format = $wb->add_format();
		#my @formats;
		#push (@formats, [0x15, 36892.521, 0, 'h:mm:ss']);
		#my $cw = 1;						
		#$wk->AddCell($rw,$cw++,$rw-1);						# Write the Sl No.
		#$wk->AddCell($rw,$cw++,$test_name_1);					# Write the test case name
		#$wk->AddCell($rw,$cw++,uc($log_status));				# Write the log_status passed or failed
		#$wk->AddCell($rw,$cw++,$seed);						# Write the seed value
		#$wk->AddCell($rw,$cw++,$warning);					# Write the seed value
		#$wk->AddCell($rw,$cw++,$tot_sim);					# Write the tot sim time
		#$wk->AddCell($rw,$cw++,$start_time);					# Write the start time
		#$wk->AddCell($rw,$cw++,$end_time);					# Write the end time
		#$wk->AddCell($rw,$cw++,$start_date);					# Write the start _date
		#$wk->AddCell($rw,$cw++,$stop_date);					# Write the stop_date
		#$wk->AddCell($rw,$cw++,$cpu_use);					# Write the CPU USAGE
		my $cw = 0;						
		$wk->AddCell($rw,++$cw,$rw-1);						# Write the Sl No.
		$wk->AddCell($rw,++$cw,$test_name_1);					# Write the test case name
		$wk->AddCell($rw,++$cw,uc($log_status));				# Write the log_status passed or failed
		$wk->AddCell($rw,++$cw,$seed);						# Write the seed value
		$wk->AddCell($rw,++$cw,$warning);					# Write the seed value
		$wk->AddCell($rw,++$cw,$tot_sim);					# Write the tot sim time
		$wk->AddCell($rw,++$cw,$start_time);					# Write the start time
		$wk->AddCell($rw,++$cw,$end_time);					# Write the end time
		$wk->AddCell($rw,++$cw,$start_date);					# Write the start _date
		$wk->AddCell($rw,++$cw,$stop_date);					# Write the stop_date
		$wk->AddCell($rw,++$cw,$cpu_use);					# Write the CPU USAGE
		$rw++;									# GO to the next row, to add the next log file details.
		$wb->SaveAs("$report_file");						# Save the report file after appending details about each test case.
	}
#Create, copy and adding information in the log file-------------------------------------------------------------------------------------------------------------------------------------------
	if ($select eq 'reg')	
	{
		my @stop_date = split (' ',$stop_date);
		my $log_name= '';
		chop $stop_date[1];
		$stop_date=join ('_',@stop_date);
		$end_time =~ s/^\s+//;
		$log_name=$test_name_1."_".$seed."_".$stop_date."_".$end_time.'.log';
		my $log_final_file = $log_dir.'/'.$log_status.'/'.$log_name;			# Append all the details to log file name_seed_stopdate_endtime	
		my $log_final_dir = $log_dir.'/'.$log_status;
		copy("$irun_log_file","$log_final_file") or die "Failed copy of irun.log\n";	# Copy the log file into the passed or failed directory
		if ($log_status eq 'failed')
		{
			error_text_file($log_final_dir, $log_name, $log_irun_dir);
		}	
		if (scalar @assertion_error != 0)
		{
			assertion_error_write ($log_final_dir, $log_name, $log_irun_dir);
		}
		opt_error_write ($log_final_dir, $log_name, $log_irun_dir);
		status_write ($log_final_dir, $log_name, $log_irun_dir);
		log_zip ($log_final_dir, $log_name, $log_irun_dir);
		if ($coverage ne 'nil') 
		{
			mkpath ("$log_final_dir/$test_dir_name") or die "Could not create directory $log_final_dir/$test_dir_name \n";
			system "cp -rf $log_irun_dir/cov_work  $log_final_dir/$test_dir_name/.";
			system "rm -rf $log_irun_dir/cov_work";
                }
		splice (@error_count);	
		splice (@error_word);
		splice (@error_exclude_count);
		splice (@error_exclude_word);
		undef (%hash_list);
		undef (%hash_exclude_list);
		undef (%hash_list_sp);
		undef (%hash_exclude_list_sp);	
	}
	else 
	{
		if ($log_status eq 'failed')
		{	
			error_text_file($log_irun_dir, $irun_log_file, $log_irun_dir);
		}
		if (scalar @assertion_error != 0)
		{
			assertion_error_write ($log_irun_dir, $irun_log_file, $log_irun_dir);
		}
		opt_error_write ($log_irun_dir, $irun_log_file, $log_irun_dir);
		status_write ($log_irun_dir, $irun_log_file, $log_irun_dir);
	}
	close ($log_fh_1);
        system "cp $current_dir/clean_ncsim.sh $log_irun_dir/.";
        system ("./clean_ncsim.sh");
        system "rm clean_ncsim.sh";
 	return 1;									# Return 1 if the entire grepping and copying process is successfull
}
#========================================================================================================================================================================
#RETRIVE_LOG_INFORMATION
# This subroutine is called to retrieve all the log information from the file
#========================================================================================================================================================================
sub retrieve_log_info
{
	my $count = 0;								# Count to store the index of the array containing row elements.
	my $pos_end = pop (@_);							# Pop the index of the end position upto which data is to be copied
	my $pos_start = pop (@_);						# Pop the index of the start position from which data is to be copied
	my $pos_string = pop (@_);						# Pop the string which is to be taken as the reference from which data is to be copied
	my $match = pop (@_);							# Pop the $match , keyword which is to be grepped from the log file.
	my @log_list = @_;							# This array contains all the rows in the log file
	my $stall;								# Variable to keep track of the Index from which data is to be copied.
	my $log_info='';							# Stored the final information which is to returned.
	my @match = grep /$match/,@log_list;					# To grep and store all the lines in the log file which match with #$match.
	if(scalar @match > 0)							# If any useful match is found , enter into the if loop.
	{
		@match=split(' ',$match[0]);					# Split the matched row into elements, separated by spaces.
		foreach my $b(@match)
		{	
			if ($b eq $pos_string)					# keep track of the index of the pop_string
			{
				  $stall=$count;
			}
		$count ++;
		}
		if ($pos_end eq 'end')
		{
			$pos_end = (scalar @match) - 2;				# Special case in the case of total_sim
		}
		for ($count = ($stall+$pos_start); $count < ($stall + $pos_end); $count ++)
		{	
			$log_info=$log_info.' '.$match[$count];			# Navigate over the pop_start and pop_end with the help of the stall value
		}
	}
	return $log_info;							# return the required log_information.
}
#---------------------------------------------------------------------------------------------------------
# ADDITIONAL FUNCTIONS
#---------------------------------------------------------------------------------------------------------
=pod
sub opt_error_info
{
	my $log_dir = $_[0];
	my $log_file = $_[1];
	my $count = 0;
	my $count_1 = 0;
	my @match;
	my $check_counter = 0;
	chdir "$log_dir";
	my @log_op_fh, my $log_op_fh, my $word;
	open($log_op_fh,'<',$log_file);
	while (<$log_op_fh>)
	{
		for $word (split)
		{
			push(@log_op_fh,$word);
		}
	}
	chdir "$current_dir";
	my @er_op_fh, my $er_op_fh, my $er_op_file=$opt_error;
	open($er_op_fh,'<',$er_op_file);
	while (<$er_op_fh>)
	{
		chomp;
		@er_op_fh = split(' ');
		push(@keyss,@er_op_fh);
		foreach my $m(@er_op_fh)
		{
			$check_counter ++;
			$count = 0;
			my $count_error = grep (/$m/, @log_op_fh);
			$count_1 = $count_1 + $count_error;
			$count = $count + $count_error;
			push(@count, $count);
		}
	}
	#print "$count_1\n";
	return $count_1;
}
sub opt_error_info
{
	my $log_dir = $_[0];
	my $log_file = $_[1];
	my $count = 0;
	my $count_1 = 0;
	chdir "$current_dir";
	my @er_op_fh, my $er_op_fh, my $er_op_file=$opt_error;
	open($er_op_fh,'<',$er_op_file);
	@er_op_fh = <$er_op_fh>;
	foreach $error_word(@er_op_fh)
	{
		chomp $word;
		@temp = split('',$word);
		foreach $letter (@temp)
		{
			if ($letter eq '*')
			{
				$letter = '\*';
			}	
		}
		$temp = join('', @temp);
		push (@error_word,$temp);
	}	
	#print "$count_1\n";
	return $count_1;
}
sub opt_error_info
{
	my $log_dir = $_[0];
	my $log_file = $_[1];
	my $word;
	my $letter;
	my @temp;
	my $temp;
	my $cn_fh;
	my $count; 
	my $count_1;
	my @er_op_fh; 
	my $er_op_fh; 
	my $er_op_file=$opt_error;
	chdir "$current_dir";
	open($er_op_fh,'<',$er_op_file);
	@er_op_fh = <$er_op_fh>;
	close $er_op_fh;
	foreach $word (@er_op_fh)
	{
		chomp $word;
		@temp = split('',$word);
		foreach $letter (@temp)
		{
			if ($letter eq '*')
			{
				$letter = '\*';
			}	
		}
		$temp = join('', @temp);
		push (@error_word,$temp);
	}
	#print "@error_word  \n";
	chdir "$log_dir";
	foreach $word (@error_word)
	{
		chomp $word;
		system("grep -c \"$word\" $log_file >> $error_count_file" );
	}	
	open ($cn_fh, '<', $error_count_file) or die "Couldn't open the file : $error_count_file";
	while(<$cn_fh>)
	{
		for $count (split)
		{
			#print "count";
			#print "$count\t";
			push(@error_count,$count);
			$count_1 = $count_1 + $count;
		}
	}
	close $cn_fh;
	splice (@error_word);
	@error_word = @er_op_fh;
	#system("rm -r $error_count_file");
	#print "$count_1";
	return $count_1;
}
=cut
sub opt_error_info
{
	my $log_dir = $_[0];
	my $log_file = $_[1];
	my $word;
	my $count;
	my $letter;
	my @er_fh;
	my $er_fh;
	my $er_ex_fh;
	my @er_ex_fh;
	my $cn_fh;
	my $count_1 = 0;
	my $temp;
	my @temp;	
	my $value;
	my @error_word_1;
	my @error_exclude_word_1;
	my $count_word;
	my @count_word;

	chdir "$current_dir";
	
	open ($er_fh,'<',$opt_error);
	@er_fh = <$er_fh>;
	close $er_fh;
	foreach $word (@er_fh)
	{
		chomp $word;
		@temp = split('',$word);
		foreach $letter (@temp)
		{
			if ($letter eq '*')
			{
				$letter = '\*';
			}	
		}
		$temp = join('', @temp);
		push (@error_word,$temp);
	}
        if ($opt_error_exclude ne 'nil')
        {	
	     open ($er_ex_fh,'<',$opt_error_exclude);
	     @er_ex_fh = <$er_ex_fh>;
	     close $er_ex_fh;
	     foreach $word (@er_ex_fh)
	     {
	     	chomp $word;
	     	@temp = split('',$word);
	     	foreach $letter (@temp)
	     	{
	     		if ($letter eq '*')
	     		{
	     			$letter = '\*';
	     		}	
	     	}
	     	$temp = join('', @temp);
	     	push (@error_exclude_word,$temp);
	     }
        }
	chdir "$log_dir";

	foreach $word (@error_word)
	{
		chomp $word;
		system("grep -ic \"$word\" $log_file >> $error_count_file" );
	}
	if(scalar @error_word) 
        {
	   open ($cn_fh, '<', $error_count_file);
	   while(<$cn_fh>)
	   {
	   	for $count (split)
	   	{
	   		push(@error_count,$count);
	   	}
	   }
	   close $cn_fh;
	}

	@error_word_1 = @er_fh;
	@hash_list{@error_word} = @error_count;
	#print Dumper (\%hash_list);	

	foreach $word (@error_exclude_word)
	{
		chomp $word;
		system("grep -ic \"$word\" $log_file >> $error_exclude_count_file" );
	}
	if(scalar @error_exclude_word) 
        {
	   open ($cn_fh, '<', $error_exclude_count_file);
	   while(<$cn_fh>)
	   {
	   	for $count (split)
	   	{
	   		push(@error_exclude_count,$count);
	   	}
	   }
	   close $cn_fh;
	}
	
	@error_exclude_word_1 = @er_ex_fh;
	@hash_exclude_list{@error_exclude_word} = @error_exclude_count;
	#print Dumper (\%hash_exclude_list);

	foreach $word (@error_word)
	{
		#print "$word\n";
		#print "@error_exclude_word\n";
		@count_word = grep /$word/, @error_exclude_word_1;
		$count_word = grep /$word/, @error_exclude_word_1;
		#system("grep -ic \"$word\" $error_exclude_file >> $")
		#print "@count_word \n";
		#print "$count_word \n";
		if ($count_word != 0)
		{
			foreach my $word1(@error_exclude_word)
			{
				$hash_list{$word} = $hash_list{$word} - $hash_exclude_list{$word1};
			}
		}
		$count_1 = $count_1 + $hash_list{$word}; 	
	}

	foreach $word(keys %hash_list)
	{
		$value = $hash_list{$word};
		#delete $hash_list{$word};
		@temp = split('',$word);
		foreach $letter (@temp)
		{
			if ($letter eq '\\')
			{
				$letter = '';
			}
		}
		$word = join('',@temp);
		#print "$word\t";
		$hash_list_sp{$word} = $value;
	}
	
	foreach $word(keys %hash_exclude_list)
	{
		$value = $hash_exclude_list{$word};
		#delete $hash_exclude_list{$word};
		@temp = split('',$word);
		foreach $letter (@temp)
		{
			if ($letter eq '\\')
			{
				$letter = '';
			}
		}
		$word = join('',@temp);
		#print "$word\t";
		$hash_exclude_list_sp{$word} = $value;
	}

	return $count_1;	
}
#---------------------------------------------------------------------------------------------------------
sub opt_error_write
{
	my $log_dir_initial = $_[2];
	my $log_dir = $_[0];
	my $log_file = $_[1];
	#my @rev_count = reverse @count; # values
	#my $count;
	
	
	chdir "$log_dir";
	#print "@count\n";
	my @log_op_fh, my $log_op_fh;
	open($log_op_fh,'>>',$log_file);
	@log_op_fh = <$log_op_fh>;
	print $log_op_fh "\n***************************************************************************************** \n";
	print $log_op_fh "Other errors found in this log file are: \n";
	#my @keys = keys %hash_error;
	foreach my $key(keys %hash_list_sp)
	{
		if ($hash_list_sp{$key} != '0')
		{
			print $log_op_fh "$key count is $hash_list_sp{$key}\n";
		}
	}
	print $log_op_fh "***************************************************************************************** \n";
	close $log_op_fh;
	chdir "$log_dir_initial";
	return 1;	
}
#---------------------------------------------------------------------------------------------------------
sub assertion_error_write
{
	my $log_dir = $_[0];
	my $log_file = $_[1];
	my $log_dir_initial = $_[2];
	chdir "$log_dir";
	my @log_op_fh, my $log_op_fh;
	open($log_op_fh,'>>',$log_file);
	@log_op_fh = <$log_op_fh>;
	print $log_op_fh "\n***************************************************************************************** \n";
	print $log_op_fh "Assertion errors are found in this file \n";
	print $log_op_fh "ASSERTION_ERROR = ".scalar @assertion_error."\n";
	print $log_op_fh "***************************************************************************************** \n";
	close $log_op_fh;
	chdir "$log_dir_initial";
	return 1;	
}
#---------------------------------------------------------------------------------------------------------
sub status_write
{
	my $log_dir = $_[0];
	my $log_file = $_[1];
	my $log_dir_initial = $_[2];
	chdir "$log_dir";
	my @log_op_fh, my $log_op_fh;
	open($log_op_fh,'>>',$log_file);
	@log_op_fh = <$log_op_fh>;
	print $log_op_fh "\n***************************************************************************************** \n";
	if ($log_status eq 'passed')
	{
		print $log_op_fh "******************************** TEST PASSED ********************************************\n"
	}
	else
	{
		print $log_op_fh "******************************** TEST FAILED ********************************************\n"
	}
	print $log_op_fh "***************************************************************************************** \n";
	close $log_op_fh;
	chdir "$log_dir_initial";
	return 1;	
}
#---------------------------------------------------------------------------------------------------------
sub error_text_file
{
	my $log_dir = $_[0];
	my $log_file = $_[1];
	my $log_dir_initial = $_[2];
	chdir "$log_dir";
	my $log_file_original = $log_file;	
	my $repeat = 4;
	while ( $repeat > 0 )
	{
		chop $log_file;
		$repeat --;
	}
	my $error_file = $log_file.'.txt';
	my $error_file_1 = $log_file.'_1.txt';
	my $er_fh;	
	open($er_fh,'>',$error_file_1);	
	print $er_fh "The errors found in the file are:\n";			
	close $er_fh;
	if ($error != 0)
	{
		if ($language eq 'UVM')
		{
			open($er_fh,'>>',$error_file_1);
			print $er_fh "\nUVM_ERROR found are:\n"; 
			close $er_fh;
			system("grep -n \"UVM_ERROR\" $log_file_original >> $error_file_1" );
		}
		if ($language eq 'OVM')
		{
			open($er_fh,'>>',$error_file_1);
			print $er_fh "\nOVM_ERROR found are:\n"; 
			close $er_fh;
			system("grep -n \"OVM_ERROR\" $log_file_original >> $error_file_1" );
		}
	}
	if ($fatal != 0)
	{
		if ($language eq 'UVM')
		{
			open($er_fh,'>>',$error_file_1);
			print $er_fh "\nUVM_FATAL found are:\n"; 
			close $er_fh;	
			system("grep -n \"UVM_FATAL\" $log_file_original >> $error_file_1" );
		}
		if ($language eq 'OVM')
		{
			open($er_fh,'>>',$error_file_1);
			print $er_fh "\nOVM_FATAL found are:\n"; 
			close $er_fh;	
			system("grep -n \"OVM_FATAL\" $log_file_original >> $error_file_1" );
		}
	}
	if (scalar @assertion_error != 0)
	{
		open($er_fh,'>>',$error_file_1);
		print $er_fh "\nASSERTION errors found are:\n";
		close $er_fh;
		system("grep -n \"\*E\" $log_file_original >> $error_file_1" );
	}
	if ($optional_error != 0)
	{
		open($er_fh,'>>',$error_file_1);	
		print $er_fh "\nThe other user-specified errors found are:\n";
		close $er_fh;
		foreach my $keys(keys %hash_list)
		{
			if ($hash_list{$keys} != 0)
			{
				open($er_fh,'>>',$error_file_1);	
				print $er_fh "\n";
				close $er_fh;
				system("grep -n \"$keys\" $log_file_original >> $error_file_1" );
			}
		}
		foreach my $keys(keys %hash_exclude_list)
		{
			if ($hash_exclude_list{$keys} != 0)
			{
				system("grep -v \"$keys\" $error_file_1 > $error_file" );
			}
		}
	}
	chdir $log_dir_initial;
	return 1;
}
#---------------------------------------------------------------------------------------------------------
sub log_zip
{
	my $log_dir = $_[0];
	my $log_file = $_[1];
	my $log_dir_initial = $_[2];
	chdir "$log_dir";
	system ("gzip $log_file");
	chdir "$log_dir_initial";
	return 1;		
}
#=========================================================================================================================================================================
# COMPILE TEST
#To create compile_ncsim.sh file and compile it
#=========================================================================================================================================================================
sub compile_test
{
	my $cmd_test_copy=$_[0];				# Make a copy of the received irun command with the required options and data
	my $common_dir=$sim_dir.'/common_libs';			# Append the sim_dir with the common_libs directory.
	print "Sim dir is $sim_dir \n";
	print "The common_libs dir is $common_dir\n";
	chdir "$common_dir" or die "Could not change directory to $common_dir\n";		# Change DIR to the common libs dir
	if ($tool eq 'ncsim')
	{
		my $op_fh,my $op_file="compile_ncsim.sh";		# name the bash file
		open($op_fh,'>',$op_file);				# Open it with a file_handle and add data to it .
		print $op_fh "#!/bin/sh\n";				
		print $op_fh "IUS_HOME=`ncroot`\n";
		print $op_fh $cmd_test_copy.'-elaborate $*';		# elaborate option only to compile and generate the snapshot
		close $op_fh;						# Close the file handle
		my $mode = 0777;					# Make the file executable
		chmod $mode, "$op_file";			
		system ("./$op_file");				
		chdir "$current_dir";					# Change directory back to the current directory.
	}
	elsif ($tool eq 'modelsim')
	{
		my $op_fh,my $op_file="compile_modelsim.sh";		# name the bash file
		open($op_fh,'>',$op_file);				# Open it with a file_handle and add data to it .
		print $op_fh $cmd_test_copy;
		close $op_fh;
		my $mode = 0777;
		chmod  $mode, "$op_file";
		system ("./$op_file");
		chdir "$current_dir";
	}	
}
#=========================================================================================================================================================================
# NUMBER OF RUNNING JOBS
# Check to check the number of running jobs.
#==========================================================================================================================================================================
sub no_of_running_jobs
{	
	my $num_jobs = `qstat | grep "$user" |wc -l `;			# This returns the number of processes which are currently running.
	return $num_jobs;					
}
#==========================================================================================================================================================================
# LOG GREP
# Once the number of running processes are less than three, then grep the current directory for any .log files and send it to the create_log sub routine.
#==========================================================================================================================================================================
sub log_grep
{	
	my $test_sub_dir=$_[0];					# Receive the current simulation directory.
	my $test_name=$_[1];
	my $log_fh;
	my @log_fh; 
	my $log_word;
	my @log_1;
        my $test_complete;
	my $test_dir=$sim_dir.'/'.$test_sub_dir;		# Prepend the entire path.	
	chdir "$sim_dir";					# Navigate to the above dir.
	my @log_files = glob "*/*test*.log";
	foreach my $log(@log_files)				
	{	
		chomp $log;					# Remove trailing nw line characters.
		$test_complete = system "grep -iq 'ncsim: CPU Usage' $log" if ($tool eq 'ncsim');
		$test_complete = system "exit" if ($tool eq 'modelsim');
		#print "Error info $test_complete $log";
		if($test_complete == 0)
		{
			$count_grep++;
			@log_1=split('/',$log); 
			#print "$log is over.\n";
			my $log_complete=create_log($log_1[1],$log_1[0]);# Send it to the create_log file sub.
			system ("rm -rf $log_1[1]");
		}       
=pod
			open ($log_fh,'<',$log) or die "can't open $log file";
			while (<$log_fh>)
			{
				for $log_word (split)
				{
					push (@log_fh, $log_word);
				}
			}
			foreach my $log_word_match(@log_fh)
			{
				if ($log_word_match eq 'exit')
				{
					sleep(2);
					if ($coverage ne 'nil') {
					   sleep(2);
					} 
					$count_grep++;
					@log_1=split('/',$log); 
					print "$log is over.\n";
					my $log_complete=create_log($log_1[1],$log_1[0]);# Send it to the create_log file sub.
					system ("rm -rf $log_1[1]");
					goto NEXT;
				}
			}
			NEXT:
			splice (@log_fh);
			splice (@log_1);
			chdir "$sim_dir";					# Navigate to the above dir.
			close $log_fh;
=cut
		splice (@log_1);
		chdir "$sim_dir";					# Navigate to the above dir.
	}
	splice (@log_files);
}
#==========================================================================================================================================================================
#RUN TEST
#To run the .sh file
#==========================================================================================================================================================================
sub run_test
{
	my $cmd_test_copy=$_[0];			# Make a copy of the irun command
	my $test_sub_dir =$_[1];			# Save the sub directory name where the simulation is to be run.
	my $test_name    =$_[2];			# Save the test_case name.
	my $log_file = $test_name.'.log';
	my $test_dir=$sim_dir.'/'.$test_sub_dir;	
	chdir "$test_dir";				# change directory to the simulation directory.
	if ($tool eq 'ncsim')
	{
		my $op_fh,my $op_file = $test_name.".sh";	
		open($op_fh,'>',$op_file) or die "Can't open $op_file file";	# Open a file handle to write into the output bash .sh file.
		print $op_fh "#!/bin/sh\n";			
		print $op_fh "IUS_HOME=`ncroot`\n";		
		print $op_fh "cd $test_dir\n";			# Change directory to test directory is mandatory before writing the irun command.
		if (scalar @define_list != 0)
		{	
			foreach my $elements (@vip_fh)
			{
				print $op_fh "$elements";
			}
		}
		#print $op_fh $cmd_test_copy.'-R -nclibdirname '.$sim_dir.'/common_libs/INCA_libs '.'-log '.$test_name.'.log $*';	# Appending the -R option To run prev elaborated file , -nclibdirname option to provide location
		if ((scalar @define_list != 0) and ($log ne 'nil'))
		{
			print $op_fh $cmd_test_copy.'-log '.$log.'.log $*';
			#print scalar @define_list."\n";
		}
		elsif (scalar @define_list != 0)
		{
			print $op_fh $cmd_test_copy.'-log '.$test_name.'.log $*';
			#print scalar @define_list."\n";
		}
		elsif($log ne 'nil')
		{
			print $op_fh $cmd_test_copy.'-R -nclibdirname '.$sim_dir.'/common_libs/INCA_libs '.'-log '.$log.'.log $*';	# Appending the -R option To run prev elaborated file , -nclibdirname option to provide location
		}
		else
		{
			print $op_fh $cmd_test_copy.'-R -nclibdirname '.$sim_dir.'/common_libs/INCA_libs '.'-log '.$test_name.'.log $*';	# Appending the -R option To run prev elaborated file , -nclibdirname option to provide location
		}
		if(($lib_link ne 'nil') and ($lib_link_file ne 'nil'))
		{
			print $op_fh '-'.$lib_link.' '.$test_dir.'/'.$lib_link_file;
		}
		close $op_fh;					# of INCA_libs, - log to specify log file name.
		my $mode = 0777;				# Change mode of the .sh file to make it exceutable.
		my $check1;					# Wait/sleep if three jobs are currently running
		chmod $mode, "$op_file";			
		if ($select eq 'reg' and $pbs ne 'nil')		# If run_test is called from the regression sub routine
		{
			SLEEP :			
			my $check = no_of_running_jobs();	# Wait/sleep if three jobs are currently running
			if ($check == $no_of_licenses)	
			{
				goto SLEEP;
			}
			if ($queue ne 'default')
			{
				system ("qsub -V -q $queue -l host=pluto $op_file");		# Submit job if slot is available
			}
			else
			{
				system ("qsub -V -l host=pluto $op_file");		# Submit job if slot is available
			}
			$check1 = no_of_running_jobs();	# Wait/sleep if three jobs are currently running
			while ($check1>=$no_of_licenses)	
			{
				$check1 = no_of_running_jobs();	# Wait/sleep if three jobs are currently running
			}
			log_grep($test_sub_dir,$test_name);
		}
		elsif ($select eq 'reg' and $pbs eq 'nil')				# If run_test is called from the regression sub routine
		{
			system ("./$op_file");			# Execute the file on the terminal
			log_grep($test_sub_dir,$test_name);
		}
		else						# If run_test is called from the Single test case sub routine
		{
			system ("./$op_file");			# Execute the file on the terminal
		}
	}
	elsif ($tool eq 'modelsim')
	{
		my $rd_fh,my @rd_file, my $rd_file = "single.fl";
		open ($rd_fh,'<',$rd_file);
		@rd_file = <$rd_file>;
		close $rd_fh;
		my $op_fh,my $op_file = $test_name.".sh";	
		open($op_fh,'>',$op_file) or die "Can't open $op_file file";	# Open a file handle to write into the output bash .sh file.
		print $op_fh "vsim ";
		print $op_fh "+UVM_TESTNAME=$test_name";
		foreach my $line (@rd_file)
		{
			print $op_fh $line;
		}
		close $op_fh;
		my $mode = 0777;
		chmod $mode, "$op_file";
		system ("./$op_file");
	}
	else
	{
	
	
	}
	chdir "$current_dir";				# Change the directory back to the current directory .	
}
#===========================================================================================================================================================================
# SINGLE TEST
# This subroutine is called if the single test option is entered by tbshe user
#===========================================================================================================================================================================
sub single_test
{
	#=========Initialization Part ==============================================================================================
	init_dir('single_test');				# To inititalize the sim_dir and the log_dir and its sub directories
	vip_library($vip_lib_dir) if (($vip_library ne 'nil') and ($vip_change_dir eq 'nil'));
	$report_file=create_report() if ($excel ne 'nil');	# To create an excel report if excel option is provided
	my $mode = 0777;					# Read write and executable mode 
	chmod $mode , "$report_file";				# Changing the mode of excel file
	create_dir_test_name($test_name_single);		# Creating the directory Top_test.
	create_dir_test_name('common_libs');			# Creating the common libs directory
	tcl_files($test_name_single,'common_libs');
	vip_library($sim_dir.'/common_libs') if (($vip_library ne 'nil') and ($vip_change_dir ne 'nil'));	# Initialising vip library if option given and not created already
	#=========Compile, Simulation and log  Part ==============================================================================================
	compile_test($cmd_test);				# To create common_libs or check if it exists and to elaborate the design.
	run_test($cmd_test,$test_name_single,$test_name_single);# It goes into the above created directory and runs the command.
	create_log($test_name_single.'.log',$test_name_single);	# Reads all the info from log file seed, date , time , status, cpu usage and appends it to excel file and saves the log file in the appropriate direcotry
}
#===========================================================================================================================================================================
# REGRESSION TEST
# This subroutine is called if the regression test option is entered by the user.
#========================================================================================================================================================================
sub reg_test
{
	init_dir($reg_file);					# To inititalize the sim_dir and the log_dir and its sub directories
	print "reglist is $reg_file\n";
	create_dir_test_name('common_libs');			# Creating the common libs directory
	vip_library($sim_dir.'/common_libs') if (($vip_library ne 'nil') and ($vip_change_dir ne 'nil'));	# Initialising vip library if option given and not created already
	vip_library($vip_lib_dir) if (($vip_library ne 'nil') and ($vip_change_dir eq 'nil'));
	$report_file=create_report() if ($excel ne 'nil');	# To create the initial templete of the report with the required headings.
	my $testcase_count = 0;
	my $testcase_search = 'testname';
	my $mode = 0777;
	chmod $mode, "$report_file";				# Changing the mode of excel file 
	chdir $current_dir;
	my $row, my $reg_fh,my @cmd_reg, my @reg_fh;			# Filehandle to open the regress filelist file.
	open($reg_fh,'<',$reg_file) or die "$! Could not open $reg_file\n";		# Open the regress file list file for reading.
	@reg_fh = <$reg_fh>;
	close $reg_fh;
	my $stop_time_1;
	my $verbosity_1;
	my $seed_2; 
	my $timeout_check = 0;
	my $verbosity_check = 0;
	my $seed_check = 0;
	$testcase_count = grep /$testcase_search/, @reg_fh;
	if ($user_input_licenses != 0)
	{
		$no_of_licenses = $user_input_licenses;
	}
	elsif (($user_input_licenses == 0) and $queue eq 'p_regress_queue')
	{
		$no_of_licenses = $testcase_count + 1;
	}
	else
	{
		$no_of_licenses = 2;
	}
	open($reg_fh,'<',$reg_file) or die"$! Could not open $reg_file\n";		# Open the regress file list file for reading.
	my $append = $cmd_reg;					# Copy of the irun command is stored in the $append variable.
	my $seed1 = 'nil';
	my $define_words;
	my @define_words;
	my $word; 
	my $word_match = 'define';
	tcl_files('common_libs');
	$cmd_reg=$cmd_reg."+UVM_TIMEOUT=$stop_time \\\n\t" if (($stop_time ne 'nil') and ($language = 'UVM'));
	$cmd_reg=$cmd_reg."+OVM_TIMEOUT=$stop_time \\\n\t" if (($stop_time ne 'nil') and ($language = 'OVM'));
	$cmd_reg=$cmd_reg."+UVM_VERBOSITY=$verbosity \\\n\t"  if(($verbosity ne 'nil') and ($language = 'UVM')); 
	$cmd_reg=$cmd_reg."+OVM_VERBOSITY=$verbosity \\\n\t"  if(($verbosity ne 'nil') and ($language = 'OVM')); 
	$cmd_reg=$cmd_reg."+svseed=$seed \\\n\t" if ($seed ne 'nil');	# If user enters it in command line, the svseed is fixed for all test cases.
	if ($deflist ne 'nil')					# Similar procedure as above to add the deflist filelists.
	{
		my $df_fh;
		open($df_fh,'<',$deflist);
		while($row=<$df_fh>)
		{
			chomp $row;
			$cmd_reg=$cmd_reg."-define ".$row." \\\n\t";
		}
	}
	if($boolean eq 'compile')			# Elaborate only once 
	{
        	compile_test($cmd_reg);			# Compile the command.	
	}
	$boolean = 'run';				# Change boolean to run, therefore from the next test case onwards, only run is executed and it is not compiled.
	while($row = <$reg_fh>)					# Read each testfile line in the reglist file
	{
		splice(@define_words);
		$count_reg++;
		my @rcv_row=split(' ',$row);			# Split each row with 'space' as splitting references.
		my $arr_count = 0;				# To save index number of each element in the split array
		my $cmd_reg = $append;				# Saving the append varaible in the cmd_reg local varaible.
		my $retest = 0;					# This determines the number of times the file is to be retested.
		my $test_name;					# This is to save each test case name
		foreach my $var(@rcv_row)			# Iterate over each element in the @rcv_row array
		{						# Check for matches : testname ., UVM_TIMEOUT, UVM_VERBOSITY, seed, retest
			@define_list = grep /$word_match/, @rcv_row;
			switch($var)
			{
				case 'testname' 	
				{									# Append test case name to the irun command.
					$test_name=$rcv_row[($arr_count+2)];
					$cmd_reg=$cmd_reg."+UVM_TESTNAME=$rcv_row[($arr_count+2)] \\\n\t" if ($language eq 'UVM');
					$cmd_reg=$cmd_reg."+OVM_TESTNAME=$rcv_row[($arr_count+2)] \\\n\t" if ($language eq 'OVM');
					#$test_name_1 = $test_name;
				}
				case 'UVM_TIMEOUT'	
				{	# Append timeout to irun command, if not specifically entered from command line
					#if ( $stop_time eq 'nil' )
					#{
					#	$stop_time = $rcv_row[($arr_count+2)];
					#}
					# If user enters it in command line, the uvm_timeout is fixed for all test cases
					$timeout_check = 1;
					$stop_time_1 = $rcv_row[($arr_count+2)];
					$cmd_reg=$cmd_reg."+UVM_TIMEOUT=$stop_time_1 \\\n\t" if ($language eq 'UVM');
					$cmd_reg=$cmd_reg."+OVM_TIMEOUT=$stop_time_1 \\\n\t" if ($language eq 'OVM');
				}	
				case 'UVM_VERBOSITY'
				{	# Append verbosity to irun command, if specifically entered from command line, Else retireve it from the regression list
								
					#if ( $verbosity eq 'nil' )
					#{
					#	$verbosity = $rcv_row[($arr_count+2)];
					#}
					# If user enters it in command line, the uvm_verbosity is fixed for all test cases
					$verbosity_check = 1;
					$verbosity_1 = $rcv_row[($arr_count+2)];
					$cmd_reg=$cmd_reg."+UVM_VERBOSITY=$verbosity_1 \\\n\t" if ($language eq 'UVM');
					$cmd_reg=$cmd_reg."+OVM_VERBOSITY=$verbosity_1 \\\n\t" if ($language eq 'OVM');
				}
				case 'seed'		
				{	# Append seed to irun command, if specifically entered from command line, Else retireve it from the regression list
					#if ( $seed eq 'nil' )
					#{
					#	$seed = $rcv_row[($arr_count+2)];
					#}
					#$seed1 = $seed;
					$seed_check = 1;
					$seed_2 = $rcv_row[($arr_count+2)];
					$seed1 = $seed_2;			
					$cmd_reg=$cmd_reg."+svseed=$seed_2 \\\n\t";	# If user enters it in command line, the svseed is fixed for all test cases.
					#$seed_2 = 'nil';
				}			
				case 'retest'		
				{
					$retest = $rcv_row[($arr_count+2)];
				}
				case 'log'
				{
					$log = $rcv_row[($arr_count+2)];
				}
			}
		$arr_count++;		# index is incremented to keep track of the iteration over the array.
		}
		if ($timeout_check == 0 and $stop_time ne 'nil') 
		{
			$cmd_reg=$cmd_reg."+UVM_TIMEOUT=$stop_time \\\n\t" if ($language eq 'UVM');
			$cmd_reg=$cmd_reg."+OVM_TIMEOUT=$stop_time \\\n\t" if ($language eq 'OVM');
		}
		if ($verbosity_check == 0 and $verbosity ne 'nil') 
		{
			$cmd_reg=$cmd_reg."+UVM_VERBOSITY=$verbosity \\\n\t" if ($language eq 'UVM');;
			$cmd_reg=$cmd_reg."+OVM_VERBOSITY=$verbosity \\\n\t" if ($language eq 'OVM');;
		}
		if ($seed_check == 0 and $seed ne 'nil') 
		{
			$cmd_reg=$cmd_reg."+svseed=$seed \\\n\t";	# If user enters it in command line, the svseed is fixed for all test cases.
			$seed1 = $seed;
		}
		$timeout_check = 0;
		$verbosity_check = 0;
		$seed_check = 0;
		if (scalar @define_list != 0)
		{
			foreach my $word_list(@define_list)
			{
				@temp = split ('',$word_list);
				foreach my $letter (@temp)
				{
					push(@define_words,$letter);
				}
				foreach my $letter (@define_words)
				{
					if ($letter eq '+')
					{
						$letter = ' ';
					}
				}
			}
			$define_words = join ('',@define_words);
			@define_words = split (' ', $define_words);
			@define_words = grep {!/$word_match/} @define_words;
			foreach my $word_list (@define_words)
			{
				$cmd_reg=$cmd_reg."-define ".$word_list." \\\n\t";	
			}
		}
		else
		{
			my $df_fh;
			open($df_fh,'<',$deflist);
			while(<$df_fh>)
			{
				for $word (split)
				{
					push (@define_words,$word);
				}
			}
			foreach my $word_list (@define_words)
			{
				$cmd_reg=$cmd_reg."-define ".$word_list." \\\n\t";
			}
		
		}
		while ($retest >= 0)
		{
			#create_dir_test_name('sim_common');		# Pass $test_name as second argument if individual/ separate directories are needed for each test case else pass sim_common
			create_dir_test_name($test_name);		# Pass $test_name as second argument if individual/ separate directories are needed for each test case else pass sim_common
			create_dir_test_name('common_libs');		# Create the common libs directory
			#tcl_files('sim_common','common_libs');
			tcl_files($test_name,'common_libs');
			if($boolean eq 'compile')			# Elaborate only once 
			{
				compile_test($cmd_reg);			# Compile the command.	
			}
			$boolean = 'run';				# Change boolean to run, therefore from the next test case onwards, only run is executed and it is not compiled.
			#run_test($cmd_reg,'sim_common', $test_name.'_'.$seed1);
			run_test($cmd_reg,$test_name, $test_name.'_'.$seed1);
			$retest --;
		}
	}
	$count_diff = $count_reg - $count_grep;
	while($count_diff >= 0)
	{
		log_grep ($sim_dir);
	        $count_diff = $count_reg - $count_grep;
		--$count_diff;
	}
	print " \n";
	print "Done qsubmitting all the test cases, waiting for the last few to finish \n";
	SLEEP1:
	my $check = no_of_running_jobs();	# Wait/sleep if three jobs are currently running.
	my $sum = 0;
	my ($hours, $min ,$sec);
	my $tot_sim_time = 0;
	foreach my $time (@all_sim_time)
	{
		my ($h, $m, $s) = split /:/, $time;
		$h = $h * 3600;
		$m = $m * 60;
		$sum = $sum + $h +$m + $s;
	}
	$sec = sprintf ("%02d", $sec = $sum%60);
	$min = sprintf ("%02d", $min = int(($sum%3600)/60));
	$hours = int($sum/3600);
	$tot_sim_time = $hours.":".$min.":".$sec;
	if ($excel ne 'nil')			# Writes the extra information in the excel file if enabled
	{
		eval "use Spreadsheet::ParseExcel;";				# ParseExcel is used to read data from rows and columns from excel worksheets.
		eval "use Spreadsheet::ParseExcel::SaveParser;";
		my $parser = Spreadsheet::ParseExcel::SaveParser->new();	# Create a new SaveParser and save it in $parser.
		my $wb = $parser->Parse("$report_file");			# Use $parser to open the initially created excel file $report_file.
		my $wk = $wb->worksheet(0);
		$rw++;							
		$wk->AddCell(++$rw,2,"Total no of tests");			# Prints the message
		$wk->AddCell($rw,3,"$total_passed_and_failed");			# Prints the total number of tests
		$wk->AddCell($rw,5,"Total simulation time");			# Prints the message
		$wk->AddCell($rw,6,"$tot_sim_time");				# Prints the total simulation tests
		$wk->AddCell(++$rw,2,"Total no of passed tests");		# Prints the message
		$wk->AddCell($rw,3,"$total_passed");				# Prints the total number of passed tests
		$wk->AddCell(++$rw,2,"Total no of failed tests");		# Prints the message
		$wk->AddCell($rw,3,"$total_failed");				# Prints the total number of failed tests
		++$rw;
		$wb->SaveAs("$report_file");			
	}
     	if ($coverage ne 'nil')							
	{
		print "Changing to coverage directoy $log_dir/passed/\n";
		#print "Changing to coverage directoy $sim_dir\n";
     		#chdir "$sim_dir"; 
		chdir "$log_dir/passed"; 
		#chdir "$log_dir/failed"; 
		system ("imc -exec $current_dir/imc_code.cmd");
        }
	# Prints the summary on the screen
	print " \n";
	print " Regression is Done\n";
	print " \n";
	print " Report Summary \n";
	print " \n";
	print " Total no of tests= $total_passed_and_failed \n";
	print " Total no of passed tests= $total_passed \n";
	print " Total no of failed tests= $total_failed \n";
}
#==========================================================================================================================================================================
# Generating the .tcl files
#==========================================================================================================================================================================
sub tcl_files
{	
	chdir $current_dir;
	my @tcl_files = `ls | grep ".tcl"`;			# Grep the sim dir for the .log files.
	my $tf, my $temp_sim_dir;
	$temp_sim_dir=$sim_dir.'/'.$_[0];
	my $temp_common=$sim_dir.'/'.$_[1];
	foreach my $tcl(@tcl_files)				
	{	
		chomp $tcl;
		$tf=$current_dir.'/'.$tcl;
		copy( $tf, $temp_sim_dir);
		copy( $tf, $temp_common);
	}
}
#==========================================================================================================================================================================
#EXCEL SHEET CODING
#==========================================================================================================================================================================
sub create_report
{	
	print "Excel Report Creation Enabled \n";
	eval "use Spreadsheet::WriteExcel;";					# WriteExcel is used to write data in rows and columns 
	my $report_file_1 = "report_$sim_mode.xls";
	my $report_file= $log_dir."/report/$report_file_1";		# The report.xls file is created with the appropriate name and in the appropriate dir.
	my $worksheet_label="report_$sim_mode";				# The worksheet is labelled.
	my $cell_row= 1, my $cell_col=1;				# The cell row and cell col is set to the 2nd row and col respectively
	my @headings=( 	'  Sl No. ',					# These are the list of parameters / headings which are required to be added in the excel sheet.
			' Test Name ',
			' Passed/Failed ',
			' Seed Value ',
			' OVM/UVM_WARNING Count',
			' Sim Time ',
			' Sim Start Time ',
			' Sim End Time ',
			' Test Start Date ',
			' Test End Date ',
			' Cpu Usage Info ');
	($workbook,$worksheet1) = get_book_and_sheet ($report_file,$worksheet_label);	# Creates new workbook and worksheet
	make_header_row( $cell_row, $cell_col,@headings);				# Creates the basic templete with all the parameters in the excel sheet.
	# The following are used to set the column width for each of the parameters.
	my $format = $workbook->add_format();
	$format->set_num_format('h:mm:ss');
	$format->set_bg_color('red'); 
	$worksheet1->set_column('B:B',5);						# Sl no
	$worksheet1->set_column('C:C',50);						# Test name
	$worksheet1->set_column('D:D',14);						# Pass/fail
	$worksheet1->set_column('E:E',12);						# Cpu
	$worksheet1->set_column('F:F',20);						# Start TIme
	$worksheet1->set_column('G:G',12,$format);					# Start TIme
	$worksheet1->set_column('H:H',15);						# End time
	$worksheet1->set_column('I:I',15);						# Sim time
	$worksheet1->set_column('J:J',17);						# Seed
	$worksheet1->set_column('K:K',17);						# Start date
	$worksheet1->set_column('L:L',65);						# End date
	$workbook->close; 								# Close the workbook.
	return $report_file;								# Return the path and name of the excel file created.
}
#===========================================================================================================================================================================
#Creates the workbook and the worksheet.
#===========================================================================================================================================================================
sub get_book_and_sheet
{ 
	my( $filename, $label) = @_; # only first run							
	if ($state == 1)
	{
		$workbook  = Spreadsheet::WriteExcel->new( $filename ) or die "Cannot open excel file\n";	# Stat is used so that this statement executes only the
		$worksheet1 = $workbook->add_worksheet( $label ) or die "Cannot open excel file\n";	# first time subroutine is called.
		$state =2;
	}
	($workbook, $worksheet1); 
} 
#===========================================================================================================================================================================
# Workbook .copy.xlsx header writing
#===========================================================================================================================================================================
sub make_header_row
{ 
	my( $row , $column , @headings ) = @_;	 			# Receive the row, col, and headings which are to be written in the excel file.
	my( $workbook, $worksheet1) = get_book_and_sheet(); 		# Retrieve the workbook and worksheet name.				
	my $format = header_format(); 					# Retrieve the format of the header from the header_format() sub.
	$worksheet1->write( $row, $column++, $_,$format )  		# Write each parameter in each column, with the retireved format.
	foreach @headings; 
} 
#===========================================================================================================================================================================
# Workbook .copy.xlsx header format
# This subroutine is a self understandable and it defines the
# Format of the data which is to be entered in the excel sheet
# and this $format can be utilized whenever a write operation takes place
#===========================================================================================================================================================================
sub header_format 
{ 
	my( $workbook, $worksheet ) = get_book_and_sheet(); 
	my $format = $workbook->add_format();  
	$format->set_bold(); 
	$format->set_bg_color('yellow'); 
	$format->set_align('center');
	$format; 
}
#===========================================================================================================================================================================
#   MAIN PROGRAM
#===========================================================================================================================================================================
# This checks if the user has entered both the single test and regression options
#==========================================================================================================================================================================
if($valid_test eq 'true' and $valid_reg eq 'true')					
{
	print (" Error: Cannot run both test and regression \n");
	help();
}
#==========================================================================================================================================================================
# This checks if the user has entered any option or not
#===========================================================================================================================================================================
if (scalar @received_options == 0)
{
	print "\nError : No options received\n";
	help();
}
#======================================================================================================================================================================================
#This appends the cmd_reg or cmd_test accordingly.
#======================================================================================================================================================================================
switch($tool)
{
	case 'ncsim' 	
	{
 		$cmd_test="irun ".$cmd_test.'-uvmhome ${IUS_HOME}/tools/uvm'." -access +rwc -perfstat -licqueue \\\n\t";	# Appends the basic commmands when ncsim is selected.
		if ( $valid_test eq 'true')					# If valid_test is true all the variables associated with single test are appended
		{								# If they are " nil " they are not appended.
			$cmd_test=$cmd_test."+UVM_TESTNAME=$test_name_single \\\n\t" if ($language eq 'UVM');
			$cmd_test=$cmd_test."+OVM_TESTNAME=$test_name_single \\\n\t" if ($language eq 'OVM');
			$cmd_test=$cmd_test."-vtimescale $vtimescale \\\n\t";
			$cmd_test=$cmd_test."-F $frtl \\\n\t";
			$cmd_test=$cmd_test."+UVM_VERBOSITY=$verbosity \\\n\t" if (($verbosity ne 'nil') and ($language eq 'UVM'));
			$cmd_test=$cmd_test."+OVM_VERBOSITY=$verbosity \\\n\t" if (($verbosity ne 'nil') and ($language eq 'OVM'));
			$cmd_test=$cmd_test."-gui \\\n\t" if ($gui ne 'nil');
			$cmd_test=$cmd_test."+svseed=$seed \\\n\t" if ( $seed ne 'nil');
			$cmd_test=$cmd_test."+uvm_timeout=$stop_time \\\n\t" if ($stop_time ne 'nil');
			$cmd_test=$cmd_test."-input $dump \\\n\t" if ($dump ne 'nil');
		}
		elsif ( $valid_reg eq 'true')				# If valid_reg is true , all the variables associated with regression tests are appended
		{
			$cmd_reg=$cmd_reg."-vtimescale $vtimescale \\\n\t";
			$cmd_reg="irun ".$cmd_reg.'-uvmhome ${IUS_HOME}/tools/uvm'." -perfstat -licqueue \\\n\t"; 
			$cmd_reg=$cmd_reg."-F $frtl \\\n\t";
			$cmd_reg=$cmd_reg."-input $dump \\\n\t" if ($dump ne 'nil');
		}
		my $row;
		if ($options ne 'nil')						# Checks whether options filelist is given or not
		{
			my $op_fh;						# Filehandle for file operations
			open($op_fh,'<',$options);				# Opens the file (Read mode)
			while($row=<$op_fh>)				
			{
				chomp $row;					# Removes newline character
				$cmd_test=$cmd_test.$row." \\\n\t";		# Concatenation for single test
				$cmd_reg=$cmd_reg.$row." \\\n\t";		# Concatenation for regression list
			}
		}
		if ($deflist ne 'nil')						# Similar procedure as above to add the deflist filelists.
		{
			my $df_fh;						# Filehandle
			open($df_fh,'<',$deflist);				# Opens the file (Read mode)
			while($row=<$df_fh>)
			{
				chomp $row;					# Removes the newline character
				$cmd_test=$cmd_test."-define ".$row." \\\n\t";	# Concatenation for single test
			}
		}
=pod		my $incl_fh;						#Similar procedure as above to add the inclist filelists
		open($incl_fh,'<',$inclist);
		while($row=<$incl_fh>)
		{
			chomp $row;
			if (($row =~ /nas_storage/) or ($row =~ /DENALI/) or ($row =~ /CDN_VIP_LIB_PATH/))
			{		
				$cmd_test=$cmd_test."-incdir ".$row." \\\n\t";						
				$cmd_reg=$cmd_reg."-incdir ".$row." \\\n\t";
			}
			else
			{
				$cmd_test=$cmd_test."-incdir ".$top_dir.'/'.$row." \\\n\t";
				$cmd_reg=$cmd_reg."-incdir ".$top_dir.'/'.$row." \\\n\t";
			}				
		}
		my $ftb_fh;						# The TB file lists are appended to the irun command.
		open($ftb_fh,'<',$ftb);					# The filelist file is opened using a file handle.
		while($row=<$ftb_fh>)					# Each row in the file is read.
		{			
			chomp $row;					# To remove any trainling new line characters.
			if (($row =~ /nas_storage/) or ($row =~ /DENALI/) or ($row =~ /CDN_VIP_LIB_PATH/))
			{		
				$cmd_test=$cmd_test.$row." \\\n\t";						
				$cmd_reg=$cmd_reg.$row." \\\n\t";
			}
			else
			{
				$cmd_test=$cmd_test.$top_dir.'/'.$row." \\\n\t";						
				$cmd_reg=$cmd_reg.$top_dir.'/'.$row." \\\n\t";
			}
		}
=cut 
		my $incl_fh, my @incl_fh;				# Filehandle and array declaration for inclist 
		open($incl_fh,'<',$inclist);				# Opening the inclist filelist
		@incl_fh = <$incl_fh>;					# Storing the inclist information in an array
		close $incl_fh;						# Closing the filehandle
		my @list;						# Storing one type of list from this inclist
		my $list;
		my $other_list;
		my @other_list;						# Storing the other type of list from this inclist
		my @temp_letters;					# For temporary storage
		my $temp_letter;
		foreach $row(@incl_fh)					# Reading the file line by line
		{
			chomp $row;					# Removing the new line character
			@temp_letters = split ('/',$row);		# Spliting the string with / as reference of splitting
			if (($temp_letters[0] eq 'testcases') or ($temp_letters[0] eq 'testbench') or ($temp_letters[0] eq 'tb'))
			{
				push(@other_list, $row);		# Creating an array which matches the if condition
			}
		}
		$other_list = \@other_list; 				# Refering to the list as a pointer 
		@list = grep {!($_ ~~ $other_list)} @incl_fh;		# Creating the other array with the exclusion of elements from the first array
		foreach my $line (@list)				# Adding the line into the string for compiling/running purpose
		{
			$cmd_test=$cmd_test."-incdir ".$line." \\\n\t";		#Adding for single test 				
			$cmd_reg=$cmd_reg."-incdir ".$line." \\\n\t";		#Adding for regression list
		}
		foreach my $line (@other_list)
		{
			$cmd_test=$cmd_test."-incdir ".$top_dir.'/'.$line." \\\n\t";	#Adding for single test
			$cmd_reg=$cmd_reg."-incdir ".$top_dir.'/'.$line." \\\n\t";	#Adding for regression list
		}
		splice (@list);						# Removing all elements from the array
		splice (@other_list);					# Removing all elements from the array
		splice (@temp_letters);					# Removing all elements from the array
		my $ftb_fh, my @ftb_fh;					# Filehandle and array declaration for tb_list
		open($ftb_fh,'<',$ftb);					# Opening the tb_list filelist
		@ftb_fh = <$ftb_fh>;					# Storing the inclist information in an array			
		close $ftb_fh;						# Closing the filehandle
		foreach $row(@ftb_fh)					# Reading the file line by line		
		{
			chomp $row;					# Removing the new line character
			@temp_letters = split ('/',$row);		# Spliting the string with / as reference of splitting
			if (($temp_letters[0] eq 'testcases') or ($temp_letters[0] eq 'testbench') or ($temp_letters[0] eq 'tb'))
			{
				push(@other_list, $row);		# Creating an array which matches the if condition
			}
		}
		$other_list = \@other_list;				# Refering to the list as a pointer
		@list = grep {!($_ ~~ $other_list)} @ftb_fh;		# Creating the other array with the exclusion of elements from the first array
		foreach my $line (@list)				# Adding the line into the string for compiling/running purpose
		{
			$cmd_test=$cmd_test.$line." \\\n\t";		#Adding for single test				
			$cmd_reg=$cmd_reg.$line." \\\n\t";		#Adding for regression list
		}
		foreach my $line (@other_list)
		{
			$cmd_test=$cmd_test.$top_dir.'/'.$line." \\\n\t";	#Adding for single test
			$cmd_reg=$cmd_reg.$top_dir.'/'.$line." \\\n\t";		#Adding for regression list
		}
		splice (@list);
		splice (@other_list);
		splice (@temp_letters);
		if ($coverage ne 'nil')
		{
			my $cov_fh;
			open($cov_fh,'<',$coverage);
			while($row=<$cov_fh>)
			{
				chomp $row;
				$cmd_test=$cmd_test.$row." \\\n\t";
				$cmd_reg=$cmd_reg.$row." \\\n\t";
			}
		}
	}
	case 'modelsim' 
	{	#Can be extended to provide support for the mentor graphics tool.	
		$cmd_test = 'vlog ';
		my $row;
		#Additional Options 
		if ($options ne 'nil')						# Checks whether options filelist is given or not
		{
			my $op_fh;						# Filehandle for file operations
			open($op_fh,'<',$options);				# Opens the file (Read mode)
			while($row=<$op_fh>)				
			{
				chomp $row;					# Removes newline character
				$cmd_test=$cmd_test.$row." ";		# Concatenation for single test
				$cmd_reg=$cmd_reg.$row." ";		# Concatenation for regression list
			}
		}
		#Define Variables
		if ($deflist ne 'nil')						# Similar procedure as above to add the deflist filelists.
		{
			my $df_fh;						# Filehandle
			open($df_fh,'<',$deflist);				# Opens the file (Read mode)
			while($row=<$df_fh>)
			{
				chomp $row;					# Removes the newline character
				$cmd_test=$cmd_test."+define+".$row." ";	# Concatenation for single test
				$cmd_reg=$cmd_reg.$row." ";		# Concatenation for regression list
			}
		}
		#Include directories	
		my $incl_fh, my @incl_fh;				# Filehandle and array declaration for inclist 
		open($incl_fh,'<',$inclist);				# Opening the inclist filelist
		@incl_fh = <$incl_fh>;					# Storing the inclist information in an array
		close $incl_fh;						# Closing the filehandle
		my @list;						# Storing one type of list from this inclist
		my $list;
		my $other_list;
		my @other_list;						# Storing the other type of list from this inclist
		my @temp_letters;					# For temporary storage
		my $temp_letter;
		foreach $row(@incl_fh)					# Reading the file line by line
		{
			chomp $row;					# Removing the new line character
			@temp_letters = split ('/',$row);		# Spliting the string with / as reference of splitting
			if (($temp_letters[0] eq 'testcases') or ($temp_letters[0] eq 'testbench') or ($temp_letters[0] eq 'tb'))
			{
				push(@other_list, $row);		# Creating an array which matches the if condition
			}
		}
		$other_list = \@other_list; 				# Refering to the list as a pointer 
		@list = grep {!($_ ~~ $other_list)} @incl_fh;		# Creating the other array with the exclusion of elements from the first array
		foreach my $line (@list)				# Adding the line into the string for compiling/running purpose
		{
		       $cmd_test=$cmd_test."+incdir+".$line." ";	#Adding for single test 				
		       $cmd_reg=$cmd_reg."+incdir+".$line." ";		#Adding for regression list
		}
		foreach my $line (@other_list)
		{
			$cmd_test=$cmd_test."+incdir+".$top_dir.'/'.$line." ";	#Adding for single test
			$cmd_reg=$cmd_reg."+incdir+".$top_dir.'/'.$line." ";	#Adding for regression list
		}
		$cmd_test=$cmd_test."\n";
		splice (@list);						# Removing all elements from the array
		splice (@other_list);					# Removing all elements from the array
		splice (@temp_letters);	
		#tb_list 
		my $ftb_fh, my @ftb_fh;					# Filehandle and array declaration for tb_list
		open($ftb_fh,'<',$ftb);					# Opening the tb_list filelist
		@ftb_fh = <$ftb_fh>;					# Storing the inclist information in an array			
		close $ftb_fh;						# Closing the filehandle
		foreach $row(@ftb_fh)					# Reading the file line by line		
		{
			chomp $row;					# Removing the new line character
			@temp_letters = split ('/',$row);		# Spliting the string with / as reference of splitting
			if (($temp_letters[0] eq 'testcases') or ($temp_letters[0] eq 'testbench') or ($temp_letters[0] eq 'tb'))
			{
				push(@other_list, $row);		# Creating an array which matches the if condition
			}
		}
		$other_list = \@other_list;				# Refering to the list as a pointer
		@list = grep {!($_ ~~ $other_list)} @ftb_fh;		# Creating the other array with the exclusion of elements from the first array
		foreach my $line (@list)				# Adding the line into the string for compiling/running purpose
		{
			$cmd_test=$cmd_test.$line." ";		#Adding for single test				
			$cmd_reg=$cmd_reg.$line." ";		#Adding for regression list
		}
		foreach my $line (@other_list)
		{
			$cmd_test=$cmd_test.$top_dir.'/'.$line." ";	#Adding for single test
			$cmd_reg=$cmd_reg.$top_dir.'/'.$line." ";		#Adding for regression list
		}
		splice (@list);
		splice (@other_list);
		splice (@temp_letters);
		
		#if ( $valid_test eq 'true')					# If valid_test is true all the variables associated with single test are appended
		#{								# If they are " nil " they are not appended.
		#	$cmd_test=$cmd_test."+UVM_TESTNAME=$test_name_single \\\n\t";
		#	$cmd_test=$cmd_test."-vtimescale $vtimescale \\\n\t";
		#	$cmd_test=$cmd_test."-F $frtl \\\n\t";
		#	$cmd_test=$cmd_test."+UVM_VERBOSITY=$uvm_verbosity \\\n\t" if ($uvm_verbosity ne 'nil');
		#	$cmd_test=$cmd_test."-c \\\n\t" if ($gui eq 'nil');
		#	$cmd_test=$cmd_test."+svseed=$seed \\\n\t" if ( $seed ne 'nil');
		#	$cmd_test=$cmd_test."+uvm_timeout=$stop_time \\\n\t" if ($stop_time ne 'nil');
		#	$cmd_test=$cmd_test."-input $dump \\\n\t" if ($dump ne 'nil');
		#}
		#$cmd_reg = ;
	}
	case 'vcs' 	
	{ 	#Can be extended to provide support for the vcs tool.
	}
}
#===========================================================================================================================================================================
# Based on the user entered option, the appropriate case is selected
#===========================================================================================================================================================================
switch ( $select )
{
	case 'test' 	
	{	
		missing_test();					# To check if mandatory and optional options are given correctly for the single test case or not.
		single_test();					# To compile and then run the test.
	}
	case 'reg'	
	{	
		missing_reg();	 				# To check if mandatory and optional option are given correctly for regression case or not.
		reg_test();					# To compile once and then run the test cases in the reglist parallely.
	}
	case 'compile'	
	{
		missing_compile();				# To check if the mandatory options are given correctly for compile case or not.
		if($valid_test eq 'true')
		{	
			init_dir('single_test');		# If single test, pass 'single test' to init dir sub routine - to create it in the sim_dir amd log_dir.
			compile_test($cmd_test);		# The compile procedure is initiated and  executed.The irun command is passsed as an argument.
		}
		elsif ($valid_reg eq 'true')
		{
			init_dir($reg_file);			# If reg test, pass 'reg_file' to init_dir sub routine - to create it in the sim_dir and log_dir.
			compile_test($cmd_reg);			# The compile procedure initiated and executed, the irun command and reg file are passed as arguments.
		}
	}
	case 'none'	
	{
		print " Error : Specify Test or Regression\n";	# Test or regression option is not specified .
		help();
	}
}
#=========================================================================================================================================================================
