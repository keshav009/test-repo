rm -rf ../regression ../sim/rtl_sim
