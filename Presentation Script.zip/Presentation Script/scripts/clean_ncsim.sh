rm -rf INCA_libs flex* *.e* *.o* *.tcl ncperfstat.out uvc.elog
