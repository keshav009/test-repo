#!/usr/bin/perl
##
##----------------------------------------------------------------------
## Copyright (c) 2013-2014 by Doulos Ltd.
##
## Licensed under the Apache License, Version 2.0 (the "License");
## you may not use this file except in compliance with the License.
## You may obtain a copy of the License at
##
##     http://www.apache.org/licenses/LICENSE-2.0
##
## Unless required by applicable law or agreed to in writing, software
## distributed under the License is distributed on an "AS IS" BASIS,
## WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
## See the License for the specific language governing permissions and
## limitations under the License.
## ----------------------------------------------------------------------

## 21/09/2014  David Long, Doulos - trans_var allows typedef. item replaced by req. Added checks/coverage_enable.
## 01/09/2014  David Long, Doulos - DUT now in test harness module. Removed unnecessary child environments. Improvements to code formatting
## 05/06/2014  David Long, Doulos - Revised template file format and options. Preliminary version for public release
## 20/05/2014  David Long, Doulos - Support for multiple agents within envs. Simplified directory structure,
## 11/04/2014  David Long, Doulos - Constraints added to seq_item
## 04/04/2014  David Long, Doulos - Naming conventions and use of config_db updated
## 12/03/2014  David Long, Doulos - Support for multiple IFs/register sub-blocks
## 24/02/2014  David Long, Doulos - DUT port list, auto instantiation in top
## 19/02/2014  Author Christoph Suehnel, Doulos
## Based on the juvb11.pl script v1.09 by Jim McGrath, Cadence which was
## uploaded as UVMWorld contribution on 16 September 2011
##

## Easier UVM Generator

use strict;
use warnings;
require 5.8.0;

use File::Copy::Recursive qw(dircopy);
use File::Copy "cp";

my $VERNUM = "2014-09-21 (PRELIMINARY)";

# Subroutine prototypes:
sub  parse_cmdline;
sub  usage;
sub  parse_common;
sub  parse_reg_template;
sub  parse_template;
sub  gen_if;
sub  gen_common;
sub  gen_seq_item;
sub  gen_driver;
sub  gen_monitor;
sub  gen_sequencer;
sub  gen_config;
sub  gen_cov;
sub  gen_agent;
sub  gen_env;
sub  gen_seq_lib;
sub  gen_env_seq_lib;
sub  gen_agent_inc;
sub  gen_agent_pkg;
sub  gen_top_inc;
sub  gen_top_pkg;
sub  gen_dut_inst;
sub  gen_top;
sub  gen_top_env;
sub  gen_top_common;
sub  gen_top_config;
sub  gen_top_seq_lib;
sub  gen_top_if;
sub  gen_top_test;
sub  gen_regmodel_config;
sub  gen_regmodel_env;
sub  gen_regmodel_adapter;
sub  gen_regmodel_coverage;
sub  gen_regmodel_seq_lib;
sub  gen_regmodel_inc;
sub  gen_regmodel_pkg;
sub  gen_questa_script;
sub  gen_vcs_script;
sub  gen_ius_script;
sub  gen_compile_file_list;
sub  write_file_header;


# Scalar Variables:
my $agent_access_mode;
my $agent_access_name;
my $agent_clock_counter;
my $agent_env_seq_inc;
my $agent_has_env;
my $agent_if;
my $agent_item;
my $agent_name;
my $agent_port_counter;
my $agent_reset;
my $agent_reset_counter;
my $agent_seq_inc;
my $agent_seqr_class;
my $agent_var;
my $agent_var_cnstr;
my $agent_var_cnstr_counter;
my $agent_var_counter;
my $aname;
my $argnum;
my $company;
my $copyright;
my $count;
my $date;
my $dept;
my $dir1;
my $dir2;
my $dir;
my $dut_iname;
my $dut_inc_path;
my $dut_path;
my $dut_pfile;
my $dut_tb_dir;
my $dut_top;
my $ele;
my $email;
my $env_clock_list;
my $env_list;
my $env_reset_list;
my $field;
my $fieldsle;
my $i;
my $inc_file;
my $inc_path;
my $incdir;
my $name;
my $pf;
my $pnum1;
my $pnum2;
my $port_decl;
my $project;
my $propsize;
my $reg_sub_access_name;
my $reg_sub_block;
my $reg_template;
my $regmname;
my $regmodel;
my $regmodel_name;
my $tbname;
my $tel;
my $template_list;
my $template_name;
my $timeunit;
my $timeprecision;
my $tmp;
my $uvm_reg_addr;
my $uvm_reg_data;
my $uvm_reg_kind;
my $var_decl;
my $year;
my $version;
my $div;

# Hash Variables
my %agent_cover_inc;
my %agent_drv_inc;
my %agent_env_seq_inc;
my %agent_factory_set;
my %agent_is_active;
my %agent_checks_enable;
my %agent_coverage_enable;
my %agent_item_kind;
my %agent_mon_inc;
my %agent_parent;
my %agent_reg_seq_inc;
my %agent_seq_inc;
my %agent_sub_access;
my %agent_sub_items;
my %agent_sub_names;
my %bus2reg_map;
my %env_agents;
my %reg_cover_inc;
my %reg_sub_access_names;
my %reg_sub_blocks;

# Array Variables
my @agent_clock_array;
my @agent_list;
my @agent_port_array;
my @agent_reset_array;
my @agent_sub_names;
my @agent_var_array;
my @agent_var_cnstr_array;
my @all_agent_ifs;
my @clist;
my @dut_inc_path_list;
my @elist;
my @env_list;
my @fields;
my @inc_file_list;
my @inc_path_list;
my @list;
my @non_reg_env;
my @props;
my @rand_var_array;
my @reg_env;
my @rlist;
my @stand_alone_agents;
my @top_env_agents;
open( LOGFILE, ">easier_uvm_gen.log" );


print "\nEasier UVM Generator: version ${VERNUM}\n";
print LOGFILE "\nEasier UVM Generator: version " . $VERNUM
  . " (Send feedback to info\@doulos.com)\n";

#print "\nThis perl-Script requires the File::Copy::Recursive module\n\n";
#
#some defaults and counters
$copyright = "";

#my ($sec,$min,$hour,$day,$month,$yr,@rest) = localtime;
$date = localtime;
$project = "generated_tb";
$year    = "";
$company = "";
$name    = "";
$email   = "";
$tel     = "";
$dept    = "";
$version = 1.0;
$inc_path = "";
$inc_file = "";
$dut_path = "";
$dut_tb_dir = "dut";
$div    = "";


$agent_name          = "";
$agent_if            = "";
$agent_item          = "";
$agent_var_counter   = 0;
$agent_port_counter  = 0;
$agent_clock_counter = 0;
$agent_reset_counter = 0;
$dut_iname    = "uut";    #instance name of dut in tb
$dut_inc_path = "";
$timeunit      = "1ns";
$timeprecision = "1ps";
$regmodel  = 0;
$dut_top   = "";          #top level dut module
$dut_pfile = "";          #dut port list file

$env_list       = "";
$env_reset_list = "";
$env_clock_list = "";
$tbname         = undef;


$agent_access_name = "";
$regmodel_name     = "";
$agent_has_env     = "yes";


#process command line
$template_name = "example.tpl";    #default template name
$template_list = "";               #default template list
$reg_template  = "";
parse_common();
parse_cmdline();
mkdir( $project, 0755 );
$dir = $project . "/sim";
mkdir( $dir, 0755 );
$dir = $project . "/tb";
mkdir( $dir, 0755 );
$dir = $project . "/tb/" . $tbname;
mkdir( $dir,         0755 );
mkdir( $dir . "/sv", 0755 );
$dir = $project . "/tb/" . $tbname . "_common";
mkdir( $dir,         0755 );
mkdir( $dir . "/sv", 0755 );
$dir = $project . "/tb/" . $tbname . "_tb";
mkdir( $dir,         0755 );
mkdir( $dir . "/sv", 0755 );
$dir = $project . "/tb/" . $tbname . "_test";
mkdir( $dir,         0755 );
mkdir( $dir . "/sv", 0755 );

$dir1 = $dut_path;

#$dir2= $project."/".$dut_name;
$dir2 = $project . "/" . $dut_tb_dir;

#print LOGFILE "dut_path: $dut_path\n";
if ( ( -e $dir ) && $dir1 ne $dir2 ) {

    #$dir1= $dut_path."/".$dut_name;

    dircopy( $dir1, $dir2 ) or die("$!\n");
}
else {
    print LOGFILE "dut_path does not exist. Nothing to copy from DUT\n";
}
if ( -e $inc_path ) {
    $dir1 = $inc_path;
    $dir2 = $project . "/tb/include";
    dircopy( $dir1, $dir2 ) or die("$!\n");
}

#process the agent templates (@list created by parse_cmdline)
print "\nParsing Templates ...\n\n";
print LOGFILE "\nParsing Templates ...\n\n";
foreach my $i ( 0 .. @list - 1) {
    if ( $list[$i] ne "" ) {
        $template_name = $list[$i];
        printf "Reading[$i]: $list[$i]\n";
        printf LOGFILE "Reading[$i]: $list[$i]\n";
        parse_template();

        #make the directories
        $dir = $project . "/tb/" . $agent_name;
        printf LOGFILE "dir: $dir\n";
        mkdir( $dir,         0755 );
        mkdir( $dir . "/sv", 0755 );

        #mkdir($dir."/examples", 0755);

        @props = ();
        $count = 0;
        print "Writing code to files\n";
        print LOGFILE "Writing code to files\n";

        #create the agent files
        gen_if();
        gen_common();
        gen_seq_item();
        gen_config();
        gen_driver();
        gen_monitor();
        gen_sequencer();
        gen_cov();
        gen_agent();
        gen_seq_lib();
        do {
     #do not generate env or env_seq_lib if regmodel used or $agent_has_env = no
            gen_env();
            gen_env_seq_lib();
          } unless ( $regmodel and exists $agent_sub_access{$agent_name} )
          or uc($agent_has_env) eq "NO";

        #generate agent_inc file
        gen_agent_inc();

        #generate agent_pkg file
        gen_agent_pkg();

    }
}
if ( $regmodel eq 1 ) {
    my $line;
    print "Processing register layer\n";
    print LOGFILE "\nProcessing register layer\n";
    parse_reg_template();
    my $dir = $project . "/tb/regmodel";
    printf LOGFILE "rdir: $dir\n";
    mkdir( $dir, 0755 );
    my $file1 = "./regmodel.sv";
    my $file2 = $project . "/tb/regmodel/regmodel.sv";
    print LOGFILE "file1: $file1\n";
    print LOGFILE "file2: $file2\n";

   #cp($file1,$file2) or die "Exiting due to Error: directory copy failure: $!";
   #open regmodel file and  put into package
    open( REGFILE_IN, "<" . $file1 )
      || die("Exiting due to Error: can't open $file1");
    open( REGFILE_OUT, ">" . $file2 )
      || die("Exiting due to Error: can't open $file2");
    my $guard_macro = "";
  COPY_HEADER: {
        $line = <REGFILE_IN>;

        #write header without modification
        if ( $line =~ /^\s*$|^\s*\/\/.*$|^\s*\/\*.*$|^\s*`ifndef\s+([\w_]+).*/ )
        {
            #blank line|comment|compiler directive
            if ($1) { $guard_macro = $1; }
            print REGFILE_OUT $line;
            redo COPY_HEADER;
        }
    }
    print REGFILE_OUT
"package regmodel_pkg;\n\timport uvm_pkg::*;\n\t`include \"uvm_macros.svh\"\n\n$line";
    while ( $line = <REGFILE_IN> ) {

        #copy rest of package file
        last if ( $line =~ /\s*`endif\s+$guard_macro/ );
        print REGFILE_OUT $line;
    }
    print REGFILE_OUT "endpackage: regmodel_pkg\n\n";
    print REGFILE_OUT $line if $line;
    close(REGFILE_IN);
    close(REGFILE_OUT);

    #$regmname = $agent_access_name."_regmodel";
    foreach my $asname (@agent_sub_names) {
		$agent_access_name = $asname;
        $regmname          = $agent_access_name . "_env";
        $agent_access_mode = $agent_sub_access{$agent_access_name};
        $dir               = $project . "/tb/" . $regmname;
        printf LOGFILE "rdir: $dir\n";
        mkdir( $dir,         0755 );
        mkdir( $dir . "/sv", 0755 );

        #mkdir($dir."/examples", 0755);
        print LOGFILE "env_list: $env_list\n";

        @elist = split( /\s+/, $env_list );
        foreach my $i ( 0 .. @elist - 1) {
            if ( $elist[$i] ne "" ) {
                printf LOGFILE "eList[$i]: $elist[$i]\n";
            }
        }

        gen_regmodel_config();
        gen_regmodel_env();
        gen_regmodel_adapter();
        gen_regmodel_coverage();
        gen_regmodel_seq_lib();
        gen_regmodel_inc();
        gen_regmodel_pkg();
        $agent_name = $regmname;
        gen_common();
    }
}

foreach my $agent (@stand_alone_agents) {
    push( @top_env_agents, $agent )
      unless grep( /$agent/, keys(%agent_parent) );
}
print LOGFILE "top env agents = @top_env_agents\n";
print "generating testbench\n";
print LOGFILE "generating testbench\n";

gen_top_common();
gen_top_config();
gen_top_env();
gen_top_seq_lib();

#gen_top_if();
gen_top_inc();
gen_top_pkg();
gen_top_test();
gen_top();

print "writing simulator script to ${project}/sim directory\n";
print LOGFILE "writing simulator script to ${project}/sim directory\n";

gen_questa_script();
gen_vcs_script();
gen_ius_script();

print "Code Generation complete\n";
print LOGFILE "Code Generation complete\n";

# ---------- Subroutines ----------
sub parse_cmdline {
    print LOGFILE "\nParsing cmdline ...\n\n";
    print LOGFILE "num args is " . $#ARGV . "\n";
    if ( $#ARGV == -1 ) { usage(); }    ### no arguments, print help and exit
    ###if ($ARGV[$argnum] =~ m/\s*help/i)
    if ( $ARGV[0] =~ m/\s*(-help|-hel|-he|-h)/i ) {
        usage();
    }
	my $pnum1 = -1;

    # Searching for register flag
    printf LOGFILE "Searching for regmodel flag\n";
    foreach $argnum ( 0 .. $#ARGV) {
        if ( $ARGV[$argnum] =~ m/\s*(-r)/i ) {
            $regmodel = 1;
            $pnum1    = $argnum;
            printf LOGFILE
              "regmodel: $regmodel, Register layer will be included\n";
            printf LOGFILE "pnum1: $pnum1\n";
        }

    }

    # Searching for project name
    printf LOGFILE "Searching for tb_name\n";
    foreach $argnum ( 0 .. $#ARGV) {
        if ( $ARGV[$argnum] =~ m/\s*(-p)/i ) {
            $tbname = $ARGV[ $argnum + 1 ];
            $pnum2  = $argnum;
            printf LOGFILE "tb_name: $tbname\n";
            printf LOGFILE "pnum2: $pnum2\n";
        }

    }
	$tbname or die "ERROR! You must specify the top-level module name using the switch -p\n";
	

    # searching for template (agent) names
    printf LOGFILE "Searching for templates\n";
    foreach $argnum ( 0 .. $#ARGV) {
        if ( $argnum != $pnum1 ) {
            if ( $argnum != $pnum2 ) {
                if ( $argnum != $pnum2 + 1 ) {

                    #check for template name
                    ###if ($ARGV[$argnum] =~ m/\s*template/i)
                    if ( $ARGV[$argnum] =~
                        m/\s*(-template|-templat|-templa|-templ|-tem|-te|-t)/i )
                    {
                        print LOGFILE "template: $ARGV[$argnum]\n";

                        #@fields = split /=/,$ARGV[$argnum];
                        #$template_name=$fields[1];
                    }
                    else {
                        if ( $ARGV[$argnum] ne "reg.tpl" ) {
                            $template_list = "$template_list $ARGV[$argnum]";

                            #print LOGFILE "T_List: $template_list\n";
                        }
                        else {
                            $reg_template = $ARGV[$argnum];
                        }
                    }

                    print LOGFILE "T_List: $template_list\n";
                    print LOGFILE "R_Temp: $reg_template\n";
                    ###if ($ARGV[$argnum] =~ m/\s*help/i)
                    if ( $ARGV[$argnum] =~ m/\s*(-help|-hel|-he|-h)/i ) {
                        usage();
                    }
                }
                @list = split /\s+/, $template_list;
                foreach $i ( 0 .. @list-1 ) {
                    if ( $list[$i] ne "" ) {
                        printf LOGFILE "List: $list[$i]\n";
                    }
                }
            }
        }
    }
	@list or die "ERROR! You must specify at least 1 template file (*.tpl)\n";
	-e $reg_template or die "ERROR! Register layer flag set but register template file \"reg.tpl\" not specified!\n" if $regmodel;
    #do {
    #    if ( -e $reg_template ) {
    #        print LOGFILE "reg template $reg_template exists\n";
    #    }
    #    else {
    #        print LOGFILE "reg template does not exist ... exiting!!!\n";
    #        exit;
    #    }
    #} if $regmodel;
}

sub usage {
    print "USAGE: perl easier_uvm_gen.pl -help (print this message)\n";
    print "\n";

    #print "       perl juvb.pl -template=template_name\n";
    print
"       perl easier_uvm_gen.pl -p toplevel tbname -t list of template_file_names\n\n";
    print "       a template file (*.tpl) is needed for each agent\n";
    print "       for syntax and content see examples provided\n";
    print "       general data must be defined in common.tpl\n\n";
    exit;
}    # end sub usage

sub parse_common {
    my $template_name = "common.tpl";
    open( TH, $template_name )
      || die(
        "Exiting due to Error: can't open template: " . $template_name . "\n" );
    print LOGFILE "Parsing common : $template_name ...\n\n";
    my $ii = 0;
    for ( ; ; ) {
        my $line;
        undef $!;
        unless ( defined( $line = <TH> ) ) {
            die $! if $!;
            last;    # reached EOF
        }

        #next if ($line =~ m/^#/); #comment line starts with "#"
        next if ( $line =~ m/^\s*#/ );    #comment line starts with "#"
        next if ( $line =~ m/^\s+$/ );    #blank line

        $line =~ s/(^.*?)#.*/$1/;         #delete trailing comments

        #@fields = split /\|/, $line;
        $line =~ /^\s*(\w+)\s*=\s*(.+?)\s*$/
          or die
          "Exiting due to Error: bad entry in line $. of common.tpl: $line\n";
        my $param_name  = $1;
        my $param_value = $2;

        if ( $param_name =~ /project/i ) {
            $project = $param_value;
            print LOGFILE "Project: $project\n";
        }
        if ( $param_name =~ /year/i ) {
            $year = $param_value;
            print LOGFILE "Year: $year\n";
        }

        #check for name
        if ( $param_name =~ /^\s*name/i ) {
            $name = $param_value;
            print LOGFILE "Name: $name\n";
        }

        #check for email
        if ( $param_name =~ /email/i ) {
            $email = $param_value;
            print LOGFILE "Email: $email\n";
        }

        #check for tel
        if ( $param_name =~ /tel/i ) {
            $tel = $param_value;
            print LOGFILE "Tel: $tel\n";
        }

        #check for dept
        if ( $param_name =~ /dept/i ) {
            $dept = $param_value;
            print LOGFILE "Dept: $dept\n";
        }

        #check for copyright
        if ( $param_name =~ /copyright/i ) {
            $copyright = $param_value;
            print LOGFILE "$copyright\n";
        }

        #check for version
        if ( $param_name =~ /version/i ) {
            $version = $param_value;
            print LOGFILE "version : $version\n";
        }

        #check for dut include paths
        if ( $param_name =~ /dut_inc_path/i ) {
            $dut_inc_path = $param_value;
            print LOGFILE "dut_inc_path[$ii]: $dut_inc_path\n";
            $dut_inc_path_list[ $ii++ ] = $dut_inc_path;
        }

        #check for include paths
        if ( $param_name =~ /^\s*inc_path/i ) {
            $inc_path = $param_value;

            #print LOGFILE "inc_path[$ii]: $inc_path\n";
            #$inc_path_list[$ii++] = $inc_path;
        }

        #check for include files
        if ( $param_name =~ /inc_file/i ) {
            $inc_file = $param_value;
            print LOGFILE "inc_file[$ii]: $inc_file\n";
            $inc_file_list[ $ii++ ] = $inc_file;
        }

        #check for dut path
        if ( $param_name =~ /dut_source_path/i ) {
            $dut_path = $param_value;
            print LOGFILE "dut_path: $dut_path\n";
        }

        #    #check for dut top level module name
        if ( $param_name =~ /dut_top/i ) {
            $dut_top = $param_value;
            print LOGFILE "dut_top: $dut_top\n";
        }

        #check for dut top level module instance name
        if ( $param_name =~ /dut_iname/i ) {
            $dut_iname = $param_value;
            print LOGFILE "dut instance name: $dut_iname\n";
        }

        #check for dut port list file
        if ( $param_name =~ /dut_pfile/i ) {
            $dut_pfile = $param_value;
            print LOGFILE "dut_pfile: $dut_pfile\n";
        }

        #check for timeunit
        if ( $param_name =~ /timeunit/i ) {
            $timeunit = $param_value;
            print LOGFILE "timeunit: $timeunit\n";
        }

        #check for timeprecision
        if ( $param_name =~ /timeprecision/i ) {
            $timeprecision = $param_value;
            print LOGFILE "timeprecision: $timeprecision\n";
        }

        #check for div
        if ( $param_name =~ /div/i ) {
            $div = $param_value;
            print LOGFILE "Division: $div\n";
        }

    }
    close TH;
}    #end parse_common

sub parse_reg_template {

    open( TH, $reg_template )
      || die(
        "Exiting due to Error: can't open template: " . $reg_template . "\n" );
    for ( ; ; ) {
        my $line;
        undef $!;
        unless ( defined( $line = <TH> ) ) {
            die $! if $!;
            last;    # reached EOF
        }

        #next if ($line =~ m/^#/); #comment line starts with "#"
        next if ( $line =~ m/\s*#/ );       #comment line starts with "#"
        next if ( $line =~ m/^\s\s*$/ );    #blank line

        $line =~ /^\s*(\w+)\s*=\s*(.+?)\s*$/
          or die
"Exiting due to Error: bad entry in line $. of ${reg_template}: $line\n";
        my $param_name  = $1;
        my $param_value = $2;

        #check for sub-blocks
        if ( $param_name =~ /rm_sub_block/i ) {

            $param_value =~ /\s*(\w+)(\s+|\s*,\s*)(\w+)/
              or die
"Exiting due to Error: bad entry in line $. of ${reg_template}: $line\n";
            $reg_sub_block                        = $1;
            $reg_sub_access_name                  = $3;
            $reg_sub_blocks{$reg_sub_access_name} = $reg_sub_block;
            $reg_sub_access_names{$reg_sub_block} = $reg_sub_access_name;
        }

        #check for register model
        if ( $param_name =~ /rm_name/i ) {

            #@fields = split /\|/, $line;
            #s/ ^\s+ | \s+$ //gx for @fields; #crunch out any white space
            $regmodel_name = $param_value;
        }
    }
    print LOGFILE "regmodel_name: $regmodel_name\n";
    print LOGFILE "\n";

    close TH;
}    #end parse_reg_template

sub parse_template {
    $agent_var_counter       = 0;
    @agent_var_array         = ();
    $agent_var_cnstr_counter = 0;
    @agent_var_cnstr_array   = ();
    $agent_port_counter      = 0;
    @agent_port_array        = ();
    $agent_clock_counter     = 0;
    @agent_clock_array       = ();
    $agent_reset_counter     = 0;
    @agent_reset_array       = ();
    $agent_seqr_class        = "";
    $uvm_reg_data            = "";
    $uvm_reg_addr            = "";
    $uvm_reg_kind            = "";
    $agent_seq_inc           = "";
    $agent_env_seq_inc       = "";
    my $agent_sub_access_name = "";
    my $factory_override      = "";
    my @other_agents;
    $agent_has_env = "NO";
    open( TH, $template_name )
      || die(
        "Exiting due to Error: can't open template: " . $template_name . "\n" );

    for ( ; ; ) {
        my $line;
        undef $!;
        unless ( defined( $line = <TH> ) ) {
            die $! if $!;
            last;    # reached EOF
        }
        next if ( $line =~ m/\s*#/ );       #comment line starts with "#"
        next if ( $line =~ m/^\s\s*$/ );    #blank line

        $line =~ /^\s*(\w+)\s*=\s*(.+?)\s*$/
          or die
"Exiting due to Error: bad entry in line $. of ${template_name}: $line\n";
        my $param_name  = $1;
        my $param_value = $2;

        #check for agent_name
        if ( $param_name =~ /agent_name/i ) {
            print LOGFILE "agent_name: $line";
            $agent_name = $param_value;
            $agent_if   = "${agent_name}_if";
            push( @all_agent_ifs, $agent_if );
        }

        #check if agent has its own env (default = NO)
        if ( $param_name =~ /agent_has_env/i ) {
            $agent_has_env = $param_value;

           #push(@stand_alone_agents,$agent_name) if uc($agent_has_env) eq "NO";
        }

        #check if other agents to be added to same env
        if ( $param_name =~ /additional_agent/i ) {
            push( @other_agents, $param_value );
            $agent_parent{$param_value} = $agent_name;
        }

        #check for uvm_seqr_class
        if ( $param_name =~ /uvm_seqr_class/i ) {
            $agent_seqr_class = $param_value;
        }

        #check for active/passive agent
        if ( $param_name =~ /agent_is_active/i ) {
            $agent_is_active{$agent_name} = uc $param_value;
        }

        #check for agent checks_enable (default = YES)
        if ( $param_name =~ /agent_checks_enable/i ) {
            $agent_checks_enable{$agent_name} = uc $param_value;
        }

        #check for agent coverage_enable (default = YES)
        if ( $param_name =~ /agent_coverage_enable/i ) {
            $agent_coverage_enable{$agent_name} = uc $param_value;
        }

        #check for trans_item
        if ( $param_name =~ /trans_item/i ) {
            $agent_item = $param_value;
            print LOGFILE "trans_item= $agent_item\n";
            $agent_item_kind{$agent_name} = $agent_item;

        }

        #check for trans_var
        if ( $param_name =~ /trans_var$/i ) {

            #print LOGFILE "\n";
            $agent_var = $param_value;
            print LOGFILE "trans_var: $agent_var\n";
            $agent_var_array[ $agent_var_counter++ ] = $agent_var;
        }

        #check for trans_var_constraint
        if ( $param_name =~ /trans_var_constraint/i ) {
            $agent_var_cnstr = $param_value;
            print LOGFILE "trans_var_constraint: $agent_var_cnstr\n";
            $agent_var_cnstr_array[ $agent_var_cnstr_counter++ ] =
              $agent_var_cnstr;
        }

        #check for agent sequence include file
        if ( $param_name =~ /agent_seq_inc/i ) {
            $agent_seq_inc{$agent_name} = $param_value;
        }

        #check for agent environment sequence include file
        if ( $param_name =~ /agent_env_seq_inc/i ) {
            $agent_env_seq_inc{$agent_name} = $param_value;
        }

        #check for agent coverpoint include file
        if ( $param_name =~ /agent_cover_inc/i ) {
            $agent_cover_inc{$agent_name} = $param_value;
        }

        #check for driver include file
        if ( $param_name =~ /driver_inc/i ) {
            $agent_drv_inc{$agent_name} = $param_value;
        }

        #check for monitor include file
        if ( $param_name =~ /monitor_inc/i ) {
            $agent_mon_inc{$agent_name} = $param_value;
        }

        #check for if_port
        if ( $param_name =~ /if_port/i ) {
            my $agent_port = $param_value;
            $agent_port_array[ $agent_port_counter++ ] = $agent_port;
        }

        #check for if_clock
        if ( $param_name =~ /if_clock/i ) {
            my $agent_clock = $param_value;
            $agent_clock_array[ $agent_clock_counter++ ] = $agent_clock;
            $env_clock_list =
              $env_clock_list
              ? "$env_clock_list $agent_name $agent_clock"
              : "$agent_name $agent_clock";
            print LOGFILE "env_clock_list: $env_clock_list\n";
        }
        @clist = split( /\s+/, $env_clock_list );
        foreach $i ( 0 .. @clist-1 ) {
            if ( $clist[$i] ne "" ) {
                print LOGFILE "clist[$i]: $clist[$i]\n";
            }
        }

        #check for if_reset
        if ( $param_name =~ /if_reset/i ) {
            $agent_reset = $param_value;
            print LOGFILE "IF_RESET: $agent_reset\n";
            $agent_reset_array[ $agent_reset_counter++ ] = $agent_reset;
            $env_reset_list =
              $env_reset_list
              ? "$env_reset_list $agent_name $agent_reset"
              : "$agent_name $agent_reset";
            print LOGFILE "env_reset_list: $env_reset_list\n";
        }
        @rlist = split( /\s+/, $env_reset_list );
        foreach $i ( 0 .. @rlist-1 ) {
            if ( $rlist[$i] ne "" ) {
                print LOGFILE "rlist[$i]: $rlist[$i]\n";
            }
        }

        #check for reg_access (gives addr map in uvm_reg)
        if ( $param_name =~ /reg_access_name/i ) {
            $param_value =~ /\s*(\w+)(\s+|\s*,\s*)(\w+)/
              or die
"Exiting due to Error: bad entry in line $. of ${template_name}: $line\n";
            $agent_sub_access_name = $1;
            push( @agent_sub_names, $agent_sub_access_name );
            $agent_sub_access{$agent_sub_access_name} = $3;
			$agent_has_env = "YES";
        }

        #check for uvm_reg to bus mappings
        if ( $param_name =~ /uvm_reg_data/i ) {
            $uvm_reg_data = $param_value;
        }
        if ( $param_name =~ /uvm_reg_addr/i ) {
            $uvm_reg_addr = $param_value;
        }
        if ( $param_name =~ /uvm_reg_kind/i ) {
            $uvm_reg_kind = $param_value;
        }

        #check for register sequence include file
        if ( $param_name =~ /reg_seq_inc/i ) {
            $agent_reg_seq_inc{"${agent_name}_env"} = $param_value;
        }

        #check for register coverpoint include file
        if ( $param_name =~ /reg_cover_inc/i ) {
            $reg_cover_inc{$agent_name} = $param_value;
        }

        #check for factory overrides
        if ( $param_name =~ /agent_factory_set/i ) {
            $param_value =~ /\s*(\w+)(\s+|\s*,\s*)(\w+)/
              or die
"Exiting due to Error: bad entry in line $. of ${template_name}: $line\n";
            $factory_override = $1;
            $agent_factory_set{$factory_override} = $3;
        }

    }
    print LOGFILE "agent_sub_access_name is $agent_sub_access_name\n";

    if ($agent_sub_access_name) {
        $bus2reg_map{$agent_sub_access_name} = {
            'data' => $uvm_reg_data,
            'addr' => $uvm_reg_addr,
            'kind' => $uvm_reg_kind
        };
        push( @agent_list, "${agent_sub_access_name}" );
        $agent_sub_names{$agent_name} = $agent_sub_access_name;
        $agent_sub_items{$agent_name} = $agent_item;
    }
    else {
        push( @agent_list, $agent_name );
    }

    if ( uc($agent_has_env) eq "NO" ) {
        push( @stand_alone_agents, $agent_name );
    }
    else {
        $env_list = "$env_list $agent_name";
        push( @env_list, "${agent_name}_env" );
    }

    if (@other_agents) {
        print LOGFILE "${agent_name}_env has other agents: @other_agents\n";
        $env_agents{"${agent_name}_env"} = \@other_agents;
    }
    close TH;
}    #end parse_template

sub write_file_header {
    my ($fname,$descript) = @_;
    print FH
"//=============================================================================\n";
    print FH "// $copyright\n";
    print FH
"//=============================================================================\n";
    print FH "// Project  : " . $project . "\n";
    print FH "//\n";
    print FH "// File Name: $fname\n";
    print FH "//\n";
    print FH "// Author   : Name         : $name\n";
    print FH "//            Email        : $email\n";
    print FH "//            Tel          : $tel\n";
    print FH "//            Division     : $div\n";
    print FH "//            Department   : $dept\n";
    print FH "//\n";
    print FH "// Version: $version\n";
    print FH "// Code created by EasierUVM Code Generator on $date\n";
    print FH
"//=============================================================================\n";
    print FH "// Description:\n";
    print FH "//\n";
    print FH "// $descript\n";
    print FH "//\n";
    print FH
"//=============================================================================\n\n";
}

sub gen_if {
    $dir = $project . "/tb/" . $agent_name;
    open( FH, ">" . $dir . "/sv/" . $agent_name . "_if.sv" )
      || die("Exiting due to Error: can't open interface: $agent_name");

	write_file_header "${agent_name}_if.sv", "Signal interface for agent $agent_name";

    print FH "`ifndef " . uc($agent_name) . "_IF_SV\n";
    print FH "`define " . uc($agent_name) . "_IF_SV\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "interface " . $agent_if . "(); \n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n";
    print FH "  import " . $agent_name . "_pkg::*;\n\n";

    foreach $ele (@inc_file_list) {
        if ( $ele ne "" ) {
            print FH "  `include \"" . $ele, "\"\n";
        }
    }
    print FH "\n";

    ### iterate through port list (for now)
    foreach $port_decl (@agent_port_array) {
        print FH "  " . $port_decl, "\n";
    }
    print FH "\n";
    print FH "  // add your properties here.\n";
    print FH "  // property name;\n";
    print FH "\n";
    print FH "  // endproperty : name\n";
    print FH "\n";
    print FH "  // label: assert property(name);\n";
    print FH "\n";
    print FH "endinterface : " . $agent_if . "\n\n";
    print FH "`endif // " . uc($agent_name) . "_IF_SV\n\n";
    close(FH);
}    #end gen_if

sub gen_common {
    $dir = $project . "/tb/" . $agent_name;
    open( FH, ">" . $dir . "/sv/" . $agent_name . "_common.sv" )
      || die("Exiting due to Error: can't open common : $agent_name");
    
	write_file_header "${agent_name}_common.sv", "Base types for $agent_name";

    print FH "`ifndef " . uc($agent_name) . "_COMMON_SV\n";
    print FH "`define " . uc($agent_name) . "_COMMON_SV\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "//  parameters\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "//  typedefs\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "//  classes\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "//  methods\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "//  misc\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n\n";
    print FH "`endif // " . uc($agent_name) . "_COMMON_SV\n\n";
    close(FH);
}

sub gen_seq_item {
    printf LOGFILE "AGENT-ITEM: $agent_item\n";
    $dir = $project . "/tb/" . $agent_name;
    open( FH, ">" . $dir . "/sv/" . $agent_item . ".sv" )
      || die("Exiting due to Error: can't open data_item: $agent_item");

	write_file_header "${agent_name}_seq_item.sv", "Sequence item for ${agent_name}_sequencer";

    print FH "`ifndef " . uc($agent_name) . "_SEQ_ITEM_SV\n";
    print FH "`define " . uc($agent_name) . "_SEQ_ITEM_SV\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "class $agent_item  extends uvm_sequence_item; \n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n";
    print FH "  // UVM Factory Registration Macro\n";
    print FH "\n";
    print FH "  `uvm_object_utils(" . $agent_item . ")\n";
    print FH "\n";
    print FH "  // class properties\n";

    foreach my $var_decl (@agent_var_array) {
        print FH "  $var_decl\n";
    }
    print FH "\n";
    print FH "  //------------------------------------------\n";
    print FH "  // Constraints\n";
    print FH "  //------------------------------------------\n";
    print FH "\n";
    if ($agent_var_cnstr_counter) {
        my $cnstr_count = 0;
        foreach my $cnstr (@agent_var_cnstr_array) {
            print FH "  constraint c$cnstr_count $cnstr\n";
            $cnstr_count++;
        }
    }
    print FH "\n";
    print FH "  //------------------------------------------\n";
    print FH "  // Methods\n";
    print FH "  //------------------------------------------\n";
    print FH "\n";
    print FH "  extern function new(string name=\"\");\n";
    print FH "  extern function void do_copy(uvm_object rhs);\n";
    print FH
"  extern function bit  do_compare(uvm_object rhs, uvm_comparer comparer);\n";
    print FH "  extern function string convert2string();\n";
    print FH "  extern function void do_print(uvm_printer printer);\n";
    print FH "  extern function void do_record(uvm_recorder recorder);\n";
    print FH "\n";
    print FH "endclass : $agent_item \n\n";
    print FH "\n";
    print FH "//------------------------------------------\n";
    print FH "// Implementations\n";
    print FH "//------------------------------------------\n";
    print FH "\n";
    print FH "function "
      . $agent_item
      . "::new(string name = \"\");\n";
    print FH "  super.new(name);\n";
    print FH "endfunction : new\n";
    print FH "\n";
    print FH "function void " . $agent_item . "::do_copy(uvm_object rhs);\n";
    print FH "  " . $agent_item . " rhs_;\n";
    print FH "\n";
    print FH "  if(!\$cast(rhs_, rhs))\n";
    print FH "    `uvm_fatal(\"do_copy\", \"cast of rhs object failed\")\n";
    print FH "  super.do_copy(rhs);\n";
    print FH "  // Copy over data members:\n";

    PROC_VAR:foreach my $var_decl (@agent_var_array) {
        print LOGFILE "var_decl=", $var_decl, "\n";
        #print  "var_decl=", $var_decl, "\n";
		if ( $var_decl =~ m/^const\s+/ ) {
          print  "WARNING: CONSTANT TRANS_VAR $var_decl not adding to copy/compare functions!\n";
		  next PROC_VAR;
		}
		if ( $var_decl =~ m/^static\s+/ ) {
          print  "WARNING: STATIC TRANS_VAR $var_decl not adding to copy/compare functions!\n";
		  next PROC_VAR;
		}
		if ( $var_decl =~ m/^typedef\s+/ ) {
          print LOGFILE "Found type definition $var_decl\n";
		  next PROC_VAR;
		}
        @fields = split /[\s\[\]]+/, $var_decl; #split on space and/or '[' or ']'

        # get name of field to print, has to work with following examples
        # rand bit [7:0] payload []; //name is field 3
		# logic signed [3:0][7:0] vec; //name is field 4
		# bit parity; //name is field 1
        my $pf = 1;    #name field in simplest case
        if ( $fields[0] =~ m/rand/ ) {
            #starts with "rand" so skip
            $pf++;
        }
        if ( $fields[$pf] =~ m/signed|unsigned/ ) {

            #skip signed or unsigned modifier
            $pf++;
        }
        while ( $fields[$pf] =~ m/^\d+:\d+/ ) {

            #skip packed dimensions (i.e. bit [7:0]
           $pf++;
        }
        #if ( (@fields > $pf + 1) && $fields[ $pf + 1 ] =~ m/\]/ ) {

            #is an unpacked array (e.g. payload []
            #print LOGFILE "this is an unpacked array \n";
        #}
		my $var_name =  $fields[$pf];
        $var_name =~ s/;//;   #remove trailing ';'
        print FH "  $var_name = rhs_.${var_name};\n";
        $props[ $count++ ] = $var_name;
		#print "var name = $var_name\n";
    }
    print FH "\n";
    print FH "endfunction : do_copy\n";
    print FH "\n";
    print FH "function bit "
      . $agent_item
      . "::do_compare(uvm_object rhs, uvm_comparer comparer);\n";
    print FH "  " . $agent_item . " rhs_;\n";
    print FH "\n";
    print FH "  if(!\$cast(rhs_, rhs))\n";
    print FH "    `uvm_fatal(\"do_copy\", \"cast of rhs object failed\")\n";
    print FH "  return super.do_compare(rhs, comparer) &&\n";
    $propsize = @props;

    foreach $i ( 0 .. @props - 1) {
        if ( $props[$i] ne "" ) {
            $field = $props[$i];
            if ( $i < $propsize - 1 ) {
                print FH "  " . $field . " == rhs_." . $field . " &&\n";
            }
            else {
                print FH "  " . $field . " == rhs_." . $field . ";\n";
            }
        }
    }
    print FH "\n";
    print FH "endfunction : do_compare\n";
    print FH "\n";
    print FH "function string " . $agent_item . "::convert2string();\n";
    print FH "  string s;\n";
    print FH "\n";
    print FH "  \$sformat(s, \"%s\\n\", super.convert2string());\n";
    print FH "\n";
    print FH "  // generate a string like this\n";
    print FH "  \$sformat(s, \"%s\\n";

    foreach $i ( 0 .. @props - 1) {
        if ( $props[$i] ne "" ) {
            $field = $props[$i];
            print FH "  " . $field . " = \\t%0h\\n";
        }
    }
    print FH "\", get_full_name(),";
    foreach $i ( 0 .. @props - 1) {
        if ( $props[$i] ne "" ) {
            $field = $props[$i];
            if ( $i < $propsize - 1 ) {
                print FH "  " . $field . ",";
            }
            else {
                print FH "  " . $field . ");\n";
            }
        }
    }
    print FH "  return s;\n";
    print FH "endfunction : convert2string\n";
    print FH "\n";
    print FH "function void "
      . $agent_item
      . "::do_print(uvm_printer printer);\n";
    print FH "  if(printer.knobs.sprint == 0)\n";
    print FH "    `uvm_info(get_type_name(), convert2string(), UVM_MEDIUM)\n";
    print FH "  else\n";
    print FH "    printer.m_string = convert2string();\n";
    print FH "endfunction : do_print\n";
    print FH "\n";
    print FH "function void "
      . $agent_item
      . "::do_record(uvm_recorder recorder);\n";
    print FH "  super.do_record(recorder);\n";
    print FH "\n";
    print FH "  // Use the record macros to record the item fields:\n";

    foreach $i ( 0 .. @props - 1 ) {
        if ( $props[$i] ne "" ) {
            $field = $props[$i];
            print FH "  `uvm_record_field(\"" . $field . "\", " . $field
              . ")\n";
        }
    }
    print FH "endfunction : do_record\n";
    print FH "\n";
    print FH "`endif // " . uc($agent_name) . "_SEQ_ITEM_SV\n\n";

    close(FH);
}    #end gen_data_item

sub gen_driver {
    $dir = $project . "/tb/" . $agent_name;
    open( FH, ">" . $dir . "/sv/" . $agent_name . "_driver.sv" )
      || die("Exiting due to Error: can't open driver: $agent_name");

	write_file_header "${agent_name}_driver.sv", "Driver for $agent_name";

    print FH "`ifndef " . uc($agent_name) . "_DRIVER_SV\n";
    print FH "`define " . uc($agent_name) . "_DRIVER_SV\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "class "
      . $agent_name
      . "_driver extends uvm_driver #("
      . $agent_item . ");\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n";
    print FH "  `uvm_component_utils(" . $agent_name . "_driver)\n";
    print FH "\n";
    print FH "  virtual " . $agent_if . " vif;\n";
    print FH "\n";
    print FH "  extern function new(string name, uvm_component parent);\n";
    print FH "  extern task run_phase(uvm_phase phase);\n";
    print FH "  extern function void report_phase(uvm_phase phase);\n";

    #    print FH "  extern task do_reset();\n";
    print FH "  extern task do_drive();\n";
    print FH "endclass : " . $agent_name . "_driver \n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "// " . $agent_name . "_driver implementation\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "function "
      . $agent_name
      . "_driver::new(string name, uvm_component parent);\n";
    print FH "  super.new(name,parent);\n";
    print FH "endfunction : new\n";
    print FH "\n";
    print FH "task " . $agent_name . "_driver::run_phase(uvm_phase phase);\n";

    #  print FH "  // add additional declarations here\n";
    #  print FH "  super.run_phase(phase);\n";
    print FH "  `uvm_info(get_type_name(),\"run_phase\",UVM_HIGH)\n";

    #    print FH "  // set signals on reset values here\n";
    #               $agent_reset = @agent_reset_array[0];
    #  print FH "  @(posedge vif.".$agent_reset.") // reset goes inactive\n";
    #    print FH "  do_reset();\n";
    print FH "  forever\n";
    print FH "    begin\n";
    print FH "      seq_item_port.get_next_item(req);\n";
    my $agent_clock = $agent_clock_array[0];

    #	if ($agent_clock ne ""){
    #     print FH "    @(posedge vif.".$agent_clock.")\n";
    #               }
    print FH
"      `uvm_info(get_type_name(), {\"req item\\n\",req.sprint}, UVM_MEDIUM)\n";
    print FH "      // insert the driver protocol here\n";
    print FH "      do_drive();\n";
    print FH "      \$cast(rsp, req.clone());\n";
    print FH "      // adopt the rsp\n";
    print FH "      seq_item_port.item_done();\n";
    if ( not $agent_clock or $agent_clock eq "" ) {
        print FH "      # 10ns;\n";
    }
    print FH "    end\n";
    print FH "endtask : run_phase\n";
    print FH "\n";
    print FH "function void "
      . $agent_name
      . "_driver::report_phase(uvm_phase phase);\n";
    print FH
      "  `uvm_info(get_type_name(), \"Reached end of stimulus\", UVM_HIGH);\n";
    print FH "  //fill in any reporting code if needed\n";
    print FH "endfunction : report_phase\n\n";

    #if include file for driver exists, pull it in here, otherwise
    #create empty do_drive tasks
    if ( exists $agent_drv_inc{$agent_name}
        && -e "${project}/tb/include/$agent_drv_inc{$agent_name}" )
    {
        print FH "`include \"$agent_drv_inc{$agent_name}\"\n\n";
    }
    else {
        #		print FH "task ${agent_name}_driver::do_reset();\n";
        #		print FH "  //add code for driver reset here...\n";
        #		print FH "endtask : do_reset\n\n";
        print FH "task ${agent_name}_driver::do_drive();\n";
        print FH "  //add code for driver protocol here...\n";
        print FH "endtask : do_drive\n";
    }
    print FH "`endif // " . uc($agent_name) . "_DRIVER_SV\n\n";
    close(FH);
}

sub gen_monitor {
    $dir = $project . "/tb/" . $agent_name;
    open( FH, ">" . $dir . "/sv/" . $agent_name . "_monitor.sv" )
      || die("Exiting due to Error: can't open monitor: $agent_name");

	write_file_header "${agent_name}_monitor.sv", "Monitor for $agent_name";
	  

    print FH "`ifndef " . uc($agent_name) . "_MONITOR_SV\n";
    print FH "`define " . uc($agent_name) . "_MONITOR_SV\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "class " . $agent_name . "_monitor extends uvm_monitor;\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n";
    print FH "`uvm_component_utils(" . $agent_name . "_monitor)\n";
    print FH "\n";
    print FH "  virtual $agent_if vif;\n\n";
    print FH "  uvm_analysis_port #(${agent_item}) ap;\n\n";
    print FH "  ${agent_name}_config  cfg;\n";
    print FH "  ${agent_item} trans;\n";
    print FH "  extern function new(string name, uvm_component parent);\n";
    print FH "  extern function void build_phase(uvm_phase phase);\n";
    print FH "  extern task run_phase(uvm_phase phase);\n";
    print FH "  extern task do_mon();\n";
    print FH "endclass : " . $agent_name . "_monitor \n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "// " . $agent_name . "_monitor implementation\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "function "
      . $agent_name
      . "_monitor::new(string name, uvm_component parent);\n";
    print FH "  super.new(name,parent);\n";
    print FH "endfunction : new\n";
    print FH "\n";
    print FH "function void "
      . $agent_name
      . "_monitor::build_phase(uvm_phase phase);\n";
    print FH "  ap = new(\"ap\", this);\n";
    print FH "endfunction : build_phase\n";
    print FH "\n";
    print FH "task ${agent_name}_monitor::run_phase(uvm_phase phase);\n";
    print FH "  $agent_item trans_clone;\n\n";
    print FH "  `uvm_info(get_type_name(),\"run_phase\",UVM_MEDIUM)\n";
    print FH "  trans = ${agent_item}::type_id::create(\"trans\");\n";
    print FH "  do_mon();\n";
    print FH "endtask : run_phase\n\n";

    #if include file for monitor exists, pull it in here, otherwise
    #create empty do_mon task
    if ( exists $agent_mon_inc{$agent_name}
        && -e "${project}/tb/include/$agent_mon_inc{$agent_name}" )
    {
        print FH "`include \"$agent_mon_inc{$agent_name}\"\n\n";
    }
    else {
        print FH "task ${agent_name}_monitor::do_mon();\n";
        print FH "  //add code for monitor protocol here...\n";
        print FH "endtask : do_mon\n";
    }
    print FH "\n";
    print FH "`endif // " . uc($agent_name) . "_MONITOR_SV\n\n";
    close(FH);
}

sub gen_sequencer {
    $dir = $project . "/tb/" . $agent_name;
    open( FH, ">" . $dir . "/sv/" . $agent_name . "_sequencer.sv" )
      || die("Exiting due to Error: can't open sequencer: $agent_name");
 	write_file_header "${agent_name}_sequencer.sv", "Sequencer for $agent_name";

    print FH "`ifndef " . uc($agent_name) . "_SEQUENCER_SV\n";
    print FH "`define " . uc($agent_name) . "_SEQUENCER_SV\n\n";

    if ( $agent_seqr_class =~ /y|yes/i ) {
        print FH
"//-----------------------------------------------------------------------------\n";
        print FH "class "
          . $agent_name
          . "_sequencer extends uvm_sequencer #("
          . $agent_item . ");\n";
        print FH
"//-----------------------------------------------------------------------------\n";
        print FH "\n";
        print FH "  `uvm_component_utils(" . $agent_name . "_sequencer)\n";
        print FH "\n";
        print FH "  extern function new(string name, uvm_component parent);\n\n";
        print FH "endclass : " . $agent_name . "_sequencer \n\n";
        print FH
"//-----------------------------------------------------------------------------\n";
        print FH "// " . $agent_name . "_sequencer implementation\n";
        print FH
"//-----------------------------------------------------------------------------\n";
        print FH "function "
          . $agent_name
          . "_sequencer::new(string name, uvm_component parent);\n";
        print FH "  super.new(name,parent);\n";
        print FH "endfunction : new\n";
    }
    else {
        print FH
"//-----------------------------------------------------------------------------\n";
        print FH "// Sequencer class is specialization of uvm_sequencer\n";
        print FH "typedef uvm_sequencer #("
          . $agent_item . ") "
          . $agent_name
          . "_sequencer;\n";
        print FH
"//-----------------------------------------------------------------------------\n";

    }
    print FH "\n";
    print FH "`endif // " . uc($agent_name) . "_SEQUENCER_SV\n\n";
    close(FH);
}

sub gen_config {
    $dir = $project . "/tb/" . $agent_name;
    open( FH, ">" . $dir . "/sv/" . $agent_name . "_config.sv" )
      || die("Exiting due to Error: can't open config: $agent_name");
	write_file_header "${agent_name}_config.sv", "Configuration for agent $agent_name";

    print FH "`ifndef " . uc($agent_name) . "_CONFIG_SV\n";
    print FH "`define " . uc($agent_name) . "_CONFIG_SV\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "class " . $agent_name . "_config extends uvm_object;\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n";
    print FH "  // Don't register with the factory!\n";
    print FH "\n";
    print FH "  virtual " . $agent_name . "_if vif;\n";
    print FH "\n";
    print FH "  //------------------------------------------\n";
    print FH "  // Data Members\n";
    print FH "  //------------------------------------------\n";
    print FH "  // Is the agent active or passive\n";
    print FH "  uvm_active_passive_enum is_active;\n";
    print FH "  bit coverage_enable;\n";
    print FH "  bit checks_enable;\n";
    print FH "\n";
    print FH
"  extern function new(string name = \"\");   //You may add more arguments to the constructor\n";
    print FH "\n";
    print FH "endclass : " . $agent_name . "_config \n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "// " . $agent_name . "_config implementation\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "function "
      . $agent_name
      . "_config::new(string name = \"\");   //You may add more arguments to the constructor\n";
    print FH "  super.new(name);\n";
    print FH "endfunction : new\n\n";
    print FH "`endif // " . uc($agent_name) . "_CONFIG_SV\n\n";
    close(FH);
}

sub gen_cov {
    $dir = $project . "/tb/" . $agent_name;
    open( FH, ">" . $dir . "/sv/" . $agent_name . "_coverage.sv" )
      || die("Exiting due to Error: can't open coverage: $agent_name");

    write_file_header "${agent_name}_coverage.sv", "Coverage for agent $agent_name";

    print FH "`ifndef " . uc($agent_name) . "_COVERAGE_SV\n";
    print FH "`define " . uc($agent_name) . "_COVERAGE_SV\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "class "
      . $agent_name
      . "_coverage extends uvm_subscriber #("
      . $agent_item . ");\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n";
    print FH "`uvm_component_utils(" . $agent_name . "_coverage)\n";
    print FH "  bit is_covered;\n\n";
    print FH "  " . $agent_item . " item;\n\n";
    print FH "  // Insert your covergroups here\n\n";
    print FH "  //------------------------------------------\n";
    print FH "  // Cover Group(s)\n";
    print FH "  //------------------------------------------\n";
    print FH "  covergroup " . $agent_name . "_cov;\n";
    print FH "    option.per_instance = 1;\n";

    #if include file for coverpoints exists, pull it in here, otherwise
    #create coverpoints with default bins
    if ( exists $agent_cover_inc{$agent_name}
        && -e "${project}/tb/include/$agent_cover_inc{$agent_name}" )
    {
        print FH "  // inserting coverpoints from source file\n";
        print FH "  `include \"$agent_cover_inc{$agent_name}\"\n\n";
    }
    else {
        print FH "    // insert your coverpoints here\n";
        print FH "\n";
        $propsize = @props - 1;
        foreach $i ( 0 .. $propsize ) {
            $tmp = $props[$i];
            print FH "    cp_" . $i . ": coverpoint item." . $tmp . ";\n";
            print FH "    //   add bins here\n";
        }
    }
    print FH "  endgroup\n\n";
    print FH "  extern function new(string name, uvm_component parent);\n";
    print FH "  extern function void write(input " . $agent_item . " t);\n";
    print FH "  extern function void report_phase(uvm_phase phase);\n\n";
    print FH "endclass : " . $agent_name . "_coverage \n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "// " . $agent_name . "_coverage implementation\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "function "
      . $agent_name
      . "_coverage::new(string name, uvm_component parent);\n";
    print FH "  super.new(name,parent);\n";
    print FH "  is_covered = 0;\n";
    print FH "  " . $agent_name . "_cov = new();\n";
    print FH "endfunction : new\n";
    print FH "\n";
    print FH "function void "
      . $agent_name
      . "_coverage::write(input "
      . $agent_item
      . " t);\n";
    print FH "  item = t;\n";
    print FH "  ${agent_name}_cov.sample();\n";
    print FH
"  //check coverage - could use ${agent_name}_cov.option.goal instead of 100 if your simulator supports it\n";
    print FH
      "  if (${agent_name}_cov.get_inst_coverage() >= 100) is_covered = 1;\n";
    print FH "endfunction : write\n";
    print FH "\n";
    print FH "function void "
      . $agent_name
      . "_coverage::report_phase(uvm_phase phase);\n";
    print FH
"  `uvm_info(get_type_name(), \$sformatf(\"Coverage score = %3.1f%%\",${agent_name}_cov.get_inst_coverage()), UVM_LOW)\n";
    print FH "endfunction : report_phase\n\n";
    print FH "`endif // " . uc($agent_name) . "_COVERAGE_SV\n\n";
    close(FH);
}

sub gen_agent {
    $dir = $project . "/tb/" . $agent_name;
    open( FH, ">" . $dir . "/sv/" . $agent_name . "_agent.sv" )
      || die("Exiting due to Error: can't open agent: $agent_name");

	write_file_header "${agent_name}_agent.sv", "Agent for $agent_name";

    print FH "`ifndef " . uc($agent_name) . "_AGENT_SV\n";
    print FH "`define " . uc($agent_name) . "_AGENT_SV\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "class ${agent_name}_agent extends uvm_agent;\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n";
    print FH "  `uvm_component_utils(${agent_name}_agent)\n";
    print FH "\n";
    print FH "  uvm_analysis_port #(${agent_item}) ap;\n\n";
    print FH "  ${agent_name}_config m_cfg;\n\n";
    print FH "  ${agent_name}_sequencer m_sequencer;\n";
    print FH "  ${agent_name}_driver m_driver;\n";
    print FH "  ${agent_name}_monitor m_monitor;\n";
    print FH "\n";
    print FH
"  extern function new(string name, uvm_component parent);\n";
    print FH "  extern function void build_phase(uvm_phase phase);\n";
    print FH "  extern function void connect_phase(uvm_phase phase);\n\n";
    print FH "endclass : " . $agent_name . "_agent \n\n";
    print FH "function "
      . $agent_name
      . "_agent::new(string name, uvm_component parent);\n";
    print FH "  super.new(name,parent);\n";
    print FH "endfunction : new\n";
    print FH "\n";
    print FH "function void "
      . $agent_name
      . "_agent::build_phase(uvm_phase phase);\n";
    print FH
"  // call super.build_phase(phase) only if you understand the consequences\n";
    print FH "  // super.build_phase(phase);\n";
    print FH "  if(!uvm_config_db #("
      . $agent_name
      . "_config)::get(this, \"\", \""
      . $agent_name
      . "_config\", m_cfg))\n";
    print FH "    `uvm_error(get_type_name(), \""
      . $agent_name
      . " config not found\")\n";
    print FH
"  `uvm_info(get_type_name(), \$sformatf(\"agent is: %s\", m_cfg.is_active), UVM_MEDIUM)\n";
    print FH
"  `uvm_info(get_type_name(), \$sformatf(\"vif: %p\", m_cfg.vif), UVM_MEDIUM)\n";
    print FH "  m_monitor = "
      . $agent_name
      . "_monitor::type_id::create(\"m_monitor\",this);\n";
    print FH "  ap = new(\"ap\", this);\n";
    print FH "  if (m_cfg.is_active == UVM_ACTIVE)\n";
    print FH "    begin\n";
    print FH "      m_driver    = "
      . $agent_name
      . "_driver::type_id::create(\"m_driver\",this);\n";
    print FH "      m_sequencer = "
      . $agent_name
      . "_sequencer::type_id::create(\"m_sequencer\",this);\n";
    print FH "    end\n";
    print FH "endfunction : build_phase\n";
    print FH "\n";
    print FH "function void "
      . $agent_name
      . "_agent::connect_phase(uvm_phase phase);\n";
    print FH
"  // call super.connect_phase(phase) only if you understand the consequences\n";
    print FH "  // super.connect_phase(phase);\n";
    print FH "  if(m_cfg.vif == null)\n";
    print FH
"    `uvm_fatal(get_type_name(), \"${agent_name} virtual interface is not set!\")\n";
    print FH "  m_monitor.vif = m_cfg.vif;\n";
    print FH "  m_monitor.ap.connect(ap);\n";
    print FH "  if (m_cfg.is_active == UVM_ACTIVE)\n";
    print FH "    begin\n";
    print FH
      "      m_driver.seq_item_port.connect(m_sequencer.seq_item_export);\n";
    print FH "      m_driver.vif = m_cfg.vif;\n";
    print FH "    end\n";
    print FH "endfunction : connect_phase\n";
    print FH "\n";
    print FH "`endif // " . uc($agent_name) . "_AGENT_SV\n\n";
    close(FH);
}

sub gen_env {
    $dir = $project . "/tb/" . $agent_name;
    open( FH, ">" . $dir . "/sv/" . $agent_name . "_env.sv" )
      || die("Exiting due to Error: can't open env: $agent_name");

	write_file_header "${agent_name}_env.sv", "Environment for agent $agent_name";

    print FH "`ifndef " . uc($agent_name) . "_ENV_SV\n";
    print FH "`define " . uc($agent_name) . "_ENV_SV\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "class " . $agent_name . "_env extends uvm_env;\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n";
    print FH "  `uvm_component_utils(" . $agent_name . "_env)\n\n";
    print FH "\n";
    print FH "  ${agent_name}_config m_${agent_name}_cfg;\n";
    print FH "  ${agent_name}_agent  m_${agent_name}_agent;\n";
    print FH "  ${agent_name}_coverage m_${agent_name}_coverage;\n";
    print FH "\n";

    #add any other agents (%env_agents is hash of ref to array)
    do {
        foreach my $extra_agent ( @{ $env_agents{"${agent_name}_env"} } ) {
            print LOGFILE "adding extra agent $extra_agent\n";
            print FH "  ${extra_agent}_config  m_${extra_agent}_cfg;\n";
            print FH "  ${extra_agent}_agent  m_${extra_agent}_agent;\n";
            print FH "  ${extra_agent}_coverage  m_${extra_agent}_coverage;\n";
        }
    } if exists $env_agents{"${agent_name}_env"};
    print FH "  extern function new(string name, uvm_component parent);\n";
    print FH "  extern function void build_phase(uvm_phase phase);\n\n";
    print FH "  extern function void connect_phase(uvm_phase phase);\n\n";
    print FH "endclass : " . $agent_name . "_env \n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "// " . $agent_name . "_config implementation\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "function "
      . $agent_name
      . "_env::new(string name, uvm_component parent);\n";
    print FH "  super.new(name,parent);\n";
    print FH "endfunction : new\n";
    print FH "\n";
    print FH "function void "
      . $agent_name
      . "_env::build_phase(uvm_phase phase);\n";
    print FH
"  // call super.build_phase(phase) only if you understand the consequences\n";
    print FH "  // super.build_phase(phase);\n";
    print FH "  if(!uvm_config_db #("
      . $agent_name
      . "_config)::get(this, \"\", \""
      . $agent_name
      . "_config\", m_${agent_name}_cfg))\n";
    print FH
"    `uvm_error(get_type_name(), \"unable to get config from configuration database\")\n";

    print FH
"  uvm_config_db #(${agent_name}_config)::set(this,\"m_${agent_name}_agent\",\"${agent_name}_config\",m_${agent_name}_cfg);\n";

    print FH
"  m_${agent_name}_agent = ${agent_name}_agent::type_id::create(\"m_${agent_name}_agent\", this);\n";
    print FH
"  m_${agent_name}_coverage= ${agent_name}_coverage::type_id::create(\"m_${agent_name}_coverage\",this);\n";
    do {
        print FH "//other agents\n";
        foreach my $extra_agent ( @{ $env_agents{"${agent_name}_env"} } ) {
            print FH
"  if(!uvm_config_db #(${extra_agent}_config)::get(this, \"\", \"${extra_agent}_config\", m_${extra_agent}_cfg))\n";
            print FH
"    `uvm_error(get_type_name(), \"unable to get ${extra_agent}_config from configuration database\")\n";
            print FH
"  uvm_config_db #(${extra_agent}_config)::set(this,\"m_${extra_agent}_agent\",\"${extra_agent}_config\",  m_${extra_agent}_cfg);\n";
            print FH
"  m_${extra_agent}_agent  = ${extra_agent}_agent::type_id::create(\"m_${extra_agent}_agent\",this);\n";
            print FH
"  m_${extra_agent}_coverage = ${extra_agent}_coverage::type_id::create(\"m_${extra_agent}_coverage\",this);\n";
        }
    } if exists $env_agents{"${agent_name}_env"};
    print FH "endfunction : build_phase\n";
    print FH "\n";

    print FH "function void "
      . $agent_name
      . "_env::connect_phase(uvm_phase phase);\n";
    print FH
"  // call super.connect_phase(phase) only if you understand the consequences\n";
    print FH "  // super.connect_phase(phase);\n";
    print FH
"  m_${agent_name}_agent.ap.connect(m_${agent_name}_coverage.analysis_export);\n";
    do {

        foreach my $extra_agent ( @{ $env_agents{"${agent_name}_env"} } ) {
            print FH
"  m_${extra_agent}_agent.ap.connect(m_${extra_agent}_coverage.analysis_export);\n";
        }
    } if exists $env_agents{"${agent_name}_env"};
    print FH "endfunction : connect_phase\n";
    print FH "\n";

    print FH "`endif // " . uc($agent_name) . "_ENV_SV\n\n";
    close(FH);
}

sub gen_seq_lib {
    $dir = $project . "/tb/" . $agent_name;
    open( FH, ">" . $dir . "/sv/" . $agent_name . "_seq_lib.sv" )
      || die("Exiting due to Error: can't open seq_lib: $agent_name");

	write_file_header "${agent_name}_seq_lib.sv", "Sequence library for agent $agent_name";

    print FH "`ifndef " . uc($agent_name) . "_SEQ_LIB_SV\n";
    print FH "`define " . uc($agent_name) . "_SEQ_LIB_SV\n\n";
    print FH
"//=============================================================================\n";
    print FH "// Sequence    : " . $agent_name . "_base_seq\n";
    print FH
      "// Using       : <list of sub-sequences used by this sequences>\n";
    print FH "// Description : Common base sequence for all sequences\n";
    print FH
"//=============================================================================\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "class "
      . $agent_name
      . "_base_seq extends uvm_sequence #($agent_item);\n";
    print FH
"//-----------------------------------------------------------------------------\n\n";
    print FH "  `uvm_object_utils(" . $agent_name . "_base_seq)\n";
    print FH "\n";
    print FH "  " . $agent_name . "_config  cfg;\n";
#    print FH "  " . $agent_item . "  item;\n";
    print FH "  extern function new(string name = \"\");\n";
    print FH "  extern task body();\n\n";
    print FH "endclass : " . $agent_name . "_base_seq\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "// " . $agent_name . "_base_seq implementation\n";
    print FH
"//-----------------------------------------------------------------------------\n\n";
    print FH "function "
      . $agent_name
      . "_base_seq::new(string name = \"\");\n";
    print FH "  super.new(name);\n";
    print FH "endfunction : new\n";
    print FH "\n";
    print FH "task " . $agent_name . "_base_seq::body();\n";
    print FH "  `uvm_info(get_type_name(),\""
      . $agent_name
      . "_base_seq\", UVM_MEDIUM)\n";
    print FH "endtask : body\n";
    print FH "\n";
    print FH
"//=============================================================================\n";
    print FH "// Sequence    : " . $agent_name . "_default_seq\n";
    print FH
      "// Using       : <list of sub-sequences used by this sequences>\n";
    print FH "// Description : Sequence generating 1 item;\n";
    print FH
"//=============================================================================\n";
    print FH "class "
      . $agent_name
      . "_default_seq extends "
      . $agent_name
      . "_base_seq;\n\n";
    print FH "  `uvm_object_utils(" . $agent_name . "_default_seq)\n";
    print FH "\n";
    $count          = 0;
    # @rand_var_array = ();

    # foreach $var_decl (@agent_var_array) {
        # @fields = split /\s+/, $var_decl;
        # $fieldsle = @fields;
        # $pf =
          # 0;    #default field to print (bit parity, want to print field 1 here)
        # if ( $fields[$pf] =~ m/rand/ ) {

            # #starts with "rand"
            # print FH "  " . $var_decl . "\n";
            # $rand_var_array[ $count++ ] = $fields[ $fieldsle - 1 ];
        # }
    # }
    # print FH "\n";
    print FH "  extern function new(string name = \"\");\n";
    print FH "  extern task body();\n\n";
    print FH "endclass : " . $agent_name . "_default_seq\n";
    print FH "\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "// " . $agent_name . "_default_seq implementation\n";
    print FH
"//-----------------------------------------------------------------------------\n\n";
    print FH "function "
      . $agent_name
      . "_default_seq::new(string name = \"\");\n";
    print FH "  super.new(name);\n";
    print FH "endfunction : new\n";
    print FH "\n";
    print FH "task " . $agent_name . "_default_seq::body();\n";
    print FH
"  `uvm_info(get_type_name(),\"default sequence starting\", UVM_MEDIUM)\n";
    print FH "  super.body();\n";
    print FH "  req = " . $agent_item . "::type_id::create(\"req\");\n";
    print FH "  start_item(req); \n";
    print FH "  if ( !req.randomize() )\n";
    print FH "    `uvm_warning(get_type_name(),\"randomization failed!\")\n";
    print FH "  finish_item(req); \n";
    print FH
"  `uvm_info(get_type_name(),\"default sequence completed\", UVM_MEDIUM)\n\n";
    #print FH "  // Alternatively use macros\n";
    #print FH "  // `uvm_do_with(item, {\n";

#    foreach $ele (@rand_var_array) {
#        s/;// for $ele;
#        print FH "       //  item." . $ele . " == " . $ele . ";\n";
#    }
#    print FH "  // })\n\n";
    print FH "endtask : body\n\n";

    #include sequence file (if specified)
    print FH "`include \"$agent_seq_inc{$agent_name}\"\n\n"
      if exists $agent_seq_inc{$agent_name} and $agent_seq_inc{$agent_name} ne "";

    print FH "//additional sequences can be included in this file\n\n";
    print FH "`endif // " . uc($agent_name) . "_SEQ_LIB_SV\n\n";

    close(FH);
}

sub gen_env_seq_lib {
    $dir = $project . "/tb/" . $agent_name;
    open( FH, ">" . $dir . "/sv/" . $agent_name . "_env_seq_lib.sv" )
      || die("Exiting due to Error: can't open env_seq_lib: $agent_name");

	write_file_header "${agent_name}_env_seq_lib.sv", "Sequence library for $agent_name";

    print FH "`ifndef " . uc($agent_name) . "_ENV_SEQ_LIB_SV\n";
    print FH "`define " . uc($agent_name) . "_ENV_SEQ_LIB_SV\n\n";
    print FH
"//=============================================================================\n";
    print FH "// Sequence    : " . $agent_name . "_env_base_seq\n";
    print FH
      "// Using       : <list of sub-sequences used by this sequences>\n";
    print FH
      "// Description : Common base sequence for all virtual sequences\n";
    print FH
"//=============================================================================\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "class " . $agent_name . "_env_base_seq extends uvm_sequence;\n";
    print FH
"//-----------------------------------------------------------------------------\n\n";
    print FH "  `uvm_object_utils(" . $agent_name . "_env_base_seq)\n\n";
    print FH "\n";
    print FH "  " . $agent_name . "_env m_env;\n";
    print FH
"  //---------------------------------------------------------------------------\n";
    print FH "  // methods\n";
    print FH
"  //---------------------------------------------------------------------------\n\n";
    print FH "  extern function new(string name = \"\");\n";
    print FH "  extern task body();\n";
    print FH
"  //---------------------------------------------------------------------------\n";
    print FH "  // constraints\n";
    print FH
"  //---------------------------------------------------------------------------\n\n";
    print FH "endclass : " . $agent_name . "_env_base_seq\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "// " . $agent_name . "_env_base_seq implementation\n";
    print FH
"//-----------------------------------------------------------------------------\n\n";
    print FH "function "
      . $agent_name
      . "_env_base_seq::new(string name = \"\");\n";
    print FH "  super.new(name);\n";
    print FH "endfunction : new\n\n";
    print FH "task " . $agent_name . "_env_base_seq::body();\n";
    print FH "endtask: body\n\n";
    print FH
"//=============================================================================\n";
    print FH "// Sequence    : " . $agent_name . "_env_default_seq\n";
    print FH "// Using       : <list of sub-sequences used by this sequence>\n";
    print FH
      "// Description : Virtual sequence invoking agent's default sequence;\n";
    print FH
"//=============================================================================\n";
    print FH "class "
      . $agent_name
      . "_env_default_seq extends "
      . $agent_name
      . "_env_base_seq;\n\n";
    print FH "\n";
    print FH "  `uvm_object_utils(" . $agent_name . "_env_default_seq)\n\n";
    print FH "  extern function new(string name = \"\");\n";
    print FH "  extern task body();\n\n";
    print FH "endclass : " . $agent_name . "_env_default_seq\n";
    print FH "\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "// " . $agent_name . "_env_default_seq implementation\n";
    print FH
"//-----------------------------------------------------------------------------\n\n";
    print FH "function "
      . $agent_name
      . "_env_default_seq::new(string name = \"\");\n";
    print FH "  super.new(name);\n";
    print FH "endfunction : new\n\n";
    print FH "task " . $agent_name . "_env_default_seq::body();\n";
    print FH "  super.body();\n";
    print FH "\n";
    print FH
"  `uvm_info(get_type_name(),\"default sequence starting\", UVM_MEDIUM)\n\n";

    print FH
      "  //fork .. join used here since there could be multiple child agents\n";
    print FH "  fork\n";
    print FH "    if (m_env.m_${agent_name}_cfg.is_active == UVM_ACTIVE)\n";
    print FH "      begin\n";
    print FH "        ${agent_name}_base_seq seq;\n";
    print FH "        seq = ${agent_name}_base_seq::type_id::create(\"seq\");\n";
    print FH "        seq.randomize();\n";
    print FH "        seq.start(m_env.m_${agent_name}_agent.m_sequencer,this);\n";
    print FH "      end\n";

    foreach my $extra_agent ( @{ $env_agents{"${agent_name}_env"} } ) {
        print FH
"    if (m_env.m_${extra_agent}_agent.m_cfg.is_active == UVM_ACTIVE)\n";
        print FH "      begin\n";
        print FH "        ${extra_agent}_base_seq seq;\n";
        print FH
          "        seq = ${extra_agent}_base_seq::type_id::create(\"seq\");\n";
        print FH "        seq.randomize();\n";
        print FH
          "        seq.start(m_env.m_${extra_agent}_agent.m_sequencer,this);\n";
        print FH "      end\n";
    }
    print FH "  join\n";
    print FH
"  `uvm_info(get_type_name(),\"default sequence completed\",UVM_MEDIUM)\n";
    print FH "endtask : body\n\n";

    #include sequence file (if specified)
    print FH "`include \"$agent_env_seq_inc{$agent_name}\"\n\n"
      if exists $agent_env_seq_inc{$agent_name} and $agent_env_seq_inc{$agent_name} ne "";

    print FH "//additional sequences can be included in this file\n\n";
    print FH "`endif // " . uc($agent_name) . "_ENV_SEQ_LIB_SV\n\n";

    close(FH);
}

sub gen_agent_inc {

    ### file list for files in sv directory (.svh file)
    $dir = $project . "/tb/" . $agent_name;
    open( FH, ">" . $dir . "/sv/" . $agent_name . ".svh" )
      || die("Exiting due to Error: can't open include file: $agent_name");

	write_file_header "${agent_name}.svh", "Include file for agent $agent_name";

    print FH "`ifndef " . uc($agent_name) . "_SVH\n";
    print FH "`define " . uc($agent_name) . "_SVH\n\n";
    print FH "  // Imports\n";
    print FH "  import uvm_pkg::*;\n";
    print FH "  import " . $tbname . "_common_pkg::*;\n\n";
    do {

        foreach my $extra_agent ( @{ $env_agents{"${agent_name}_env"} } ) {
            print FH "  import ${extra_agent}_pkg::*;\n";
        }
    } if exists $env_agents{"${agent_name}_env"};
    print FH "  // General includes\n";
    print FH "  `include \"uvm_macros.svh\"\n\n";
    print FH "  // AGENT includes\n";
    print FH "  `include \"" . $agent_name . "_common.sv\"\n";
    print FH "  `include \"${agent_item}.sv\"\n";

    #includes for named agent
    print FH "  `include \"" . $agent_name . "_config.sv\"\n";
    print FH "  `include \"" . $agent_name . "_driver.sv\"\n";
    print FH "  `include \"" . $agent_name . "_monitor.sv\"\n";
    print FH "  `include \"" . $agent_name . "_sequencer.sv\"\n";
    print FH "  `include \"" . $agent_name . "_coverage.sv\"\n";
    print FH "  `include \"" . $agent_name . "_agent.sv\"\n";
    print FH "  `include \"" . $agent_name . "_seq_lib.sv\"\n";

  #do not include env or sequence when agent has regmodel (env at next level up)
    do {
        print FH "  `include \"" . $agent_name . "_env.sv\"\n";
        print FH "  `include \"" . $agent_name . "_env_seq_lib.sv\"\n";
      } unless $regmodel
      and exists $agent_sub_access{$agent_name}
      or uc($agent_has_env) eq "NO";

    print FH "\n";
    print FH "`endif // " . uc($agent_name) . "_SV\n\n";
    close(FH);
}

sub gen_agent_pkg {

    ### file list for files in sv directoru (.svh file)
    $dir = $project . "/tb/" . $agent_name;
    open( FH, ">" . $dir . "/sv/" . $agent_name . "_pkg.sv" )
      || die("Exiting due to Error: can't open include file: $agent_name");

	write_file_header "${agent_name}_pkg.sv", "Package for agent $agent_name";

    print FH "  package " . $agent_name . "_pkg;\n\n";
    print FH "    `include \"" . $agent_name . ".svh\"\n\n";
    print FH "  endpackage : " . $agent_name . "_pkg\n\n";
    print FH "  `include \"" . $agent_name . "_if.sv\"\n\n";
    close(FH);
}

sub gen_top_inc {

    ### file list for files in sv directoru (.svh file)
    $dir = $project . "/tb/" . $tbname;
    open( FH, ">" . $dir . "/sv/" . $tbname . ".svh" )
      || die("Exiting due to Error: can't open include file: $tbname");

	write_file_header "${tbname}.svh", "Include file for $tbname";

    print FH "`ifndef " . uc($tbname) . "_SVH\n";
    print FH "`define " . uc($tbname) . "_SVH\n\n";
    print FH "  // Imports\n";
    print FH "  import uvm_pkg::*;\n\n";
    print FH "  // General includes\n";
    print FH "  `include \"uvm_macros.svh\"\n\n";
    print FH "  import regmodel_pkg::*;\n" if $regmodel;

    foreach my $agent (@agent_list) {
        print FH "  import ${agent}_pkg::*;\n"
          ;    #unless grep(/$agent/,@stand_alone_agents);
    }

    do {
        foreach my $agent_env (@env_list) {
            $agent_env =~ /(\w+)_env/;
            print FH "  import ${agent_env}_pkg::*;\n"
              if exists $agent_sub_access{$1};
        }
    } if $regmodel;

    print FH "\n";
    print FH "  // tb includes\n";
    print FH "  `include \"" . $tbname . "_config.sv\"\n";
    print FH "  `include \"" . $tbname . "_env.sv\"\n";
    print FH "  `include \"" . $tbname . "_seq_lib.sv\"\n";
    print FH "\n";
    print FH "`endif // " . uc($tbname) . "_SV\n\n";
    close(FH);
}

sub gen_top_pkg {

    ### file list for files in sv directoru (.svh file)
    $dir = $project . "/tb/" . $tbname;
    open( FH, ">" . $dir . "/sv/" . $tbname . "_pkg.sv" )
      || die("Exiting due to Error: can't open include file: $tbname");

	write_file_header "${tbname}_pkg.sv", "Package for $tbname";

    print FH "  package " . $tbname . "_pkg;\n\n";
    print FH "    `include \"" . $tbname . ".svh\"\n\n";
    print FH "  endpackage : " . $tbname . "_pkg\n\n";
    close(FH);
}

sub gen_dut_inst() {
    my $port_list_file = $dut_pfile;
    open( PFH, $port_list_file )
      or die( "Exiting due to Error: can't open template: "
          . $port_list_file
          . "\n" );
    my $port_list = "(\n";
    my $tab       = "  ";

    #skip empty lines
    my $line = "";
  SKIP_BL: while (<PFH>) {
        if (/\w+/) {
            $line = $_;
            last SKIP_BL;
        }
    }
    $line
      or die "Exiting due to Error: dut_pfile $dut_pfile exists but is empty\n";
    my $if_name  = $1;
    my $var_list = "";
  PROC_INTF: while ($line) {
        print LOGFILE "Writing ports for interface $if_name\n" if $if_name;
        while ($line) {
            if ( $line =~ m/\s*#/ ) {    #script comments - ignore
                $line = <PFH>;
                next PROC_INTF;
            }
            elsif ( $line =~ m!\s*//.*\n! ) {    #SV comments
                $port_list .= "$tab$tab$&";
            }
            elsif ( $line =~ /^\s*(\S+)\s+(\S+)\s*\n/ ) {    #ports
                if ($if_name) {
                    $port_list .= "$tab$tab.$1(${if_name}0.$2),\n";
                }
                else {
                    $port_list .= "$tab$tab.$1($2),\n";
                }
            }
            elsif ( $line =~ /\s*DEC\s*\|\s*(.+)\s*\n/ ) {    #variable dec
                $var_list .= $tab . $1 . ";\n";
            }
            elsif ( $line =~ /!(\w+){0,1}/ ) {                #next if_name
                $if_name = ( $1 and $1 ne "none" ) ? $1 : "";
                $line = <PFH>;
                next PROC_INTF;
            }
            $line = <PFH>;
        }
    }    #PROC_INTF

    #remove trailing newline and ','
    chop($port_list);
    chop($port_list);
    $port_list .= "\n  );";

    print FH "$var_list\n";
    print FH "  $dut_top $dut_iname ";
    print FH "$port_list\n";
}


sub gen_top_env {
    $dir = $project . "/tb/" . $tbname;
    open( FH, ">" . $dir . "/sv/" . $tbname . "_env.sv" )
      || die("Exiting due to Error: can't open env: $tbname");

	write_file_header "${tbname}_env.sv", "Environment for $tbname";

    print FH "`ifndef " . uc($tbname) . "_ENV_SV\n";
    print FH "`define " . uc($tbname) . "_ENV_SV\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "class " . $tbname . "_env extends uvm_env;\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n";
    print FH "  `uvm_component_utils(" . $tbname . "_env)\n\n";
    print FH "\n";

    print FH "\n  //Child Environments\n";
    foreach my $agent (@agent_list) {
        print FH "  ${agent}_env\tm_${agent}_env;\n"
          unless grep( /$agent/, @stand_alone_agents )
          or ( $agent eq "" );
    }

    print FH "\n  //Configuration objects for child environments\n";
    foreach my $agent (@agent_list) {
        if ( $regmodel and exists $agent_sub_access{$agent} ) {
            print FH "  ${agent}_env_config\tm_${agent}_env_cfg;\n";
        }
        else {
            print FH "  ${agent}_config\tm_${agent}_cfg;\n"
              unless grep( /$agent/, @top_env_agents )
              or ( $agent eq "" );
        }
    }

    print FH "\n  //Child Agents\n";
    foreach $aname (@top_env_agents) {
        print FH "  ${aname}_agent\tm_${aname}_agent;\n";
        print FH "  ${aname}_config\tm_${aname}_cfg;\n";
        print FH "  ${aname}_coverage\tm_${aname}_coverage;\n";
    }

    if ( $regmodel_name ne "" ) {
        print FH "\n  //Register model\n";
        print FH "  $regmodel_name regmodel;\n";
    }

    print FH "\n";
    print FH "  " . $tbname . "_config\tm_cfg;\n\n";
    print FH "  //" . $tbname . "_scoreboard\tm_scoreboard;\n\n";
    print FH
"  extern function new(string name, uvm_component parent);\n";
    print FH "  extern function void build_phase(uvm_phase phase);\n";
    print FH "  extern function void connect_phase(uvm_phase phase);\n";
    print FH "  extern function void end_of_elaboration_phase(uvm_phase phase);\n";
    print FH "  extern function void check_phase(uvm_phase phase);\n";
    print FH "endclass : " . $tbname . "_env \n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "// " . $tbname . "_env implementation\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH
"function ${tbname}_env::new(string name, uvm_component parent);\n";
    print FH "  super.new(name,parent);\n";
    print FH "endfunction : new\n";
    print FH "\n";
    print FH "function void ${tbname}_env::build_phase(uvm_phase phase);\n";
    print FH
"  // call super.build_phase(phase) only if you understand the consequences\n";
    print FH "  // super.build_phase(phase);\n";
    print FH "  `uvm_info(get_type_name(), \"In build_phase\", UVM_HIGH)\n";
    print FH
"  if (!uvm_config_db #(${tbname}_config)::get(this, \"\", \"${tbname}_config\", m_cfg)) \n";
    print FH
      "    `uvm_error(get_type_name(), \"unable to get ${tbname}_config\")\n";

    do {
        print FH "  regmodel = m_cfg.regmodel;\n";
        print FH "\n";
        print FH "  // Test for top-level environment\n";
        print FH "  if (regmodel == null) \n";
        print FH
          "  begin  //is top-level so need to create register model here...\n";
        print FH
          "     regmodel = ${regmodel_name}::type_id::create(\"regmodel\");\n";
        print FH "    regmodel.build();\n";
        print FH "  end\n";
    } if $regmodel and $regmodel_name ne "";

    foreach my $agent (@agent_list) {
        if ( $agent ne "" ) {
            if ( $regmodel and exists $agent_sub_access{$agent} ) {

                #build envs that access regmodel
                print FH
                  "  m_${agent}_env_cfg = new(\"m_${agent}_env_cfg\");\n";
                print FH "  m_${agent}_env_cfg.vif = m_cfg.${agent}_vif;\n";
                print FH "  m_${agent}_env_cfg.is_active = m_cfg.is_active_${agent};\n";
                print FH
"  if (m_${agent}_env_cfg.is_active != UVM_ACTIVE)\n    `uvm_warning(get_type_name(), \"front-door register access requires active agent but current setting is UVM_PASSIVE!\")\n";
                print FH "  m_${agent}_env_cfg.regmodel = regmodel.${agent};\n"
                  if $regmodel_name;
                print FH "  m_${agent}_env_cfg.checks_enable = m_cfg.checks_enable_${agent};\n";
                print FH "  m_${agent}_env_cfg.coverage_enable = m_cfg.coverage_enable_${agent};\n";
                print FH
"  uvm_config_db #(${agent}_env_config)::set(this, \"m_${agent}_env\", \"${agent}_env_config\", m_${agent}_env_cfg);\n\n";
            }
            else {
                print FH "  m_${agent}_cfg = new(\"m_${agent}_cfg\");\n";
                print FH "  m_${agent}_cfg.vif = m_cfg.${agent}_vif;\n";
                print FH "  m_${agent}_cfg.is_active = m_cfg.is_active_${agent};\n";
                print FH "  m_${agent}_cfg.checks_enable = m_cfg.checks_enable_${agent};\n";
                print FH "  m_${agent}_cfg.coverage_enable = m_cfg.coverage_enable_${agent};\n";
                if ( grep( /$agent/, @stand_alone_agents ) ) {
                    if ( grep( /$agent/, @top_env_agents ) ) {

                        #need to add cfg to agent
                        print FH
"  uvm_config_db #(${agent}_config)::set(this, \"m_${agent}_agent\", \"${agent}_config\", m_${agent}_cfg);\n\n";
                    }
                    else {
                        #need to add cfg to env that contains agent
                        print FH
"  uvm_config_db #(${agent}_config)::set(this, \"m_$agent_parent{$agent}_env\", \"${agent}_config\", m_${agent}_cfg);\n\n";
                    }
                }
                else {
                    #add cfg to agent's own env
                    print FH
"  uvm_config_db #(${agent}_config)::set(this, \"m_${agent}_env\", \"${agent}_config\", m_${agent}_cfg);\n\n";
                }
            }
        }
    }

    print FH "\n";
    foreach my $agent (@agent_list) {
        print FH "  m_${agent}_env = ${agent}_env::type_id::create(\"m_${agent}_env\", this);\n"
          if ( $agent ne "" )
          and !grep( /$agent/, @stand_alone_agents );
    }

    foreach my $aname (@top_env_agents) {
        print FH "  m_${aname}_agent = ${aname}_agent::type_id::create(\"m_${aname}_agent\", this);\n";
		print FH "  if (m_${aname}_cfg.coverage_enable)\n";
        print FH "    m_${aname}_coverage = ${aname}_coverage::type_id::create(\"m_${aname}_coverage\", this);\n";
    }

    print FH "\n";
    print FH
"  //m_scoreboard = ${tbname}_scoreboard::type_id::create(\"m_scoreboard\", this);\n\n";
    print FH "endfunction : build_phase\n\n";

    #connect phase
    print FH "function void ${tbname}_env::connect_phase(uvm_phase phase);\n\n";
    print FH
"  // call super.connect_phase(phase) only if you understand the consequences\n";
    print FH "  // super.connect_phase(phase);\n";
    print FH "  `uvm_info(get_type_name(), \"In connect_phase\", UVM_HIGH)\n";

    foreach my $env (@env_list) {
        print FH
"  `uvm_info(get_type_name(), \$sformatf(\"m_${env}: %p\\n\",m_${env}), UVM_MEDIUM)\n"
          if ( $env ne "" );
    }
    print FH "\n";
    foreach my $agent (@agent_list) {
        print FH
"  //m_${agent}_env.m_${agent}_agent.ap.connect(m_scoreboard.${agent}_analysis_export);\n"
          unless grep( /$agent/, @stand_alone_agents )
          or ( $agent eq "" );
    }

    foreach my $aname (@top_env_agents) {
        print FH
"  //m_${aname}_agent.ap.connect(m_scoreboard.${aname}_analysis_export);\n";
		print FH "  if (m_${aname}_cfg.coverage_enable)\n";
        print FH "    m_${aname}_agent.ap.connect(m_${aname}_coverage.analysis_export);\n";
    }

#	print FH "  //m_scoreboard.".$agent_access_name."_regs = ".$agent_access_name."_regs;\n\n";
#print FH "//  uvm_config_db \#(".$tbname."_config)::set(null, \"*\", \"".$tbname."_config\", cfg);\n";

    #print FH "  // Set up the agent sequencers as resources\n";

#foreach  my $agent (@agent_list) {
#	print FH "  uvm_config_db \#(${agent}_sequencer)::set(null, \"*\", \"${agent}_sequencer\", m_${agent}_env.m_${agent}_agent.m_sequencer);\n"
#		if ($agent ne "");
#}
    do {
        my @agent_reg_list = keys(%agent_sub_names);

# foreach my $agent_reg (@agent_reg_list) {
# print FH "  uvm_config_db \#(${agent_reg}_sequencer)::set(null, \"*\", \"${agent_reg}_sequencer\", m_${agent_reg}_regmodel_env.m_${agent_reg}_agent.m_sequencer);\n";
# }

        print FH "  //set register sub-block sequencers;\n";
        foreach my $agent_reg (@agent_reg_list) {
            print FH
"  m_${agent_reg}_env.${agent_reg}2reg_predictor.map = regmodel.${agent_reg}_map;\n";
            print FH
"  regmodel.$agent_sub_names{$agent_reg}_map.set_sequencer(m_${agent_reg}_env.m_${agent_reg}_agent.m_sequencer,",
              "m_${agent_reg}_env.reg2$agent_sub_names{$agent_reg});\n";
        }
    } if $regmodel;
    print FH "endfunction : connect_phase\n\n";
    print FH "\n";

    print FH "function void ${tbname}_env::end_of_elaboration_phase(uvm_phase phase);\n\n";
    print FH "  `uvm_info(get_type_name(), \"In end-of_elaboration_phase\", UVM_HIGH)\n";
    print FH "  super.end_of_elaboration_phase(phase);\n";
    print FH "  uvm_top.print_topology();\n";
    print FH "endfunction : end_of_elaboration_phase\n\n";

    print FH "function void ${tbname}_env::check_phase(uvm_phase phase);\n\n";
    print FH "  super.check_phase(phase);\n";
    print FH "  `uvm_info(get_type_name(), \"In check_phase\", UVM_HIGH)\n";
    print FH "endfunction : check_phase\n\n";

    print FH "`endif // " . uc($tbname) . "_ENV_SV\n\n";
    close(FH);
}

sub gen_top_common {
    $dir = $project . "/tb/" . $tbname . "_common";
    open( FH, ">" . $dir . "/sv/" . $tbname . "_common.svh" )
      || die("Exiting due to Error: can't open common : $tbname");

	write_file_header "${tbname}_common.svh", "Base types for $tbname";

    print FH "`ifndef " . uc($tbname) . "_COMMON_SV\n";
    print FH "`define " . uc($tbname) . "_COMMON_SV\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "//  parameters\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "//  typedefs\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "//  classes\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "//  methods\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "//  misc\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n\n";
    print FH "`endif // " . uc($tbname) . "_COMMON_SV\n\n";
    close(FH);

    open( FH, ">" . $dir . "/sv/" . $tbname . "_common_pkg.sv" )
      || die( "Exiting due to Error: can't open include file: "
          . $tbname
          . "_common_pkg.sv" );

	write_file_header "${tbname}_common_pkg.sv", "Overall package for $tbname";

    print FH "  import uvm_pkg::*;\n\n";
    print FH "  `include \"uvm_macros.svh\"\n\n";
    print FH "  package " . $tbname . "_common_pkg;\n\n";
    print FH "    `include \"" . $tbname . "_common.svh\"\n\n";
    print FH "  endpackage : " . $tbname . "_common_pkg\n\n";
    close(FH);

}

sub gen_top_config {
    $dir = $project . "/tb/" . $tbname;
    open( FH, ">" . $dir . "/sv/" . $tbname . "_config.sv" )
      || die("Exiting due to Error: can't open config: $tbname");

	write_file_header "${tbname}_config.sv", "Configuration for $tbname";

    print FH "`ifndef " . uc($tbname) . "_CONFIG_SV\n";
    print FH "`define " . uc($tbname) . "_CONFIG_SV\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "class " . $tbname . "_config extends uvm_object;\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n";
    print FH "  // Don't register with the factory!\n";
    print FH "\n";

    do {
        print FH "  // the register model\n";
        print FH "  $regmodel_name   regmodel;\n";
        print FH "\n";
    } if $regmodel_name;

    print FH "  //virtual interfaces\n";
    for ( my $i = 0 ; $i < @all_agent_ifs ; $i++ ) {
        print FH "  virtual ${all_agent_ifs[$i]}\t${agent_list[$i]}_vif;\n";
    }
    print FH "\n";

    print FH "  //interface agent is_active\n";
    for ( my $i = 0 ; $i < @all_agent_ifs ; $i++ ) {
        print FH "  uvm_active_passive_enum	is_active_${agent_list[$i]};\n";
    }
    print FH "\n";
    print FH "  //interface agent coverage_enable\n";
    for ( my $i = 0 ; $i < @all_agent_ifs ; $i++ ) {
        print FH "  bit coverage_enable_${agent_list[$i]};\n";
    }
    print FH "\n";
    print FH "  //interface agent checks_enable\n";
    for ( my $i = 0 ; $i < @all_agent_ifs ; $i++ ) {
        print FH "  bit checks_enable_${agent_list[$i]};\n";
    }
    print FH "\n";
    print FH
"  extern function new(string name = \"\");  //You may add more arguments to the constructor\n";
    print FH "\n";
    print FH "endclass : " . $tbname . "_config \n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "// " . $tbname . "_config implementation\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "function " . $tbname
      . "_config::new(string name = \"\");  //You may add more arguments to the constructor\n";
    print FH "  super.new(name);\n";
    print FH "endfunction : new\n\n";
    print FH "`endif // " . uc($tbname) . "_CONFIG_SV\n\n";
    close(FH);
}

sub gen_top_seq_lib {
    $dir = $project . "/tb/" . $tbname;
    open( FH, ">" . $dir . "/sv/" . $tbname . "_seq_lib.sv" )
      || die("Exiting due to Error: can't open seq_lib: $tbname");

	write_file_header "${tbname}_seq_lib.sv", "Sequence library for $tbname";

    print FH "`ifndef " . uc($tbname) . "_SEQ_LIB_SV\n";
    print FH "`define " . uc($tbname) . "_SEQ_LIB_SV\n\n";
    print FH
"//=============================================================================\n";
    print FH "// Sequence    : " . $tbname . "_base_seq\n";
    print FH "// Using       : <list of sub-sequences used by this sequence>\n";
    print FH
"// Description : Common base class for all top-level virtual sequences\n";
    print FH
"//=============================================================================\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "class " . $tbname
      . "_base_seq extends uvm_sequence #(uvm_sequence_item);\n";
    print FH
"//-----------------------------------------------------------------------------\n\n";
    print FH "  `uvm_object_utils(" . $tbname . "_base_seq)\n\n";
    print FH "  $regmodel_name  regmodel;\n\n" if $regmodel;

    foreach my $agent (@agent_list) {
        print FH "  ${agent}_env\tm_${agent}_env;\n"
          unless grep( /$agent/, @stand_alone_agents )
          or ( $agent eq "" );
    }
    foreach my $aname (@top_env_agents) {
        print FH "  ${aname}_agent\tm_${aname}_agent;\n";
    }
    print FH "\n";
    print FH "  //number of times to repeat child sequences\n";
    print FH "  int m_seq_count = 1;\n\n";

    print FH "  extern function new(string name = \"\");\n\n";
    print FH "  extern task body();\n";
    print FH
"  //---------------------------------------------------------------------------\n";
    print FH "  // constraints\n";
    print FH
"  //---------------------------------------------------------------------------\n\n";
    print FH "endclass : " . $tbname . "_base_seq\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "// " . $tbname . "_base_seq implementation\n";
    print FH
"//-----------------------------------------------------------------------------\n\n";
    print FH "function "
      . $tbname
      . "_base_seq::new(string name = \"\");\n";
    print FH "   super.new(name);\n";
    print FH "endfunction : new\n\n";
    print FH "task " . $tbname . "_base_seq::body();\n";

    print FH "endtask: body\n\n";
    print FH
"//=============================================================================\n";
    print FH "// Sequence    : " . $tbname . "_default_seq\n";
    print FH "// Using       : <list of sub-sequences used by this sequence>\n";
    print FH "// Description : Sequence generating 1 item;\n";
    print FH
"//=============================================================================\n";
    print FH "class "
      . $tbname
      . "_default_seq extends "
      . $tbname
      . "_base_seq;\n\n";
    print FH "\n";
    print FH "  `uvm_object_utils(" . $tbname . "_default_seq)\n\n";
    print FH "  // AGENT sequences\n";

    foreach my $env (@env_list) {
        $env =~ /(\w+)_env/;
        if ( exists $agent_sub_access{$1} ) {
            push @reg_env, $env;
            print FH "  ${env}_base_seq\tm_${env}_seq;\n" if ( $env ne "" );
        }
        else {    #env that does not access regmodel
            push @non_reg_env, $1;
            print FH "  ${1}_env_base_seq\tm_${1}_env_seq;\n" if ( $env ne "" );
        }
    }

    print FH "\n";
    do {
        print FH "  // Register builtin sequences\n";
        print FH "  uvm_reg_hw_reset_seq  rst_seq;\n";
        print FH "  uvm_reg_bit_bash_seq  reg_bash;\n";
        print FH "\n";
    } if $regmodel;
    print FH "  extern function new(string name = \"\");\n";
    print FH "  extern task body();\n\n";
    print FH "endclass : " . $tbname . "_default_seq\n";
    print FH "\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "// " . $tbname . "_default_seq implementation\n";
    print FH
"//-----------------------------------------------------------------------------\n\n";
    print FH "function "
      . $tbname
      . "_default_seq::new(string name = \"\");\n";
    print FH "  super.new(name);\n";
    print FH "endfunction : new\n\n";
    print FH "task " . $tbname . "_default_seq::body();\n";
    print FH "  super.body();\n";
    print FH "\n";

    foreach my $env (@reg_env) {
        print FH
"  m_${env}_seq = ${env}_base_seq::type_id::create(\"m_${env}_seq\");\n"
          if ( $env ne "" );
    }
    foreach my $env (@non_reg_env) {
        print FH
"  m_${env}_env_seq = ${env}_env_base_seq::type_id::create(\"m_${env}_env_seq\");\n"
          if ( $env ne "" );
    }
    print FH "\n";
    print FH "  repeat(m_seq_count)\n";
    print FH "    begin\n";

    my @vseq_list;
    if ($regmodel) {
        foreach my $env (@reg_env) {
            print FH "      m_${env}_seq.randomize();\n" if ( $env ne "" );
            if ( $env =~ /(\w+)_env/ ) {
                push @vseq_list, "m_${env}_seq";
                print FH "      m_${env}_seq.regmodel = regmodel.${1};\n";
            }
        }
    }
    foreach my $env (@non_reg_env) {
        push @vseq_list, "m_${env}_env_seq";
        print FH "      m_${env}_env_seq.randomize();\n";
        print FH "      m_${env}_env_seq.m_env = m_${env}_env;\n";
    }

    print FH "      fork\n";
    foreach my $vseq (@vseq_list) {
        print FH "        ${vseq}.start(null,this);\n";
    }
    foreach my $aname (@top_env_agents) {
        print FH "        if (m_${aname}_agent.m_cfg.is_active == UVM_ACTIVE)\n";
        print FH "          begin\n";
        print FH "            ${aname}_base_seq seq;\n";
        print FH "            seq = ${aname}_base_seq::type_id::create(\"seq\");\n";
        print FH "            seq.randomize();\n";
        print FH "            seq.start(m_${aname}_agent.m_sequencer,this);\n";
        print FH "          end\n";

    }
    print FH "      join\n";
    #print FH "      // fork\n";
    #print FH "        // alternatively use macros to start sequences\n";
    #foreach $i ( 0 .. @elist - 1) {
    #    if ( $elist[$i] ne "" ) {
    #        print FH "        // `uvm_do_on("
    #          . $elist[$i]
    #          . "_seq,  m_"
    #          . $elist[$i]
    #          . "_sequencer)\n";
    #    }
    #}
    #print FH "      // join\n";
    print FH
"      `uvm_info(get_type_name(),\"default sequence completed\",UVM_MEDIUM)\n";
    print FH "    end\n\n";
    print FH "endtask : body\n\n";
    print FH "//additional sequences can be included in this file\n\n";
    print FH "`endif // " . uc($tbname) . "_SEQ_LIB_SV\n\n";

    close(FH);
}

sub gen_top_if {
    $dir = $project . "/tb/" . $tbname . "_tb";
    open( FH, ">" . $dir . "/sv/" . $tbname . "_if.sv" )
      || die(
        "Exiting due to Error: can't open interface: " . $tbname . "_if" );

	write_file_header "${tbname}_if.sv", "Signal interfaces for $tbname";
    print FH

    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "interface " . $tbname . "_if (); \n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n";
    print FH "  import " . $tbname . "_common_pkg::*;\n\n";

    foreach my $intf (@agent_list) {
        if ( $intf ne "" ) {
            if ( $intf ne $regmname ) {
                print FH "  ${intf}_if    ${intf}_if0();\n";
            }
        }
    }
    print FH "\n";
    print FH "endinterface : " . $tbname . "_if\n\n";
    close(FH);
}

sub gen_top_test {
    $dir = $project . "/tb/" . $tbname . "_test";
    open( FH, ">" . $dir . "/sv/" . $tbname . "_test_pkg.sv" )
      || die( "can't open test: " . $tbname . "_test_pkg.sv" );

	write_file_header "${tbname}_test_pkg.sv", "Test package for $tbname";

    print FH "`ifndef " . uc($tbname) . "_TEST_PKG_SV\n";
    print FH "`define " . uc($tbname) . "_TEST_PKG_SV\n\n";
    print FH "package " . $tbname . "_test_pkg;\n";
    print FH "  // Imports\n";
    print FH "  import uvm_pkg::*;\n\n";
    print FH "  import regmodel_pkg::*;\n\n" if $regmodel;
    print FH "  // General includes\n";
    print FH "  `include \"uvm_macros.svh\"\n\n";

    foreach my $agent (@agent_list) {
        print FH "  import ${agent}_pkg::*;\n";
    }
    foreach my $agent_env (@env_list) {
        $agent_env =~ /(\w+)_env/;
        print FH "  import ${agent_env}_pkg::*;\n"
          if $regmodel and exists $agent_sub_access{$1};
    }
    print FH "  import " . $tbname . "_pkg::*;\n";
    print FH "\n";
    print FH "  `include \"" . $tbname . "_base_test.sv\"\n";
    print FH "  `include \"" . $tbname . "_test.sv\"\n";
    print FH "endpackage : " . $tbname . "_test_pkg\n\n";
    print FH "`endif // " . uc($tbname) . "_TEST_PKG_SV\n\n";
    close(FH);

    $dir = $project . "/tb/" . $tbname . "_test";
    open( FH, ">" . $dir . "/sv/" . $tbname . "_base_test.sv" )
      || die(
        "Exiting due to Error: can't open test: " . $tbname . "_base_test.sv" );

	write_file_header "${tbname}_base_test.sv", "Test base class for ${tbname} (included in package ${tbname}_test_pkg)\n";

    print FH "`ifndef " . uc($tbname) . "_BASE_TEST_SV\n";
    print FH "`define " . uc($tbname) . "_BASE_TEST_SV\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "class " . $tbname . "_base_test extends uvm_test;\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n";
    print FH "  `uvm_component_utils(" . $tbname . "_base_test)\n";
    print FH "\n";
    print FH "  " . $tbname . "_config m_cfg;\n\n";
    print FH "  " . $tbname . "_env    m_env;\n\n";
    print FH
"//---------------------------------------------------------------------------\n";
    print FH "// methods\n";
    print FH
"//---------------------------------------------------------------------------\n\n";
    print FH "  extern function new(string name, uvm_component parent);\n";
    print FH "  extern function void build_phase(uvm_phase phase);\n";
    print FH
      "  extern function void start_of_simulation_phase(uvm_phase phase);\n";
    print FH
"//---------------------------------------------------------------------------\n";
    print FH "// constraints\n";
    print FH
"//---------------------------------------------------------------------------\n\n";
    print FH "endclass : " . $tbname . "_base_test\n";
    print FH
"//---------------------------------------------------------------------------\n";
    print FH "// Implementation\n";
    print FH
"//---------------------------------------------------------------------------\n\n";
    print FH "function "
      . $tbname
      . "_base_test::new(string name , uvm_component parent);\n";
    print FH "  super.new(name, parent);\n";
    print FH "endfunction : new\n\n";
    print FH "function void " . $tbname
      . "_base_test::build_phase(uvm_phase phase);\n";
    print FH
"  // call super.build_phase(phase) only if you understand the consequences\n";
    print FH "  // super.build_phase(phase);\n";
    print FH "  // Create top config\n";
    print FH "  m_cfg = new(\"m_cfg\");\n";

    foreach ( my $i = 0 ; $i < @all_agent_ifs ; $i++ ) {
        if ( $agent_list[$i] ne "" ) {
            print FH "\n";
            print FH
"  if(!uvm_config_db #(virtual $all_agent_ifs[$i])::get(this, \"\", \"$all_agent_ifs[$i]\", m_cfg.$agent_list[$i]_vif) )\n";
            print FH
"    `uvm_error(get_type_name(), \"no virtual interface found\")\n";
            if ( exists $agent_is_active{ $agent_list[$i] } and $agent_is_active{ $agent_list[$i] } ne "" ) {
                print FH
"  m_cfg.is_active_$agent_list[$i] = $agent_is_active{$agent_list[$i]};\n";
            }
            else {
                print FH "  m_cfg.is_active_$agent_list[$i] = UVM_ACTIVE;\n";
            }
            if ( exists $agent_checks_enable{ $agent_list[$i] } and $agent_checks_enable{ $agent_list[$i] } eq "NO" ) {
                print FH "  m_cfg.checks_enable_$agent_list[$i] = 0;\n";
            }
            else {
                print FH "  m_cfg.checks_enable_$agent_list[$i] = 1;\n";
            }
            if ( exists $agent_coverage_enable{ $agent_list[$i] } and $agent_coverage_enable{ $agent_list[$i] } eq "NO" ) {
                print FH "  m_cfg.coverage_enable_$agent_list[$i] = 0;\n";
            }
            else {
                print FH "  m_cfg.coverage_enable_$agent_list[$i] = 1;\n";
            }
        }
    }
    print FH "\n";
    print FH
"  uvm_config_db #(${tbname}_config)::set(this, \"m_env\", \"${tbname}_config\", m_cfg);\n\n";
    print FH "  // Create env\n";
    print FH "  m_env = ${tbname}_env::type_id::create(\"m_env\", this);\n\n";
    print FH "\n";
    print FH "endfunction : build_phase\n\n";
    print FH "function void " . $tbname
      . "_base_test::start_of_simulation_phase(uvm_phase phase);\n";
    print FH "  super.start_of_simulation_phase(phase);\n";
    print FH
"  `uvm_info(get_type_name(), \$sformatf(\"Verbosity level is set to: %d\", get_report_verbosity_level()), UVM_MEDIUM)\n";
    print FH
"  `uvm_info(get_type_name(), \"Print all Factory overrides\", UVM_HIGH)\n";
    print FH "  factory.print();\n";
    print FH "endfunction : start_of_simulation_phase\n\n";
    print FH "`endif // " . uc($tbname) . "_BASE_TEST_SV\n\n";
    close(FH);

    # define specific tests
    $dir = $project . "/tb/" . $tbname . "_test";
    open( FH, ">" . $dir . "/sv/" . $tbname . "_test.sv" )
      || die(
        "Exiting due to Error: can't open test: " . $tbname . "_test.sv" );

	write_file_header "${tbname}_test.sv", "Test class for ${tbname} (included in package ${tbname}_test_pkg)\n";

    print FH "`ifndef " . uc($tbname) . "_TEST_SV\n";
    print FH "`define " . uc($tbname) . "_TEST_SV\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "class " . $tbname . "_test extends " . $tbname . "_base_test;\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n";
    print FH "  `uvm_component_utils(" . $tbname . "_test)\n";
    print FH
"//---------------------------------------------------------------------------\n";
    print FH "// methods\n";
    print FH
"//---------------------------------------------------------------------------\n\n";
    print FH "  extern function new(string name, uvm_component parent);\n";
    print FH "  extern function void build_phase(uvm_phase phase);\n";
    print FH "  extern task run_phase(uvm_phase phase);\n";
    print FH "  extern task wait_end_test();\n";
    print FH
"//---------------------------------------------------------------------------\n";
    print FH "// constraints\n";
    print FH
"//---------------------------------------------------------------------------\n\n";
    print FH "endclass : " . $tbname . "_test\n";
    print FH
"//---------------------------------------------------------------------------\n";
    print FH "\n";
    print FH
"//---------------------------------------------------------------------------\n";
    print FH "// Implementation\n";
    print FH
"//---------------------------------------------------------------------------\n\n";
    print FH "function "
      . $tbname
      . "_test::new(string name, uvm_component parent);\n";
    print FH "  super.new(name,parent);\n";
    print FH "endfunction : new\n";
    print FH "\n";
    print FH "function void " . $tbname
      . "_test::build_phase(uvm_phase phase);\n";
    do {
        print FH "  // Include reg coverage from the register model\n";
        print FH "  uvm_reg::include_coverage(\"*\", UVM_CVR_ALL);\n";
    } if $regmodel and $regmodel_name ne "";
    print FH "  // Include additional settings\n";
    print FH
"  //NEED to set factory overrides and configurations before calling \n  //super.build_phase() which creates the verification hierarchy.\n\n";
    print FH "  //default factory overrides\n";
    print FH
"  ${tbname}_base_seq::type_id::set_type_override(${tbname}_default_seq::get_type());\n";
    foreach my $env (@env_list) {
        $env =~ /(\w+)_env/;
        if ( $regmodel and exists $agent_sub_access{$1} ) {
            print FH
"  ${env}_base_seq::type_id::set_type_override(${env}_default_seq::get_type());\n"
              if $env ne "";
        }
        else {
            print FH
"  ${1}_base_seq::type_id::set_type_override(${1}_default_seq::get_type());\n"
              if $env ne "";
            print FH
"  ${1}_env_base_seq::type_id::set_type_override(${1}_env_default_seq::get_type());\n"
              if $env ne "";
        }
    }
    foreach my $aname (@stand_alone_agents) {
        print FH
"  ${aname}_base_seq::type_id::set_type_override(${aname}_default_seq::get_type());\n";
    }

    print FH "\n  //user-defined factory overrides\n";
    foreach my $factory_override ( keys %agent_factory_set ) {
        print FH
"  ${factory_override}::type_id::set_type_override($agent_factory_set{$factory_override}::get_type());\n"
          if $factory_override ne "";
    }

    print FH "\n  //add configuration database items here...\n\n";

    print FH "  super.build_phase(phase);\n";
    print FH "endfunction : build_phase\n\n";

    print FH "task " . $tbname . "_test::run_phase(uvm_phase phase);\n";
    print FH "  ${tbname}_base_seq vseq;\n";
    print FH "  vseq = ${tbname}_base_seq::type_id::create(\"vseq\");\n";
    foreach my $agent (@agent_list) {
        print FH "  vseq.m_${agent}_env = m_env.m_${agent}_env;\n"
          unless grep( /$agent/, @stand_alone_agents )
          or ( $agent eq "" );
    }
    foreach my $aname (@top_env_agents) {
        print FH "  vseq.m_${aname}_agent = m_env.m_${aname}_agent;\n";
    }

    print FH "  vseq.regmodel = m_env.regmodel;\n" if $regmodel_name ne "";
    print FH "  phase.raise_objection(this, \"Starting virtual sequence\");\n";
    print FH "  `uvm_info(get_type_name(), \"Objection raised\", UVM_MEDIUM)\n";
    print FH
"  //uncomment and modify the following line to set number of times child sequences repeat\n";
    print FH "  //vseq.m_seq_count = 1;\n";
    print FH "  vseq.start(null);\n";
    print FH "  wait_end_test();  //wait until test has completed\n";
    print FH "  phase.drop_objection(this, \"Finished virtual sequence\");\n";
    print FH
      "  `uvm_info(get_type_name(), \"Objection dropped\", UVM_MEDIUM)\n";
    print FH "endtask : run_phase\n\n";

    if ( -e "${project}/tb/include/top_test_inc.sv" ) {
        print FH "`include \"top_test_inc.sv\"\n\n";
    }
    else {
        print FH "task ${tbname}_test::wait_end_test();\n";
        print FH
          "  //replace line below with code to wait until the end of test\n";
        print FH "  #100ns; //wait for a time or event\n";
        print FH "endtask : wait_end_test\n";
    }
    print FH "\n";

    print FH "`endif // " . uc($tbname) . "_TEST_SV\n\n";
    close(FH);

}

sub gen_top() {
    ### generate top modules
    $dir = $project . "/tb/" . $tbname;
	
	### Test Harness
    open( FH, ">" . $dir . "_tb/sv/" . $tbname . "_th.sv" )
      || die( "Exiting due to Error: can't open include file: "
          . $tbname
          . "_th.sv" );
	write_file_header "${tbname}_th.sv", "Test Harness";

    print FH "module " . $tbname . "_th;\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n";
    print FH "  timeunit $timeunit;\n";
    print FH "  timeprecision $timeprecision;\n\n";
    print FH "  logic clock = 0;\n";
    print FH "  logic reset;\n\n";

    print FH "  //instantiate AGENT interfaces\n";
    print FH "\n";

    foreach my $intf (@agent_list) {
        if ( $intf ne "" ) {
            print FH "  ${intf}_if    ${intf}_if0();\n" unless ($regmname and $intf eq $regmname);
        }
    }
    print FH "\n";
    for ( $i = 0 ; $i < @rlist ; $i = $i + 2 ) {
        if ( $rlist[$i] ne "" ) {
            print FH "  assign "
              . $rlist[$i] . "_if0."
              . $rlist[ $i + 1 ]
              . " = reset;\n";
        }
    }
    print FH "\n";
    for ( $i = 0 ; $i < @clist ; $i = $i + 2 ) {
        if ( $clist[$i] ne "" ) {
            print FH "  assign "
              . $clist[$i] . "_if0."
              . $clist[ $i + 1 ]
              . " = clock;\n";
        }
    }
    print FH "\n";
    print FH "  //instantiate and connect dut to interface(s) here\n";
    gen_dut_inst();
	
    print FH "\n";	
    print FH "  //example clock generator process\n";
    print FH "  always #10 clock = ~clock;\n";
    print FH "\n";
	
    print FH "  //example reset generator process\n";
    print FH "  initial\n";
    print FH "    begin\n";
    print FH "      reset=0;         //active low reset for this example\n";
    print FH "      #75 reset=1;\n";
    print FH "    end\n";
    print FH "\n";
	
    print FH "endmodule\n\n";
    close(FH);

	###Testbench
		  
    open( FH, ">" . $dir . "_tb/sv/" . $tbname . "_tb.sv" )
      || die( "Exiting due to Error: can't open include file: "
          . $tbname
          . "_tb.sv" );

	write_file_header("_th","Testbench");
    print FH "module " . $tbname . "_tb;\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n";
    print FH "  timeunit $timeunit;\n";
    print FH "  timeprecision $timeprecision;\n\n";
    print FH "  import uvm_pkg::*;\n";
    print FH "  `include \"uvm_macros.svh\"\n";
    print FH "\n";
    print FH "  import " . $tbname . "_test_pkg::*;\n";
    print FH "\n";
    print FH "  // import additional packages if needed\n\n";
    print FH "  //test harness\n";
    print FH "  ${tbname}_th th();\n\n";
	
    print FH "  initial\n";
    print FH "    begin\n";
    #print FH "      uvm_config_db #(int)::set(null, \"*\", \"recording_detail\", 1);\n";
    foreach ( my $i = 0 ; $i < @all_agent_ifs ; $i++ ) {
        if ( $all_agent_ifs[$i] ne "" ) {
            print FH
"      uvm_config_db #(virtual $all_agent_ifs[$i])::set(null, \"uvm_test_top\", \"$all_agent_ifs[$i]\", th.$all_agent_ifs[$i]0);\n";
        }
    }
    print FH "\n";
    print FH "      run_test();\n";
    print FH "    end\n";
    print FH "\n";
    print FH "endmodule\n\n";
    close(FH);
}


sub gen_regmodel_config {
    $dir = $project . "/tb/" . $regmname;
    open( FH, ">" . $dir . "/sv/" . $regmname . "_config.sv" )
      || die("Exiting due to Error: can't open config: $regmname");

	write_file_header "${regmname}_config.sv", "Configuration for $regmname\n";

    print FH "`ifndef " . uc($regmname) . "_CONFIG_SV\n";
    print FH "`define " . uc($regmname) . "_CONFIG_SV\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "class " . $regmname . "_config extends uvm_object;\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n";
    print FH "  // Don't register with the factory\n";
    print FH "\n";
    print FH "  // Virtual interface\n";
    print FH "  virtual ${agent_access_name}_if vif;\n";
    print FH "  $reg_sub_blocks{$agent_access_name}\tregmodel;\n\n";
    print FH "  uvm_active_passive_enum is_active;\n";
    print FH "  bit coverage_enable;\n";
    print FH "  bit checks_enable;\n";
    print FH "\n";
    print FH
"  extern function new(string name = \"\");  //You may add more arguments to the constructor\n";
    print FH "\n";
    print FH "endclass : " . $regmname . "_config \n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "// " . $regmname . "_config implementation\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "function "
      . $regmname
      . "_config::new(string name = \"\");  //You may add more arguments to the constructor\n";
    print FH "  super.new(name);\n";
    print FH "endfunction : new\n\n";
    print FH "`endif // " . uc($regmname) . "_CONFIG_SV\n\n";
    close(FH);
}

sub gen_regmodel_env {
    $dir = $project . "/tb/" . $regmname;
    open( FH, ">" . $dir . "/sv/" . $regmname . ".sv" )
      || die("Exiting due to Error: can't open env: $regmname");

	write_file_header "${regmname}.sv", "Environment for $regmname\n";

    print FH "`ifndef " . uc($regmname) . "_SV\n";
    print FH "`define " . uc($regmname) . "_SV\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "class " . $regmname . " extends uvm_env;\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n";
    print FH "  `uvm_component_utils(" . $regmname . ")\n\n";
    print FH "\n";
    print FH "  " . $regmname . "_config m_cfg;\n";
    print FH "  ${agent_access_name}_config  m_${agent_access_name}_cfg;\n";
    print FH "  "
      . $agent_access_name
      . "_agent  m_${agent_access_name}_agent;\n";
    print FH "  ${regmname}_coverage m_${regmname}_coverage;\n";
    print FH "  ${agent_access_name}_coverage m_${agent_access_name}_coverage;\n";
    print FH "  $reg_sub_blocks{$agent_access_name}\tregmodel;\n\n";
    print FH "  // Register layering adapter\n";
    print FH "  reg2"
      . $agent_access_name
      . "_adapter reg2"
      . $agent_access_name . ";\n";
    print FH "  // Register predictor\n";
    print FH "  uvm_reg_predictor #($agent_sub_items{$agent_access_name}) "
      . $agent_access_name
      . "2reg_predictor;\n\n";
    print FH "\n";
    print FH "  extern function new(string name, uvm_component parent);\n";
    print FH "  extern function void build_phase(uvm_phase phase);\n\n";
    print FH "  extern function void connect_phase(uvm_phase phase);\n\n";
    print FH
      "  extern function void end_of_elaboration_phase(uvm_phase phase);\n\n";
    print FH "  extern function void report_phase(uvm_phase phase);\n\n";
    print FH "endclass : " . $regmname . " \n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "// " . $regmname . " implementation\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "function "
      . $regmname
      . "::new(string name, uvm_component parent);\n";
    print FH "  super.new(name,parent);\n";
    print FH "endfunction : new\n";
    print FH "\n";
    print FH "function void " . $regmname . "::build_phase(uvm_phase phase);\n";
    print FH
"  // call super.build_phase(phase) only if you understand the consequences\n";
    print FH "  // super.build_phase(phase);\n";
    print FH
"  if(!uvm_config_db #(${regmname}_config)::get(this, \"\", \"${regmname}_config\", m_cfg))\n"
      ;    #
    print FH
"    `uvm_error(get_type_name(), \"unable to get config from configuration database\")\n";
    print FH "  regmodel = m_cfg.regmodel;\n\n";
    print FH "  // Test for top-level environment\n";
    print FH "  if (regmodel == null) \n";
    print FH
      "  begin  //is top-level so need to create register model here...\n";
    print FH
"    regmodel = $reg_sub_blocks{$agent_access_name}::type_id::create(\"regmodel\");\n";
    print FH "    regmodel.build();\n";
    print FH "  end\n";

    print FH
      "  m_${agent_access_name}_cfg = new(\"m_${agent_access_name}_cfg\");\n";
    print FH "  m_${agent_access_name}_cfg.vif = m_cfg.vif;\n";
    print FH "  m_${agent_access_name}_cfg.is_active = m_cfg.is_active;\n";
    print FH "  m_${agent_access_name}_cfg.checks_enable = m_cfg.checks_enable;\n";
    print FH "  m_${agent_access_name}_cfg.coverage_enable = m_cfg.coverage_enable;\n";
    print FH
"  uvm_config_db #(${agent_access_name}_config)::set(this,\"m_${agent_access_name}_agent\",\"${agent_access_name}_config\",m_${agent_access_name}_cfg);\n";
    print FH "  m_${agent_access_name}_agent = "
      . $agent_access_name
      . "_agent::type_id::create(\"m_${agent_access_name}_agent\", this);\n";
    print FH "  m_${regmname}_coverage = ${regmname}_coverage::type_id::create(\"m_${regmname}_coverage\", this);\n";
	print FH "  if(m_cfg.coverage_enable)\n";
    print FH "    m_${agent_access_name}_coverage = ${agent_access_name}_coverage::type_id::create(\"m_${agent_access_name}_coverage\", this);\n";
    print FH "  reg2"
      . $agent_access_name
      . " = reg2"
      . $agent_access_name
      . "_adapter::type_id::create(\"reg2"
      . $agent_access_name
      . "\", this);\n";
    print FH "  "
      . $agent_access_name
      . "2reg_predictor = uvm_reg_predictor #($agent_sub_items{$agent_access_name})::type_id::create(\""
      . $agent_access_name
      . "2reg_predictor\", this);\n";
    print FH "endfunction : build_phase\n";
    print FH "\n";
    print FH "function void "
      . $regmname
      . "::connect_phase(uvm_phase phase);\n";
    print FH
"  // call super.connect_phase(phase) only if you understand the consequences\n";
    print FH "  // super.connect_phase(phase);\n";
    print FH "  if (regmodel.get_parent() == null)\n";
    print FH
"    regmodel.default_map.set_sequencer(m_${agent_access_name}_agent.m_sequencer, reg2${agent_access_name});\n\n";
    print FH
"  ${agent_access_name}2reg_predictor.map = regmodel.${agent_access_name}_map;\n";
    print FH
"  ${agent_access_name}2reg_predictor.adapter = reg2${agent_access_name};\n";
    print FH "  regmodel.${agent_access_name}_map.set_auto_predict(0);\n";
    print FH "  m_${agent_access_name}_agent.m_monitor.ap.connect(${agent_access_name}2reg_predictor.bus_in);\n";
    print FH "  m_${agent_access_name}_agent.m_monitor.ap.connect(m_${regmname}_coverage.analysis_export);\n";
    print FH "  m_${regmname}_coverage.regmodel = regmodel;\n";
	print FH "  if(m_cfg.coverage_enable)\n";
    print FH "    m_${agent_access_name}_agent.m_monitor.ap.connect(m_${agent_access_name}_coverage.analysis_export);\n";
    print FH "endfunction : connect_phase\n";
    print FH "\n";
    print FH "function void "
      . $regmname
      . "::end_of_elaboration_phase(uvm_phase phase);\n";
    print FH "  uvm_reg  regs[\$];\n";
    print FH "  string name;\n";
    print FH "  regmodel.${agent_access_name}_map.get_registers(regs);\n";
    print FH
"  `uvm_info(get_type_name(), \$sformatf(\"found %d registers\", regs.size()), UVM_MEDIUM)\n";
    print FH "  for (int j = 0; j < regs.size(); j++) \n";
    print FH
"    `uvm_info(get_type_name(), \$sformatf(\"reg[%0d]: %s\", j, regs[j].get_name()), UVM_HIGH)\n";
    print FH "endfunction : end_of_elaboration_phase\n";
    print FH "\n";
    print FH "function void "
      . $regmname
      . "::report_phase(uvm_phase phase);\n";
    print FH "  `uvm_info(get_type_name(), \"In report phase\", UVM_LOW)\n";
    print FH "endfunction : report_phase\n";
    print FH "\n";
    print FH "`endif // " . uc($regmname) . "_SV\n\n";
    close(FH);
}

sub gen_regmodel_adapter {
    $dir = $project . "/tb/" . $regmname;
    open( FH, ">" . $dir . "/sv/reg2" . $agent_access_name . "_adapter.sv" )
      || die( "Exiting due to Error: can't open adapter: reg2"
          . $agent_access_name
          . "_adapter.sv" );

	write_file_header "${agent_access_name}_adapter.sv", "Environment for reg2 ${agent_access_name}_adapter.sv\n";

    print FH "`ifndef REG2" . uc($agent_access_name) . "_ADAPTER_SV\n";
    print FH "`define REG2" . uc($agent_access_name) . "_ADAPTER_SV\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "class reg2"
      . $agent_access_name
      . "_adapter extends uvm_reg_adapter;\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n";
    print FH "  `uvm_object_utils(reg2" . $agent_access_name . "_adapter)\n\n";
    print FH "  extern function new(string name = \"reg2"
      . $agent_access_name
      . "_adapter\");\n\n";
    print FH
"  extern function uvm_sequence_item reg2bus(const ref uvm_reg_bus_op rw);\n";
    print FH
"  extern function void bus2reg(uvm_sequence_item bus_item, ref uvm_reg_bus_op rw);\n\n";
    print FH "endclass : reg2" . $agent_access_name . "_adapter \n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "// reg2" . $agent_access_name . "_adapter implementation\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "function reg2"
      . $agent_access_name
      . "_adapter::new(string name = \"reg2"
      . $agent_access_name
      . "_adapter\");\n";
    print FH "   super.new(name);\n";
    print FH "endfunction : new\n";
    print FH "\n";
    print FH "function uvm_sequence_item reg2"
      . $agent_access_name
      . "_adapter::reg2bus(const ref uvm_reg_bus_op rw);\n";
    print FH
"  $agent_sub_items{$agent_access_name} ${agent_access_name} = $agent_sub_items{$agent_access_name}::type_id::create(\"${agent_access_name}\");\n";

    if ( $agent_access_mode =~ /WR|WO/i ) {
        print FH "  "
          . $agent_access_name . "."
          . $bus2reg_map{$agent_access_name}->{'kind'}
          . " = (rw.kind == UVM_READ) ? 0 : 1;\n";
        print FH "  "
          . $agent_access_name . "."
          . $bus2reg_map{$agent_access_name}->{'addr'}
          . "  = rw.addr;\n";
        print FH "  "
          . $agent_access_name . "."
          . $bus2reg_map{$agent_access_name}->{'data'}
          . " = rw.data;\n";
        print FH
"  `uvm_info(get_type_name(), \$sformatf(\"reg2bus rw::kind: %s, addr: %d, data: %h, status: %s\", rw.kind, rw.addr, rw.data, rw.status), UVM_HIGH)\n";
    }
    elsif ( $agent_access_mode =~ /RO/i ) {
        print FH "  "
          . $agent_access_name . "."
          . $bus2reg_map{$agent_access_name}->{'kind'}
          . " = (rw.kind == UVM_READ) ? 0 : 1;\n";
        print FH "  "
          . $agent_access_name . "."
          . $bus2reg_map{$agent_access_name}->{'addr'}
          . "  = rw.addr;\n";
        print FH "  "
          . $agent_access_name . "."
          . $bus2reg_map{$agent_access_name}->{'data'}
          . " = rw.data;\n";
        print FH
"  `uvm_info(get_type_name(), \$sformatf(\"reg2bus rw::kind: %s, addr: %d, data: %h, status: %s\", rw.kind, rw.addr, rw.data, rw.status), UVM_HIGH)\n";
        print FH
"  if (rw.kind != UVM_READ) `uvm_warning(get_type_name(), \"Interface is READ-ONLY\")\n";
    }
    else {
        print FH
          "  `uvm_warning(get_type_name(), \"Interface mode not specified\")\n";
    }
    print FH "  return " . $agent_access_name . ";\n";
    print FH "endfunction : reg2bus\n";
    print FH "\n";
    print FH "function void reg2"
      . $agent_access_name
      . "_adapter::bus2reg(uvm_sequence_item bus_item, ref uvm_reg_bus_op rw);\n";
    print FH "  $agent_sub_items{$agent_access_name} ${agent_access_name};\n";
    print FH "  if (!\$cast(${agent_access_name}, bus_item))\n";
    print FH
"    `uvm_fatal(get_type_name(),\"Provided bus_item is not of the correct type\")\n";

    if ( $agent_access_mode =~ /WR|WO/i ) {
        print FH "  rw.kind = "
          . $agent_access_name . "."
          . $bus2reg_map{$agent_access_name}->{'kind'}
          . " ? UVM_WRITE : UVM_READ;\n";
    }
    else {
        print FH "  rw.kind = UVM_READ;\n";
    }
    print FH "  rw.addr = "
      . $agent_access_name . "."
      . $bus2reg_map{$agent_access_name}->{'addr'} . ";\n";
    print FH "  rw.data = "
      . $agent_access_name . "."
      . $bus2reg_map{$agent_access_name}->{'data'} . ";\n";
    print FH "  rw.status = UVM_IS_OK;\n";
    print FH
"  `uvm_info(get_type_name(), \$sformatf(\"bus2reg rw::kind: %s, addr: %d, data: %h, status: %s\", rw.kind, rw.addr, rw.data, rw.status), UVM_HIGH)\n";
    print FH "endfunction : bus2reg\n";
    print FH "\n";
    print FH "`endif // REG2" . uc($agent_access_name) . "_ADAPTER_SV\n\n";
    close(FH);
}

sub gen_regmodel_coverage {
    $dir = $project . "/tb/" . $regmname;
    open( FH, ">" . $dir . "/sv/" . $regmname . "_coverage.sv" )
      || die( "Exiting due to Error: can't open config: "
          . $regmname
          . "_coverage.sv" );

	write_file_header "${regmname}_coverage.sv", "Coverage for $regmname\n";

    print FH "`ifndef " . uc($regmname) . "_COVERAGE_SV\n";
    print FH "`define " . uc($regmname) . "_COVERAGE_SV\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "class "
      . $regmname
      . "_coverage extends uvm_subscriber #($agent_sub_items{$agent_access_name});\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "\n";
    print FH "  `uvm_component_utils(" . $regmname . "_coverage)\n";
    print FH "  bit is_covered;\n\n";
    print FH "  $agent_sub_items{$agent_access_name} item;\n\n";

    print FH "\n";
    print FH "  $reg_sub_blocks{$agent_access_name}\tregmodel;\n";
    print FH "\n";
    print FH "  covergroup reg_rw_cov;\n";
    print FH "  option.per_instance = 1;\n";

    #if include file for coverpoints exists, pull it in here, otherwise
    #create coverpoints with default bins
    if ( exists $reg_cover_inc{$agent_name}
        && -e "${project}/tb/include/$reg_cover_inc{$agent_name}" )
    {
        print FH "  // inserting coverpoints from source file\n";
        print FH "  `include \"$reg_cover_inc{$agent_name}\"\n\n";
    }
    else {
        print FH "    // insert your coverpoints here\n";
        print FH "\n";
    }

    print FH "  endgroup: reg_rw_cov\n";
    print FH "\n";
    print FH "  extern function new(string name, uvm_component parent);\n";
    print FH "  extern function void write($agent_sub_items{$agent_access_name} t);\n";
    print FH "  extern function void report_phase(uvm_phase phase);\n";
    print FH "\n";
    print FH "endclass : " . $regmname . "_coverage \n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "// " . $regmname . "_coverage implementation\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "function "
      . $regmname
      . "_coverage::new(string name, uvm_component parent);\n";
    print FH "  super.new(name, parent);\n";
    print FH "  reg_rw_cov = new();\n";
    print FH "endfunction : new\n\n";

    print FH "function void "
      . $regmname
      . "_coverage::write($agent_sub_items{$agent_access_name} t);\n";
    print FH "  // assign seq item properties to internal signals\n";
    print FH "  item = t;\n";
    print FH "  reg_rw_cov.sample();\n";
    print FH
"  //check coverage - could use reg_rw_cov.option.goal instead of 100 if your simulator supports it\n";
    print FH "  if (reg_rw_cov.get_inst_coverage() >= 100) is_covered = 1;\n";
    print FH "endfunction : write\n\n";
    print FH "function void "
      . $regmname
      . "_coverage::report_phase(uvm_phase phase);\n";
    print FH
"  `uvm_info(get_type_name(), \$sformatf(\"Coverage score = %3.1f%%\",reg_rw_cov.get_inst_coverage()), UVM_LOW)\n";
    print FH "endfunction : report_phase\n\n";
    print FH "`endif // " . uc($regmname) . "_COVERAGE_SV\n\n";
    close(FH);
}

sub gen_regmodel_seq_lib {
    $dir = $project . "/tb/" . $regmname;
    open( FH, ">" . $dir . "/sv/" . $regmname . "_seq_lib.sv" )
      || die( "Exiting due to Error: can't open seq_lib: "
          . $regmname
          . "_seq_lib.sv" );

	write_file_header "${regmname}_seq_lib.sv", "Sequence library for $regmname\n";

    print FH "`ifndef " . uc($regmname) . "_SEQ_LIB_SV\n";
    print FH "`define " . uc($regmname) . "_SEQ_LIB_SV\n\n";
    print FH
"//=============================================================================\n";
    print FH "// Sequence    : " . $regmname . "_base_seq\n";
    print FH
      "// Using       : <list of sub-sequences used by this sequences>\n";
    print FH "// Description : Common base sequence for all sequences\n";
    print FH
"//=============================================================================\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "class "
      . $regmname
      . "_base_seq extends uvm_sequence #($agent_sub_items{$agent_access_name});\n";
    print FH
"//-----------------------------------------------------------------------------\n\n";
    print FH "  `uvm_object_utils(" . $regmname . "_base_seq)\n\n";
    print FH "\n";
    print FH "  $reg_sub_blocks{$agent_access_name}\tregmodel;\n";
    print FH "\n";
    print FH "  rand  uvm_reg_data_t data;         // For passing data\n";
    print FH
      "  uvm_status_e         status;       // Returning access status \n";
    print FH "\n";
    print FH
"  //---------------------------------------------------------------------------\n";
    print FH "  // methods\n";
    print FH
"  //---------------------------------------------------------------------------\n\n";
    print FH "  extern function new(string name = \"\");\n";
    print FH "  extern task body();\n";
    print FH
"  //---------------------------------------------------------------------------\n";
    print FH "  // constraints\n";
    print FH
"  //---------------------------------------------------------------------------\n\n";
    print FH "endclass : " . $regmname . "_base_seq\n\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "// " . $regmname . "_base_seq implementation\n";
    print FH
"//-----------------------------------------------------------------------------\n\n";
    print FH "function "
      . $regmname
      . "_base_seq::new(string name = \"\");\n";
    print FH "  super.new(name);\n";
    print FH "endfunction : new\n\n";
    print FH "task " . $regmname . "_base_seq::body();\n";
    print FH "endtask: body\n\n";
    print FH
"//=============================================================================\n";
    print FH "// Sequence    : " . $regmname . "_default_seq\n";
    print FH
      "// Using       : <list of sub-sequences used by this sequences>\n";
    print FH "// Description : Sequence generating 1 item;\n";
    print FH
"//=============================================================================\n";
    print FH "class "
      . $regmname
      . "_default_seq extends "
      . $regmname
      . "_base_seq;\n\n";
    print FH "\n";
    print FH "  `uvm_object_utils(" . $regmname . "_default_seq)\n\n";
    print FH "  uvm_reg data_regs[\$]; // Queue of registers\n\n";
    print FH "  extern function new(string name = \"\");\n";
    print FH "  extern task body();\n\n";
    print FH "endclass : " . $regmname . "_default_seq\n";
    print FH "\n";
    print FH
"//-----------------------------------------------------------------------------\n";
    print FH "// " . $regmname . "_default_seq implementation\n";
    print FH
"//-----------------------------------------------------------------------------\n\n";
    print FH "function "
      . $regmname
      . "_default_seq::new(string name = \"\");\n";
    print FH "  super.new(name);\n";
    print FH "endfunction : new\n\n";
    print FH "task " . $regmname . "_default_seq::body();\n";
    print FH "  super.body();\n";
    print FH "\n";
    print FH
"  `uvm_info(get_type_name(),\"default sequence starting\", UVM_MEDIUM)\n\n";
    print FH "  regmodel.get_registers(data_regs);\n";
    print FH "  data_regs.shuffle();\n";
    print FH "  foreach(data_regs[i])\n";
    print FH "    begin\n";
    print FH "      // Randomize register content and then update\n";
    print FH "      if(!data_regs[i].randomize())\n";
    print FH
"        `uvm_error(get_type_name(), \$sformatf(\"Randomization error for data_regs[%0d]\", i))\n";
    print FH
      "      data_regs[i].update(status, .path(UVM_FRONTDOOR), .parent(this));\n";
    print FH "    end \n";
    print FH
"  `uvm_info(get_type_name(),\"default sequence completed\",UVM_MEDIUM)\n";
    print FH "endtask : body\n\n";

    #include sequence file (if specified)
    print FH "`include \"$agent_reg_seq_inc{$regmname}\"\n\n"
      if exists $agent_reg_seq_inc{$regmname} and $agent_reg_seq_inc{$regmname} ne "";
    print FH "//additional sequences can be included in this file\n\n";
    print FH "`endif // " . uc($regmname) . "_SEQ_LIB_SV\n\n";

    close(FH);
}

sub gen_regmodel_inc {

    ### file list for files in sv directoru (.svh file)
    $dir = $project . "/tb/" . $regmname;
    open( FH, ">" . $dir . "/sv/" . $regmname . ".svh" )
      || die( "Exiting due to Error: can't open include file: "
          . $regmname
          . ".svh" );

	write_file_header "${regmname}.svh", "Include file for $regmname\n";

    print FH "`ifndef " . uc($regmname) . "_SVH\n";
    print FH "`define " . uc($regmname) . "_SVH\n\n";
    print FH "  // Imports\n";
    print FH "  import uvm_pkg::*;\n";
    print FH "  import regmodel_pkg::*;\n";
    print FH "  import " . $tbname . "_common_pkg::*;\n\n";
    print FH "  import " . $agent_access_name . "_pkg::*;\n\n";
    print FH "  // General includes\n";
    print FH "  `include \"uvm_macros.svh\"\n\n";
    print FH "  // AGENT includes\n";
    print FH "  `include \"reg2" . $agent_access_name . "_adapter.sv\"\n";
    print FH "  `include \"" . $regmname . "_common.sv\"\n";
    print FH "  `include \"" . $regmname . "_config.sv\"\n";
    print FH "  `include \"" . $regmname . "_coverage.sv\"\n";
    print FH "  `include \"" . $agent_access_name . "_env.sv\"\n";
    print FH "  `include \"" . $regmname . "_seq_lib.sv\"\n";
    print FH "\n";
    print FH "`endif // " . uc($regmname) . "_SV\n\n";
    close(FH);
}

sub gen_regmodel_pkg {

    ### file list for files in sv directoru (.svh file)
    $dir = $project . "/tb/" . $regmname;
    open( FH, ">" . $dir . "/sv/" . $regmname . "_pkg.sv" )
      || die("Exiting due to Error: can't open include file: $tbname");

	write_file_header "${regmname}_pkg.sv", "Package for $regmname\n";

    print FH "  package " . $regmname . "_pkg;\n\n";
    print FH "    `include \"" . $regmname . ".svh\"\n\n";
    print FH "  endpackage : " . $regmname . "_pkg\n\n";
    close(FH);
}

sub gen_questa_script {
    $dir = $project . "/sim";
    open( FH, ">" . $dir . "/compile_questa.do" )
      || die("Exiting due to Error: can't open file: compile_questa.do");
    print FH "\n";
    print FH "#rm -rf work\n\n";
    print FH "file delete -force work\n\n";
    print FH "vlib work\n\n";
    print FH "#compile the dut code\n";
    print FH "set cmd \"vlog -F ../${dut_tb_dir}/files.f\"\n";
    print FH "eval \$cmd\n\n";

    do {
        print FH "#compile the register model package\n";
        print FH "set cmd \"vlog -sv  ../tb/regmodel/regmodel.sv\"\n";
        print FH "eval \$cmd\n\n";
    } if $regmodel;

    print FH "    set tb_name $tbname\n";
    $incdir = "+incdir+../tb/include ";
    foreach $i ( 0 .. @inc_path_list - 1 ) {
        if ( $inc_path_list[$i] ne "" ) {
            $incdir .= "+incdir+" . $inc_path_list[$i] . " ";
        }
    }

    printf LOGFILE "incdir: $incdir\n";
    print FH "    set cmd  \"vlog -sv " . $incdir . "+incdir+../tb/\"\n";
    print FH
"    append cmd \$tb_name \"_common/sv ../tb/\" \$tb_name \"_common/sv/\" \$tb_name \"_common_pkg.sv\"\n";
    print FH "    eval \$cmd\n\n";

    print FH "set agent_list {\\ \n";
    print LOGFILE "env_list=@env_list, agent_list=@agent_list,\n";
    foreach my $aname (@stand_alone_agents) {
        if ( $aname ne "" ) {
            print FH "\t$aname \\\n";
        }
    }
    foreach my $agent (@agent_list) {
        if ( ( $agent ne "" ) and !grep( /$agent/, @stand_alone_agents ) ) {
            print FH "\t$agent \\\n";
        }
    }
    do {
        foreach my $agent (@env_list) {
            $agent =~ /(\w+)_env/;
            if ( $agent ne "" ) {
                print FH "\t$agent \\\n" if exists $agent_sub_access{$1};
            }
        }
    } if $regmodel;
    print FH "\t}\n";
    print FH "foreach  ele \$agent_list {\n";
    print FH "  if {\$ele != \" \"} {\n";
    print FH "    set cmd  \"vlog -sv " . $incdir . "+incdir+../tb/\"\n";
    print FH
      "    append cmd \$ele \"/sv ../tb/\" \$ele \"/sv/\" \$ele \"_pkg.sv\"\n";
    print FH "    eval \$cmd\n";
    print FH "                   }\n";
    print FH "}\n\n";

    print FH "    set cmd  \"vlog -sv " . $incdir . "+incdir+../tb/\"\n";
    print FH
"    append cmd \$tb_name \"/sv ../tb/\" \$tb_name \"/sv/\" \$tb_name \"_pkg.sv\"\n";
    print FH "    eval \$cmd\n\n";

    print FH "    set cmd  \"vlog -sv " . $incdir . "+incdir+../tb/\"\n";
    print FH
"    append cmd \$tb_name \"_test/sv ../tb/\" \$tb_name \"_test/sv/\" \$tb_name \"_test_pkg.sv\"\n";
    print FH "    eval \$cmd\n\n";

    print FH "    set cmd  \"vlog -sv -timescale $timeunit/$timeprecision "
      . $incdir
      . "+incdir+../tb/\"\n";
    print FH
"    append cmd \$tb_name \"_tb/sv ../tb/\" \$tb_name \"_tb/sv/\" \$tb_name \"_th.sv\"\n";
    print FH "    eval \$cmd\n\n";

    print FH "    set cmd  \"vlog -sv -timescale $timeunit/$timeprecision "
      . $incdir
      . "+incdir+../tb/\"\n";
    print FH
"    append cmd \$tb_name \"_tb/sv ../tb/\" \$tb_name \"_tb/sv/\" \$tb_name \"_tb.sv\"\n";
    print FH "    eval \$cmd\n\n";

    print FH "#vsim "
      . $tbname
      . "_tb +UVM_TESTNAME="
      . $tbname
      . "_test +UVM_VERBOSITY=UVM_FULL -sv_lib \$env(UVM_LIB) -voptargs=+acc -solvefaildebug -uvmcontrol=all -classdebug\n";
    print FH "vsim "
      . $tbname
      . "_tb +UVM_TESTNAME="
      . $tbname
      . "_test +UVM_VERBOSITY=UVM_FULL -voptargs=+acc -solvefaildebug -uvmcontrol=all -classdebug\n";
    print FH "run 0\n";
    print FH "#do wave.do\n";
    close(FH);

    ### add execute permissions for script
    chmod( 0755, $dir . "/compile_questa.do" );
}

sub gen_vcs_script {
    my $dir = $project . "/sim";
    my $vcs_opts =
      "-sverilog +acc +vpi -timescale=$timeunit/$timeprecision -ntb_opts uvm";
    open( FH, ">" . $dir . "/compile_vcs.sh" )
      || die("Exiting due to Error: can't open file: compile_vcs.sh");
    print FH "#!/bin/sh\n";
    print FH "vcs $vcs_opts \\\n";
    gen_compile_file_list();
    print FH "-R +UVM_TESTNAME=${tbname}_test +UVM_VERBOSITY=UVM_FULL \$* \n";
    close(FH);

    ### add execute permissions for script
    chmod( 0755, $dir . "/compile_vcs.sh" );
}

sub gen_ius_script {
    my $dir = $project . "/sim";
    my $ius_opts =
      "-vtimescale $timeunit/$timeprecision -uvmhome \${IUS_HOME}/tools/uvm";
    open( FH, ">" . $dir . "/compile_ius.sh" )
      || die("Exiting due to Error: can't open file: compile_ius.sh");
    print FH "#!/bin/sh\n";
    print FH "IUS_HOME=`ncroot`\n";
    print FH "irun $ius_opts \\\n";
    gen_compile_file_list();
    print FH "+UVM_TESTNAME=${tbname}_test +UVM_VERBOSITY=UVM_FULL \$* \n";
    close(FH);

    ### add execute permissions for script
    chmod( 0755, $dir . "/compile_ius.sh" );
}

sub gen_compile_file_list {
    my $incdir = "+incdir+../tb/include \\\n";
    foreach my $i ( 0 .. @inc_path_list - 1 ) {
        if ( $inc_path_list[$i] ne "" ) {
            $incdir .= "+incdir+$inc_path_list[$i] \\\n";
        }
    }
    $incdir .= "+incdir+../tb/${tbname}_common/sv \\\n";

    foreach my $aname (@stand_alone_agents) {
        if ( $aname ne "" ) {
            $incdir .= "+incdir+../tb/${aname}/sv \\\n";
        }
    }
    foreach my $agent (@agent_list) {
        if ( ( $agent ne "" ) and !grep( /$agent/, @stand_alone_agents ) ) {
            $incdir .= "+incdir+../tb/${agent}/sv \\\n";
        }
    }
    do {
        foreach my $agent (@env_list) {
            $agent =~ /(\w+)_env/;
            if ( $agent ne "" ) {
                $incdir .= "+incdir+../tb/${agent}/sv \\\n"
                  if exists $agent_sub_access{$1};
            }
        }
    } if $regmodel;

    $incdir .= "+incdir+../tb/${tbname}/sv \\\n";
    $incdir .= "+incdir+../tb/${tbname}_test/sv \\\n";
    $incdir .= "+incdir+../tb/${tbname}_tb/sv \\\n";

    print FH "$incdir";
    print FH "-F ../${dut_tb_dir}/files.f \\\n";

    #compile the register model package;
    print FH "../tb/regmodel/regmodel.sv \\\n" if $regmodel;

    print FH "../tb/${tbname}_common/sv/${tbname}_common_pkg.sv \\\n";

    #need to compile agents before envs
    foreach my $aname (@stand_alone_agents) {
        if ( $aname ne "" ) {
            print FH "../tb/${aname}/sv/${aname}_pkg.sv \\\n";
        }
    }
    foreach my $agent (@agent_list) {
        if ( ( $agent ne "" ) and !grep( /$agent/, @stand_alone_agents ) ) {
            print FH "../tb/${agent}/sv/${agent}_pkg.sv \\\n";
        }
    }
    do {
        foreach my $agent (@env_list) {
            $agent =~ /(\w+)_env/;
            if ( $agent ne "" ) {
                print FH "../tb/${agent}/sv/${agent}_pkg.sv \\\n"
                  if exists $agent_sub_access{$1};
            }
        }
    } if $regmodel;

    print FH "../tb/${tbname}/sv/${tbname}_pkg.sv \\\n";
    print FH "../tb/${tbname}_test/sv/${tbname}_test_pkg.sv \\\n";
    print FH "../tb/${tbname}_tb/sv/${tbname}_th.sv \\\n";
    print FH "../tb/${tbname}_tb/sv/${tbname}_tb.sv \\\n";
}

