#!/bin/sh
IUS_HOME=`ncroot`
irun -vtimescale 1ns/10ps -uvmhome ${IUS_HOME}/tools/uvm \
+incdir+../tb/include \
+incdir+../tb/top_common/sv \
+incdir+../tb/s_infip_ufscon_databuff/sv \
+incdir+../tb/top/sv \
+incdir+../tb/top_test/sv \
+incdir+../tb/top_tb/sv \
-F ../dut/files.f \
../tb/top_common/sv/top_common_pkg.sv \
../tb/s_infip_ufscon_databuff/sv/s_infip_ufscon_databuff_pkg.sv \
../tb/top/sv/top_pkg.sv \
../tb/top_test/sv/top_test_pkg.sv \
../tb/top_tb/sv/top_th.sv \
../tb/top_tb/sv/top_tb.sv \
+UVM_TESTNAME=top_test +UVM_VERBOSITY=UVM_FULL $* 
