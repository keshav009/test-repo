#!/usr/bin/perl -w
#========================================================================================================================================================
#  Task 	: Perl Script 
#  
#  Filename 	: test.pl
#
#========================================================================================================================================================
#
#  Description	: Perl script to assist user in running single test cases or regression lists using cadence sim tool.
#
#========================================================================================================================================================
#
#========================================================================================================================================================
#Libraries Used.
#========================================================================================================================================================
use strict;
use warnings;
use Getopt::Long;					#Getopt::Long is used for command line arguments while executing the perl script.
use Switch;						#Switch is equivalent to case statements.
use POSIX qw(strftime);					#strftime is used to get the current time in any desired format.
use Cwd;						#cwd() returns the current working directory in which the perl script is executing.
use File::Copy;
use File::Path;


#========================================================================================================================================================
# Validity Variables Used for test and regression.
#========================================================================================================================================================

my $valid_test 	= 'nil';				#Flag to keep track if the single test case option is selected by the user
my $valid_reg  	= 'nil';				#Flag to keep track if the regression option is selected by the user.
my $retest 	= 0;					#$retest keeps track of the number of times each test_case is to be run.
my $select 	= 'none';				#$select is used to switch betweem compile, test or regression mode.
my $state	= 1;					# To operate as static variable while creating the excel sheet.
#========================================================================================================================================================
#Variables to store the IRUN commands for test and regression.
#========================================================================================================================================================

my $cmd_reg='';
my $cmd_test='';

#========================================================================================================================================================
#OPTIONS- These variables are used to store all the required options for test and regression.
##========================================================================================================================================================
my $reg_file;							# $reg_file is used to store the regression file list.
my $uvm_verbosity = 'nil';					
my $seed = 'nil';
my $stop_time ='nil';
my $test_name_single;						# $test_name_single is used to store a single test case name.
my $frtl;							# $frtl is use to store the rtl file list. 
my $ftb;							# ftb is used to store the testbench filelist.
my $tool;							# Holds the tool name - ncsim, vcs, modelsim.
my $inclist;							 
my $vtimescale;
my $deflist = 'nil';
my $sim_mode;
my $gui ='nil';
my $dump = 'nil';
my $log = 'nil';		
my $log_status = 'passed';					# It holds the status of the log file as either passed or failed.
my $vip_library ='nil';
my $no_of_licenses=3;					# Default taken as 3 and it can be changed by the user.
my $excel='nil';
my $options='nil';						# Extra options to be added.
#========================================================================================================================================================
#To read from a recevied file the mandatory and optional options for test and regression and store them in an array @option_array
#========================================================================================================================================================
sub retrieve

{
	my @option_array,my $rcv_fh,my $row,my $rcv_file=$_[0];
	open($rcv_fh,'<',$rcv_file) or 
	die " The file $rcv_file does not exist. Copy it from the orginal script folder\n";
	while( $row =<$rcv_fh>)
	{	
		chomp($row);
		push(@option_array,$row);
	}
	return @option_array;
}

#========================================================================================================================================================
#Passs the text files which hold the Mandatory and optional options and store them in their respective arrays
#========================================================================================================================================================
	
my @mandatory_single=retrieve('mandatory_single.txt');
my @mandatory_regression= retrieve('mandatory_regression.txt');
my @mandatory_compile= retrieve('mandatory_compile.txt');
my @optional_single=retrieve('optional_single.txt');
my @optional_regression=retrieve('optional_regression.txt');
my @single_options=(@mandatory_single,@optional_single);
my @regression_options=(@mandatory_regression,@optional_regression);
my @received_options;						#This array holds all the options entered by the user.

my $boolean='compile';			# Stat executes the staement only once and $boolean is 'compile'.
#========================================================================================================================================================
#Directories.
#========================================================================================================================================================
my $top_dir;							# Stores the path of the ..../verification directory of the root projet structure.
my $current_dir;						# Stores the path of the ..../ scripts directory .
my $log_dir;							# Stores the path of the ..../ logs directory .
my $sim_dir;							# Stores the path of the ..../ sims directory .
my $workbook;							# Stores the excel workbook name which holds the final excel report
my $worksheet1;							
my $rw = 2;							# To keep track of the $row_count while entering data into the excel worksheet
my $report_file;						# To store the excel report.

#========================================================================================================================================================
#Initialising the paths to the different directory variables accordingly
#========================================================================================================================================================

$current_dir = cwd();
my @temp=split('/',$current_dir); 
pop(@temp);
$top_dir=join('/',@temp);
$sim_dir=$top_dir."/sim_dir";
$log_dir=$top_dir."/logs";

#========================================================================================================================================================
#This method receives the different options specified below, from the command line when the script is executed.
#As and when the user enters a particular option, the script jumps to the corresponding subroutine and executes the task in it.
#========================================================================================================================================================

GetOptions( 	"regression=s"		=>\&regression,
	    	"test=s"		=>\&test,
	     	"uvm_verbosity=s"	=>\&uvm_verbosity,
		"seed=s"		=>\&seed,
		"stop_time=s"		=>\&stop_time,
		"frtl=s"		=>\&frtl,
		"ftb=s"			=>\&ftb,
		"tool=s"		=>\&tool,
		"inclist=s"		=>\&inclist,
		"dump=s"		=>\&dump,
		"vtimescale=s"		=>\&vtimescale,
		"log=s"			=>\&log,
		"vip_library=s"		=>\$vip_library,
		"gui"			=>\&gui,
		"excel"			=>\$excel,
		"deflist=s"		=>\&deflist,
		"sim_mode=s"		=>\&sim_mode,	
		"licenses=i"		=>\$no_of_licenses,
		"options=s"		=>\&options,
	    	"help=s"		=>\&help,) or help();	# If any user options are not in the list or if there are no options specified for an option.
								# An error is thrown accodrdingle and The help file is called and the program dies.

#========================================================================================================================================================
#This subroutine validates if the received  file or directory  argument exists
#========================================================================================================================================================

sub file_exist

	{
		if (-e $_[0])							# Checks if the file exists.
		{  
			if(-R $_[0]){}						# Checks if the file is readable.
			else
			{
				die "\n\nError:File $_[0] is not readable.\n";
			}
		}				
		else	
                {
	       		die "\n\nError:File :$_[0] does not exist.\n";          # Error thrown if it is otherwise.
		}	
	}

#========================================================================================================================================================
# Depending on the received options or options entered by the user, these subroutines are called.
#========================================================================================================================================================
sub regression
	{	
		$valid_reg = 'true';			# This flag is used as an indication that the user entered regression.
		$select = 'reg';			# The mode of operation is selected as regression.
		$reg_file=$current_dir.'/'.$_[1];	# Appending the full path to the regression file.
		file_exist($reg_file);			# Checking if the regression filelist file exists and if it is readable
		$reg_file=$_[1];			# Storing the regress filelist name without the whole path , to create the sim_dir later.
		push(@received_options,$_[0]);		# Storing the received option regression in an array.
		
	}

#---------------------------------------------------------------------------------------------------------
sub test
	{
		
		$valid_test='true';			# This flag is used as an indication that the user entered regression.
		$select='test';				# The mode of operation is selected as regression.
		$test_name_single=$_[1];		# The single test case name is stored in this variable.
		push(@received_options,$_[0]);		# Storing the received option test in an array.
	}

#---------------------------------------------------------------------------------------------------------
sub uvm_verbosity
	{
		$uvm_verbosity= $_[1];			# The uvm_verbosity value is stored in this array.
		push(@received_options,$_[0]);		# Storing the received option uvm_verbostiy in an array.
	}
#---------------------------------------------------------------------------------------------------------
sub gui
	{
		$gui = $_[1];				# The gui is set in this variable.
		push(@received_options,$_[0]);		# Storing the received option gui in an array.
		
	}


#---------------------------------------------------------------------------------------------------------
sub seed
	{
		$seed = $_[1];				# The seed value is stored in this variable.
		push(@received_options,$_[0]);		# Storing the received option seed in an array.
	}
#---------------------------------------------------------------------------------------------------------
sub options
	{

		$options = $_[1];				# The inclist file is saved in this variable.
		$options=$current_dir.'/'.$options;		# The full path is prepended to the inclist file name.
		file_exist($options);				# Checking if the inclist filelist file exists and if it is readable.

		#push(@received_options,$_[0]);			# Storing the received option inclist inclist in an array.
	
	}
#---------------------------------------------------------------------------------------------------------
sub stop_time
	{
		$stop_time = $_[1];			# The simulation stop time is stored in this variable.
		push(@received_options,$_[0]);		# Storing the received option stop_time in an array.
	}

#---------------------------------------------------------------------------------------------------------
sub dump
	{
		$dump=$current_dir.'/'.$_[1];		# Appending the full path to the .tcl file
		push(@received_options,$_[0]);		# Storing the received option dump in an array
		my $dump_fh;				# Printing exit as the last line in the tcl file.
		open($dump_fh,'>',$_[0]);
		print $dump_fh "\nexit";
		close $dump_fh;
		
	}

#---------------------------------------------------------------------------------------------------------
sub log
	{
		$log = $_[1];				# The log file name is stored in this variable
		push(@received_options, $_[0]);		# Storing the received option log in an array
	}

#---------------------------------------------------------------------------------------------------------
sub vtimescale
	{	
		$vtimescale = $_[1];			# The vtimescale is stored in this variable.
		push(@received_options,$_[0]);		# Storing the received option vtimescale in an array

	}
#---------------------------------------------------------------------------------------------------------
sub inclist
	{
				
		$inclist = $_[1];				# The inclist file is saved in this variable.
		$inclist=$current_dir.'/'.$inclist;		# The full path is prepended to the inclist file name.
		file_exist($inclist);				# Checking if the inclist filelist file exists and if it is readable.
		push(@received_options,$_[0]);			# Storing the received option inclist inclist in an array.
	}
#-----------------------------------------------------------------------------------------------------------------------------------
sub deflist 
	{
				
		$deflist = $_[1];				# The deflist file is daved in this variable.
		$deflist=$current_dir.'/'.$deflist;		# The full path is prepended to the deflist file namne.
		file_exist($deflist);				# Checking if the define filelist file exists and if it is readable
		push(@received_options,$_[0]);			# Storing the received option deflist in an array.
	}

#---------------------------------------------------------------------------------------------------------
sub ftb
	{

		$ftb = $_[1];					# The TB filelist is saved in this variable
		$ftb =$current_dir.'/'.$ftb;			# The full path is prependede to this TB filelist.
		file_exist($ftb);				# Checking if the TB filelist file exists and if it is readable.
		push(@received_options,$_[0]);			# Storing the received option ftb  in an array
		
	}

#------------------------------------------------------------------------------------------------------------------------------------
sub frtl
	{

		$frtl = $_[1];					# The RTl filelist file is saved in this variable.
		$frtl=$current_dir.'/'.$frtl;			# The full path is prepended to the RTl filelist file.
		file_exist($frtl);				# Checking if the RTL filelsit file exists and if it is readable.
		push(@received_options,$_[0]);			# Storing the received option in an array.
		
	}
#------------------------------------------------------------------------------------------------------------------------------------
sub sim_mode
	{	
		my @legal_sim_mode = qw(rtl_sim compile);				# This array contains the values which are allowed as arguements for the sim_mode option.
		$sim_mode=$_[1];							# The sim_mode is saved in this variable.
		if (grep { $_ eq $sim_mode } @legal_sim_mode)				# This checks if the received option is valid and allowed option or not
		{									# Currently only rtl_sim and compile are funcitonal, and accordingly
											# log and sim dirs are appended, the gate and cov simulations can be added.
			switch($sim_mode)						
			{
				case 'compile'  {	$select='compile';		
							$sim_dir=$sim_dir.'/rtl_sim'; 	
							$log_dir=$log_dir.'/rtl_sim';	
						}
				case 'rtl_sim'  {	$sim_dir=$sim_dir.'/rtl_sim';	
							$log_dir=$log_dir.'/rtl_sim';
						}
				 
			}
			push(@received_options,$_[0]);					# The recevied option sim_mdoe is stored in the array.
		}
		else
		{
			print "\n Error: Wrong option for sim_mode.\n Specify one of the following @legal_sim_mode\n";	# Error message is printed if the receved option argument is not valid and the program dies.
			die("\n");
		}
	}
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
sub tool
	{
	my @legal_tool = qw(modelsim ncsim vcs);		# These are the allowed options for tool.
	if ( grep { $_ eq $_[1] } @legal_tool)			# The user entered value is compared with the legal/allowed values.
	{
	
		$tool=$_[1];					# The tool value is stored in this variable.
		push (@received_options,$_[0]);		     	# Storing the received option tool in an array
	}
	else
	{
		print "\nerror: must specify one of the following argumentsfor \"-tool \" \n@legal_tool\n"; 	#Error message is printed if the user enters an invlaid value allowed for tool.
		die "\n";
	}


	}

#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
sub help

	{
		my $help_text=$current_dir.'/help.txt';			# Prepends the full path to the help,txt file.
		file_exist($help_text);					# Checls if the help file exists.
		system("cat $help_text");				# Displays the help fiule on the console file.
		die("\n");						# Kills the program.
	}

#======================================================================================================================================================================================
# DATE AND TIME
#This subroutine is used to return date and time in the @return array.
#It is currently not used and can be used if needed, as the sim date and time 
#is grepped from the irun.log file itself.
#======================================================================================================================================================================================
sub get_date_time	

	{
		my $date=strftime "%d-%m-%Y",localtime;		# Command to retrieve  date in ddmmyyy format.
		my $time=strftime "%T",localtime;		# Command to retrive time.
		my @time=split(' ',$time);			
		my @return;
		push(@return,$date);
		push(@return,$time[0]);
		return @return;					# Returns the date and time found.
		}


#======================================================================================================================================================================================
# MISSING_SINGLE_TEST
# This is to check if any mandatory options for single test are not specified 
#======================================================================================================================================================================================
sub missing_test
	{
			my @missing;											# Array to store the missing mandatory options 
			foreach my $variable(@mandatory_single)			
				{				
					push (@missing,$variable) unless grep { $_ eq $variable } @received_options;	# If any of the mandatory options are not in the received list of options, they are pushed to @missing.
				}		
			if(scalar @missing != 0)									# If there are missing options, print Error message.				
				{
					print "\nError:Mandatory Options to run a single test is not specified.\nThe missing options is/are @missing.\n"; 
					help();
				}		

			foreach my $variable (@received_options)							# If any variable in the revceived option list is not optional for single test, an error is thrown.
				{
	
					print "\nError:The option specified $variable is not a valid optional variable for single.\n" and help()  unless grep { $_ eq $variable } @single_options;

				}

	}

#======================================================================================================================================================================================
# MISSING_REGRESSION_TEST
# This is to check if any mandatory options for regression test are not specified
#======================================================================================================================================================================================

sub missing_reg
	{

			my @missing;											# Array to store the missing mandatory options
			foreach my $variable(@mandatory_regression)
				{
				push(@missing,$variable) unless grep { $_ eq $variable } @received_options;		# If any of the mandatory options are not in the received list of options, they are pushed to @missing.

				}
			if(scalar @missing != 0)									# If there are missing options, print Error message.				
			{	
					print "\nError:Mandatory Options to run a regression test is not specified.\nThe missing option is/are @missing.\n";
					help();
			}

			foreach my $variable (@received_options)							# If any variable in the revceived option list is not optional for single test, an error is thrown.
				{
	
					print "\nError:The option specified $variable is not a valid optional variable for regression test.\n" and help() unless grep { $_ eq $variable } @regression_options;
					
				}


	}


#======================================================================================================================================================================================
# MISSING_COMPILE_TEST
# This is to check if all mandatory options for compile mode are specified or not
#======================================================================================================================================================================================
sub missing_compile
	{
		my @missing;											# Array to store the missing mandatory options
		foreach my $variable(@mandatory_compile)
			{
				push (@missing,$variable) unless grep {$_ eq $variable } @received_options;	# If any of the mandatory optins are not in the received list of options, they are pushed to @missing
		
			}
		if(scalar @missing != 0)									# If there are missing options print the Error Measage
			{
				print "\n Error : Mandatory options to compile the test are not specified\n. The missing options is/are @missing \n";
				help();
			}
	
	
	
	
	}

#======================================================================================================================================================================================
#INITIALIZE THE DIRECTORY
# This initializes the sim_directory and the logs directory
#======================================================================================================================================================================================
sub init_dir
	{	
		my $sub_dir_name = $_[0];							# Receive the sub_directory name . Eg : reglist_8.fl, reglist_16.fl, single_test.
		if (($select eq 'compile' and $valid_reg eq 'true') or ($select eq 'reg'))	# If not compile and not single test, in other words if only regression: then chop ".fl" extention.
		{
			chop ($sub_dir_name);
			chop ($sub_dir_name);
			chop ($sub_dir_name);
		}
		$sim_dir=$sim_dir.'/'.$sub_dir_name;						# Prepend the entire path to the received sub_directory_name.
		if (-e $sim_dir)								# Check if the sub_directory exists.
		{	
			chdir $sim_dir;								# Change directory to the sub_dir.
			opendir (my $dh, $sim_dir) or die "failed \n";				# open a Directory file handle.

			my @dirs = grep { -d "$sim_dir/$_" && ! /^\.{1,2}$/ } readdir ($dh);	# read all the direcotries in it into @dirs array.

				foreach my $dir_name ( @dirs)		
				{	
					if ( ($dir_name ne 'common_libs') )			# Remove all directories except the common_libs.
					{
						
						my $remove = $sim_dir.'/'.$dir_name ;
						rmtree( $remove ) or die "couldn not remove \n";
				
					}
				}


		}
		else										
		{	
			mkpath "$sim_dir" or die "Could not create $sim_dir\n";							# If sub_directory does not exist, create it.
		}


		$log_dir=$log_dir.'/'.$sub_dir_name;						# Prepend the entire path to the log_sub_directory.
		if (-e $log_dir)								# Check if it exists
		{
			rmtree $log_dir or die "Could not remove $log_dir\n";						# If it does , clear all data in it by deleting it.
		} 
		
			
		mkpath "$log_dir" ; 								# Re-create it . create failed, passed and report directories inside of it.
		
		my $failed = $log_dir.'/failed';						
		my $passed = $log_dir.'/passed';
		my $report = $log_dir.'/report';

		mkpath("$failed");
		mkpath("$passed");
		mkpath("$report");

				
		chdir $current_dir;								#Change back to current direcotry.
	}


				
#======================================================================================================================================================================================
#======================================================================================================================================================================================
sub vip_library
	{
		my $test_sub_dir = $_[0];
		my $test_sim_dir=$sim_dir.'/'.$test_sub_dir;
		chdir $test_sim_dir;
		my $exe = 'create_vip.sh';
		
		if (-d "$vip_library")
		{
			print "vip_lib Exists. Not creating again \n";
		}
		else
		{
			print "VIP does not exist, Creating it again \n"; 
			open(my $fh,'>',$exe);
			print $fh "cd $test_sim_dir\n";
			print $fh '${CDN_VIP_ROOT}/bin/cdn_vip_setup_env -cdnautotest -s ncsim_irun -cdn_vip_root ${CDN_VIP_ROOT} -m sv_uvm -csh -cdn_vip_lib '.$vip_library.' -i axi';
			my $mode = 0777;				# Make the file executable
			chmod $mode, "$exe";			
			system ("qsub $exe");
			my $num_jobs = 0;
			my $user = $ENV{"USER"};					# Returns the current users name.
			do
			{
				print "waiting \n";
				$num_jobs = `qstat | grep "$user" | grep "$exe" |wc -l `;			# This returns the number of processes which are currently running.
			}while ( $num_jobs >0)
		}	
		#die "DONE CREATING\n";
	
	}
#======================================================================================================================================================================================
#Create a directory for the corresponding test_name
#======================================================================================================================================================================================
sub create_dir_test_name
	{
		my $test_name = $_[0];
		mkpath ("$sim_dir/$test_name");
	}

#======================================================================================================================================================================================
#CREATE_LOG
#To copy the log file generated to the log file folder and grep the required info and save it in report.xls
#======================================================================================================================================================================================
sub create_log		
	{
		
		my $test_name_single=$_[0];						# Store the test case name in this variable.
		my $test_dir_name=$_[1];						# Store the sub_simulation_directory name in this varaible.
		my $log_irun_dir=$sim_dir.'/'.$test_dir_name;			
		chdir $log_irun_dir or die "Failed to change to $log_irun_dir\n";	# Navigate to the directory where the simulation is taking place.	
		if ( $log ne 'nil')							# If User has specified log name through options change the log file name.
		{
			$test_name_single = $log;
		}
		
		
#Opening and reading the log file----------------------------------------------------------------------------------------------------------------------------------------------------
		
		my @log_list;								# To store all the lines in the generated test_name.log file into the @log_list array
		my $log_fh;								# File_handle to open the test_name.log file.
		my $irun_log_file = $log_irun_dir.'/'.$test_name_single;		# Prepend the test case name with the directroy whrere the log file will be placed.
		file_exist("$irun_log_file");						# Check if the log file exists
		open($log_fh,"$irun_log_file");						
		@log_list=<$log_fh>;							# Read all the lines in the log file into the @log__list array.
#CPU Usage---------------------------------------------------------------------------------------------------------------------------------------------------------------------------


		my $cpu_use=retrieve_log_info(@log_list,"CPU Usage","Usage",2,'end');	# CPU Usage is grepped from the log file and the sub routine retirve_log_info , returns the values.
		if ($cpu_use eq '')
		{	
			return 0;							# If the cpu usage if empty , that means the log file hasnt been generated completely, and the sub finished execution.
		}
#Start Time and Date----------------------------------------------------------------------------------------------------------------------------------------------------------------

		my $start_time=retrieve_log_info(@log_list,"Started on","at",1,2); 	# start time is grepped from the log file and the sub routine retirve_log_info , returns the values.
		my $start_date=retrieve_log_info(@log_list,"Started on","at",-3,0);	# start date is grepped from the log file and the sub routine retirve_log_info , returns the values.
		
#Stop Time and Date------------------------------------------------------------------------------------------------------------------------------------------------------------------

		
		
		my $end_time=retrieve_log_info(@log_list,"Exiting on","at",1,2);	# end time is grepped from the log file and the sub routine retirve_log_info , returns the values.		
		my $stop_date=retrieve_log_info(@log_list,"Exiting on","at",-3,0);	# end date is grepped from the log file and the sub routine retirve_log_info , returns the values.
		my $tot_sim=retrieve_log_info(@log_list,"Exiting on","at",4,5);		# total sim time is grepped from the log file and the sub routine retirve_log_info , returns the values
		chop $tot_sim;								# Chop to remove any trailing character

#Passed or Failed, LOG_STATUS--------------------------------------------------------------------------------------------------------------------------------------------------------
		my $error=retrieve_log_info(@log_list,"UVM_ERROR :",":",1,2);
		my $fatal=retrieve_log_info(@log_list,"UVM_FATAL :",":",1,2);
		if (($error + $fatal) > 0 )						# If any fatal or errors are there in the log file, then store the log file in failed folder and update status as failed
		{
			$log_status = 'failed';
		}
		else
		{
			$log_status = 'passed';
		}


		
#Get SVSEED VALUE--------------------------------------------------------------------------------------------------------------------------------------------------------------------
		my $match="SVSEED";							# Match saves the word which is to be looked up in the log file
		my $seed = '';								
		my @match = grep /$match/,@log_list;					# All the lines which has the term SVSEED is stored in @match
		@match=split('',$match[0]);						# The first such line is split up
		my $count,my $stall;							
		foreach my $b(@match)							# Itereate over each element in the line
		{	
			if ($b eq ':')							# as soon as " : " is found, store the index in stall
			{
			  $stall=$count;						
			}
			$count ++;							# Increment Count to keep track of index of each element in the array.
		}
		for ($count = ($stall+2); $count < scalar @match; $count ++)		# Print the seed value by using the ' stall' value saved from the previous iteration
		{	
			$seed=$seed.$match[$count];					# Check out a sample log file for more information.
		}	
		$seed =~ s/|s+$//;							# Rmeove any white spcaes to the right
		chomp $seed;								# Remove trailing new line characters

#Retriving the test name by chopping off the extra 9 characters used while creating the file plreq.log------------------------------------------------------------------------------------------
		my $repeat = 4;
		while ( $repeat > 0 )
		{
			chop $test_name_single;
			$repeat --;
		}
			
#Update the excel filee-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	if ($excel ne 'nil')
	{	use Spreadsheet::ParseExcel;				#ParseExcel is used to read data from rows and columns from excel worksheets.
		use Spreadsheet::ParseExcel::SaveParser;		#SaveParser is used to dynamically update the excel when the script is running

		my $parser = Spreadsheet::ParseExcel::SaveParser->new();		# Create a new SaveParser and save it in $parser.
		my $wb = $parser->Parse("$report_file");				# Use $parser to open the initially craeted excel file $report_file.
		my $wk = $wb->worksheet(0);						# navigate to the first worksheet in the excel file.
		my $cw = 1;						
		$wk->AddCell($rw,$cw++,$rw-1);						# Write the Sl No.
		$wk->AddCell($rw,$cw++,$test_name_single);				# Write the test case name
		$wk->AddCell($rw,$cw++,$log_status);					# Write the log_status passed or failed
		$wk->AddCell($rw,$cw++,$cpu_use);					# Write the CPU USAGE
		$wk->AddCell($rw,$cw++,$start_time);					# Write the start time
		$wk->AddCell($rw,$cw++,$end_time);					# Write the end time
		$wk->AddCell($rw,$cw++,$tot_sim);					# Write the tot sim time
		$wk->AddCell($rw,$cw++,$seed);						# Write the seed value
		$wk->AddCell($rw,$cw++,$start_date);					# Write the start _date
		$wk->AddCell($rw,$cw++,$stop_date);					# Write the stop_date
		$rw++;									# GO to the next row, to add the next log file details.
		$wb->SaveAs("$report_file");						# Save the report file after appending deatails about each test case.
	}


	
#Create and copy the log file------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

		
		my $log_name=$test_name_single."_".$seed."_".$stop_date."_".$end_time.'.log';	
		my $log_final_file =$log_dir.'/'.$log_status.'/'.$log_name;			# Append all the details to log file name_seed_stopdate_endtime	
		copy("$irun_log_file","$log_final_file") or die "Failed copy of irun.log\n";	# Copy the log file into the passed or failed directory
		return 1;									# Return 1 if the entire grepping and copying process is successfull
	}

#======================================================================================================================================================================================
#RETRIVE_LOG_INFORMATION
# This subroutine is called to retrieve all the log information from the file
#======================================================================================================================================================================================
sub retrieve_log_info
	{
		my $count = 0;								# Count to store the index of the array containing row elements.
		my $pos_end = pop (@_);							# Pop the index of the end position upto which data is to be copied
		my $pos_start = pop (@_);						# Pop the index of the satrt position from which data is to be copied
		my $pos_string = pop (@_);						# Pop the string which is to be taken as the reference from which data is to be copied
		my $match = pop (@_);							# Pop the $match , keyword which is to be grepped from the log file.
		my @log_list = @_;							# This array contains all the rows in the log file
		my $stall;								# Variable to keep track of the Index from which data is to be copied.
		my $log_info='';							# Stored the final information which is to returned.

		my @match = grep /$match/,@log_list;					# To grepa and store all the lines in the log file which match with #$match.
		if(scalar @match > 0)							# If any useful match is found , enter into the if loop.
		{
			@match=split(' ',$match[0]);					# Split the matched row into elements, separated by spaces.
			foreach my $b(@match)
			{	
				if ($b eq $pos_string)					# keep track of the index of the pop_string
				{
					  $stall=$count;
				  
				}
			$count ++;
			}
		
			if ($pos_end eq 'end')
			{
				$pos_end = (scalar @match) - 2;				# Special case in the case of total_sim

			}
			for ($count = ($stall+$pos_start); $count < ($stall + $pos_end); $count ++)

			{	
				$log_info=$log_info.' '.$match[$count];			# Navigate over the pop_start and pop_end with the help of the stall value
			}
		}
		return $log_info;							# return the required log_information.
	}



#======================================================================================================================================================================================
# COMPILE TEST
#To create compile_ncsim.sh file and compile it
#======================================================================================================================================================================================
sub compile_test
	{
		my $cmd_test_copy=$_[0];				# Make a copy of the received irun command with the required options and data
		my $test_dir=$sim_dir.'/common_libs';			# Append the sim_dir with the common_libs directory.
		if (-e $test_dir)					# Check if the common libs dir exists.
		{									
			chdir "$test_dir";				# Change DIR to the common libs dir
			goto COMPILE;					# Jump to label COMPILE
		}
		else
		{
			mkpath ("$test_dir");			# If common_libs does not exist, create it.
			chdir $test_dir;				# Change directory to the common_libs directory.
	COMPILE:	 	
			my $op_fh,my $op_file="compile_ncsim.sh";	# name the bash file
			open($op_fh,'>',$op_file);			# Open it with a file_handle and add data to it .
			print $op_fh "#!/bin/sh\n";			
			print $op_fh "IUS_HOME=`ncroot`\n";
			print $op_fh $cmd_test_copy.'-elaborate $*';	# -elaborate option only to compile and generate the snapshot
			close $op_fh;					# Close the file handle
			my $mode = 0777;				# Make the file executable
			chmod $mode, "$op_file";			
			system ("./$op_file");				# Compile Operation
			chdir "$current_dir";				# Change directory back to the current directory.
		}	
	}

#======================================================================================================================================================================================
# NUMBER OF RUNNING JOBS
#Check to check the number of uunning jobs.
#======================================================================================================================================================================================
sub no_of_running_jobs
	{	
	my $user = $ENV{"USER"};					# Returns the current users name.
	my $num_jobs = `qstat | grep "$user" |wc -l `;	# This returns the number of processes which are currently running.
	return $num_jobs;					
	}

#======================================================================================================================================================================================
# LOG GREP
# Once the number of running processes are less than three, then grep the current directory for any .log files and send it to the create_log sub routine.
#======================================================================================================================================================================================
sub log_grep
	{	
		my $test_sub_dir=$_[0];					# Recieve the current simulation directory.
		my $test_dir=$sim_dir.'/'.$test_sub_dir;		# Prepend the entire path.	
		chdir "$test_dir";					# Navigate to the above dir.
		my @log_files = `ls | grep ".log"`;			# Grep the sim dir for the .log files.
		foreach my $log(@log_files)				
		{	
			chomp $log;					# Remove trailing nw line characters.
			my $log_complete=create_log($log,$test_sub_dir);# Send it to the create_log file sub.
			unlink $log if $log_complete;			# Remove the log file if all the required info has been successfully grepped.
		}
	}

#======================================================================================================================================================================================
#RUN TEST
#To run the .sh file
#======================================================================================================================================================================================
sub run_test
	{
		my $cmd_test_copy=$_[0];			# Make a copy of the irun command
		my $test_sub_dir =$_[1];			# Save the sub directory name where the simulation is to be run.
		my $test_name    =$_[2];			# Save the test_case name.
		my $test_dir=$sim_dir.'/'.$test_sub_dir;	
		chdir "$test_dir";				# change directory to the simulation directory.
		my $op_fh,my $op_file = $test_name.".sh";	
		open($op_fh,'>',$op_file);			# Open a file handle to write into the output bash .sh file.
		print $op_fh "#!/bin/sh\n";			
		print $op_fh "IUS_HOME=`ncroot`\n";		
		print $op_fh "cd $test_dir\n";			# Change directory to test directory is mandatory before writing the irun command.
		print $op_fh $cmd_test_copy.'-R -nclibdirname '.$sim_dir.'/common_libs/INCA_libs '.'-log '.$test_name.'.log $*';	# Appending the -R option To run prev elaborated file , -nclibdirname option to provide location
		close $op_fh;														# of INCA_libs, - log to specify log file name.
		my $mode = 0777;				# Change mode of the .sh file to make it exceutable.
		chmod $mode, "$op_file";			
#KILLING HERE ------------------
		die "\n";		
#KILLING HERE ------------------
		if ($select eq 'reg')				# If run_test is called from the regression sub routine
		{
			SLEEP :			
			my $check = no_of_running_jobs();	# Wait/sleep if three jobs are currently running
			if ($check == $no_of_licenses)		
			{
				goto SLEEP;
			}
			system ("qsub $op_file");		# Submit job if slot is available
			log_grep($test_sub_dir);
		}
		else						# If run_test is called from the Single test case sub routine
		{
			system ("./$op_file");			# Execute the file on the terminal
		}
			
		chdir "$current_dir";				# Change the directory back to the current directory .	
	}

#======================================================================================================================================================================================
# SINGLE TEST
# This subroutine is called if the single test option is entered by the user
#======================================================================================================================================================================================

sub single_test
	{
		init_dir('single_test');				# To inititalize the sim_dir and the log_dir and its sub directories
		vip_library('common_libs') if ($vip_library ne 'nil');
		$report_file=create_report() if ($vip_library ne 'nil');# To inititalize the sim_dir and the log_dir and its sub directories
		compile_test($cmd_test);				# To create common_libs or check if it exists and to elaborate the design.
		create_dir_test_name($test_name_single);		# Creating the directory Top_test.
		tcl_files($test_name_single,'common_libs');
		run_test($cmd_test,$test_name_single,$test_name_single);# It goes into the above created directory and runs the command.
		create_log($test_name_single.'.log',$test_name_single);	# Reads all the info from log file seed, date , time , status, cpu usage and appends it to excel file and saves the log file in the appropriate direcotry
	}



#======================================================================================================================================================================================
#REGRESSION TEST
#This subroutine is called if the regression test option is entered by the user.
#======================================================================================================================================================================================

sub reg_test
	{
		init_dir($reg_file);					# To inititalize the sim_dir and the log_dir and its sub directories
		vip_library('common_libs') if ($vip_library ne 'nil');
		$report_file=create_report() if ($excel ne 'nil');	# To create the initial templete of the report with the required headings.
		chdir $current_dir;
		my $row, my $reg_fh,my @cmd_reg;			# Filehandle to open the regress filelist file.
		open($reg_fh,'<',$reg_file) or die"$! Could not open $reg_file\n";				# Open the regress file list file for reading.
		my $append = $cmd_reg;					# Copy of the irun command is stored in the $append variable.
		while($row = <$reg_fh>)					# Read each testfile line in the reglist file
		{	
			my @rcv_row=split(' ',$row);			# Split each row with 'space' as splitting references.
			my $arr_count = 0;				# To save index number of each element in the split array
			my $cmd_reg = $append;				# Saving the append varaible in the cmd_reg local varaible.
			my $retest=0;					# This determines the number of times the file is to be retested.
			my $test_name;					# This is to save each test case name
			foreach my $var(@rcv_row)			# Iterate over each element in the @rcv_row array
			{						# Check for matches : testname ., UVM_TIMEOUT, UVM_VERBOSITY, seed, retest
				switch($var)
						{
						case 'testname' 	{									# Append test case name to the irun command.
										$test_name=$rcv_row[($arr_count+2)];
										$cmd_reg=$cmd_reg."+UVM_TESTNAME=$rcv_row[($arr_count+2)] \\\n\t";
										
									}

						case 'UVM_TIMEOUT'	{									# Append timeout to irun command, if not specifically entered from command line
																		# Else retrieve it from the regression list
										if ( $stop_time eq 'nil' )
										{
											$stop_time = $rcv_row[($arr_count+2)];
										}
																		# If user enters it in command line, the uvm_timeout is fixed for all test cases
										$cmd_reg=$cmd_reg."+UVM_TIMEOUT=$stop_time \\\n\t";
								  	}	
						case 'UVM_VERBOSITY'	{									# Append verbosity to irun command, if specifically entered from command line
																		# Else retireve it from the regression list
										if ( $uvm_verbosity eq 'nil' )
										{
											$uvm_verbosity = $rcv_row[($arr_count+2)];
										}
																		# If user enters it in command line, the uvm_verbosity is fixed for all test cases
										$cmd_reg=$cmd_reg."+UVM_VERBOSITY=$uvm_verbosity \\\n\t";
									}
						case 'seed'		{									# Append seed to irun command, if specifically entered from command line
																		# Else retireve it from the regression list
										if ( $seed eq 'nil' )
										{
											$seed = $rcv_row[($arr_count+2)];
										}
										$cmd_reg=$cmd_reg."+svseed=$seed \\\n\t";				# If user enters it in command line, the svseed is fixed for all test cases.
									}			

						case 'retest'		{

										$retest = $rcv_row[($arr_count+2)];
									}

						}

				$arr_count++;													# index is incremented to keep track of the itereation over the array.

			  }				
			while ($retest >= 0)
			{
			create_dir_test_name('sim_common');				# Pass $test_name as second argument if individual/ separate directories are needed for each test case else pass sim_common
			tcl_files('sim_common','common_libs');
			
			if($boolean eq 'compile')					# Elaborate only once 
			{
				compile_test($cmd_reg);					# Compile the command.	
			}
			$boolean = 'run';						# Change boolean to run, therefore from the next test case onwards, only run is executed and it is not compiled.
			run_test($cmd_reg,'sim_common', $test_name.'_'.$retest);	# Run the command,
			$retest --;
			
			}
			
	        }
		

			
			SLEEP1:
			my $check = no_of_running_jobs();	# Wait/sleep if three jobs are currently running.
			if ($check > 1)				# If jobs are still running,wait. goto sleep1 again.
			{
				goto SLEEP1;
			}
				log_grep('sim_common');		# log_grep to grep all the log files in the simulation directory.
				
	}

sub tcl_files
	{	
		chdir $current_dir;
		my @tcl_files = `ls | grep ".tcl"`;			# Grep the sim dir for the .log files.
		my $tf, my $temp_sim_dir;
		$temp_sim_dir=$sim_dir.'/'.$_[0];
		my $temp_common=$sim_dir.'/'.$_[1];
		foreach my $tcl(@tcl_files)				
		{	
			chomp $tcl;
			$tf=$current_dir.'/'.$tcl;
			copy( $tf, $temp_sim_dir);
			copy( $tf, $temp_common);
		}
	}

#======================================================================================================================================================================================
#EXCEL SHEET CODING
#======================================================================================================================================================================================
sub create_report
	{	
		print " Excel Report Creation Enabled \n";
		use Spreadsheet::WriteExcel;							#WriteExcel is used to write data in rows and columns 
		my $report_file= $log_dir."/report/report_$sim_mode.xls";			#The report.xls file is created with the appropriate name and in the appropriate dir.
		my $worksheet_label="report_$sim_mode";						# The worksheet is labelled.
		my $cell_row= 1, my $cell_col=1;						# The cell row and cell col is set to the 2nd row and col respectively.
		my @headings=( 	'  Sl No. ',							# These are the list of parametersz / headings which are required to be added in the excel sheet.
				' Test Name ',
				' Passed/Failed ',
				' Cpu Usage Info ',
				' Sim Start Time ',
				' Sim End Time ',
				' Sim Time ',
				' Seed Value ',
				' Test Start Date ',
				' Test End Date ');

		($workbook,$worksheet1) = get_book_and_sheet ($report_file,$worksheet_label);	# Creates new workbook and worksheet
		make_header_row( $cell_row, $cell_col,@headings);				# Creates the basic templete with all the parameters in the excel sheet.
												# The following are used to set the colum n width for each of the parameters.
		$worksheet1->set_column('B:B',5);						# Sl no
		$worksheet1->set_column('C:C',50);						# Test name
		$worksheet1->set_column('D:D',12);						# Pass/fail
		$worksheet1->set_column('E:E',60);						# Cpu
		$worksheet1->set_column('F:F',15);						# Start TIme
		$worksheet1->set_column('G:G',15);						# End time
		$worksheet1->set_column('H:H',12);						# Sim time
		$worksheet1->set_column('I:I',12);						# Seed
		$worksheet1->set_column('J:J',17);						# Start date
		$worksheet1->set_column('K:K',17);						# End date

		$workbook->close; 								# Close the workbook.
		return $report_file;								# Return the path and name of the excel file created.
	}

#======================================================================================================================================================================================
#Creates the workbook and the worksheet.
#======================================================================================================================================================================================
sub get_book_and_sheet
			{ 
				my( $filename, $label) = @_; # only first run							
				if ($state == 1)
				{
					#state $workbook  = Spreadsheet::WriteExcel->new( $filename ) or die "Cannot open excel file\n";	# Stat is used so that this statement executes only the
					$workbook  = Spreadsheet::WriteExcel->new( $filename ) or die "Cannot open excel file\n";	# Stat is used so that this statement executes only the
					#state $worksheet1 = $workbook->add_worksheet( $label ) or die "Cannot open excel file\n";	# first time subroutine is called.
					$worksheet1 = $workbook->add_worksheet( $label ) or die "Cannot open excel file\n";	# first time subroutine is called.
					$state =2;
				}
				($workbook, $worksheet1); 
			} 

			
#======================================================================================================================================================================================
#Workbook .copy.xlsx header writing
#======================================================================================================================================================================================
sub make_header_row
			{ 
				my( $row , $column , @headings ) = @_;	 			# Receive the row, col, and headings which are to be written in the excel file.
				my( $workbook, $worksheet1) = get_book_and_sheet(); 		# Retrieve the workbook and worksheet name.				
				my $format = header_format(); 					# Retrieve the format of the header from the header_format() sub.
				$worksheet1->write( $row, $column++, $_,$format )  		# Write each parameter in each column, with the retireved format.
				foreach @headings; 
			} 

#======================================================================================================================================================================================
#Workbook .copy.xlsx header format
#This subroutine is a self understandable and it defines the
#format of the data which is to be entered in the excel sheet
#and this $format can be utilized whenever a write operation takes place
#======================================================================================================================================================================================
sub header_format 
			{ 
				my( $workbook, $worksheet ) = get_book_and_sheet(); 
				my $format = $workbook->add_format();  
				$format->set_bold(); 
				$format->set_bg_color('yellow'); 
				$format->set_align('center');
				$format; 
			}

#======================================================================================================================================================================================
#   MAIN PROGRAM
#======================================================================================================================================================================================


#======================================================================================================================================================================================
# This cheecks if the user has entered both the single test and regression options
#======================================================================================================================================================================================

if($valid_test eq 'true' and $valid_reg eq 'true')					
	{
		print (" Error: Cannot run both test and regression \n");
		help();
		
	}

#======================================================================================================================================================================================
# This checks if the user has entered any option or not
#======================================================================================================================================================================================
if (scalar @received_options == 0)
	{
		print "\nError : No options received\n";
		help();

	}

#======================================================================================================================================================================================
#This appends the cmd_reg or cmd_test accordingly.
#======================================================================================================================================================================================
switch($tool)
		{
			case 'ncsim' 	{ 	$cmd_test="irun ".$cmd_test.'-uvmhome ${IUS_HOME}/tools/uvm'." -access +rwc -perfstat \\\n\t";		# Appends the basic commmands when ncsim is selected.
						if ( $valid_test eq 'true')									# If valid_test is true all the variables associated with single test are appended
						{												# If they are " nil " they are not appended.
							$cmd_test=$cmd_test."+UVM_TESTNAME=$test_name_single \\\n\t";
							$cmd_test=$cmd_test."-vtimescale $vtimescale \\\n\t";
							$cmd_test=$cmd_test."-F $frtl \\\n\t";
							$cmd_test=$cmd_test."+UVM_VERBOSITY=$uvm_verbosity \\\n\t" if ($uvm_verbosity ne 'nil');
							$cmd_test=$cmd_test."-gui \\\n\t" if ($gui ne 'nil');
							$cmd_test=$cmd_test."+svseed=$seed \\\n\t" if ( $seed ne 'nil');
							$cmd_test=$cmd_test."+uvm_timeout=$stop_time \\\n\t" if ($stop_time ne 'nil');
							$cmd_test=$cmd_test."-input $dump \\\n\t" if ($dump ne 'nil');
						}
						elsif ( $valid_reg eq 'true')									# If valid_reg is true , all the variables associated with regression tests are appended
						{
							$cmd_reg=$cmd_reg."-vtimescale $vtimescale \\\n\t";
						  	$cmd_reg="irun ".$cmd_reg.'-uvmhome ${IUS_HOME}/tools/uvm'." -perfstat \\\n\t"; 
							$cmd_reg=$cmd_reg."-F $frtl \\\n\t";
						}
						my $row;
						if ($options ne 'nil')										# Similar procedure as above to add the deflist filelists.
						{
							my $op_fh;
							open($op_fh,'<',$options);
							while($row=<$op_fh>)
							{
								chomp $row;
								$cmd_test=$cmd_test.$row." \\\n\t";
								$cmd_reg=$cmd_reg.$row." \\\n\t";
							}
						}
						my $ftb_fh;											# The TB file lists are appended to the irun command.
						open($ftb_fh,'<',$ftb);										# The filelist file is opened using a file handle.
						while($row=<$ftb_fh>)										# Each row in the file is read.
						{			
							chomp $row;										# To remove any trainling new line characters.
							$cmd_test=$cmd_test.$top_dir.'/'.$row." \\\n\t";						
							$cmd_reg=$cmd_reg.$top_dir.'/'.$row." \\\n\t";
						}
						my $incl_fh;											#Similar procedure as above to add the inclist filelists
						open($incl_fh,'<',$inclist);
						while($row=<$incl_fh>)
						{
							chomp $row;
							$cmd_test=$cmd_test."-incdir ".$top_dir.'/'.$row." \\\n\t";
							$cmd_reg=$cmd_reg."-incdir ".$top_dir.'/'.$row." \\\n\t";
						
						}

						if ($deflist ne 'nil')										# Similar procedure as above to add the deflist filelists.
						{
							my $df_fh;
							open($df_fh,'<',$deflist);
							while($row=<$df_fh>)
							{
								chomp $row;
								$cmd_test=$cmd_test."-define ".$top_dir.'/'.$row." \\\n\t";
								$cmd_reg=$cmd_reg."-define ".$top_dir.'/'.$row." \\\n\t";
							}
						}
					}
				
			case 'modelsim' {													# Can be extended to provide support for the  mentor graphics tool.
					}
			case 'vcs' 	{ 													# Can be extended to provide support for the vcs tool.
					}
		}

#======================================================================================================================================================================================
# Based on the user entered option, the appropriate case is selected
#======================================================================================================================================================================================

switch ( $select )
	
	{

	case 'test' 	{	
				missing_test();					# To check if mandatory and optional options are given correctly for the single test case or not.
				single_test();					# To compile and then run the test.

			}
	case 'reg'	{	
				missing_reg();	 				# To check if mandatory and optional option are given correctly for regression case or not.
				reg_test();					# To compile once and then run the test cases in the reglist parallely.
				
			}
	case 'compile'	{
				missing_compile();				# To check if the mandatory options are given correctly for compile case or not.
				
				if($valid_test eq 'true')
				{	
					init_dir('single_test');		# If single test, pass 'single test' to init dir sub routine - to create it in the sim_dir amd log_dir.
					compile_test($cmd_test);		# The compile procedure is initiated and  executed.The irun command is passsed as an argument.
				}
				elsif ($valid_reg eq 'true')
				{
					init_dir($reg_file);			# If reg test, pass 'reg_file' to init_dir sub routine - to create it in the sim_dir and log_dir.
					compile_test($cmd_reg);			# The compile procedure initiated and executed, the irun command and reg file are passed as arguments.
				}
				
			}
	case 'none'	{
				print " Error : Specify Test or Regression\n";	# Test or regression option is not specified .
				help();
			}

	}

#======================================================================================================================================================================================
